#!/usr/bin/env python3
"""Simple test to identify undo/redo issues"""

import sys
import os
import traceback
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QPointF

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_simple_undo():
    """Simple test to identify the core issue"""
    print("Simple Undo/Redo Test")
    print("=" * 50)
    
    app = QApplication(sys.argv)
    
    # Import after QApplication is created
    from ui.canvas import Canvas
    from cad.shapes import Line, Circle, Rectangle
    
    canvas = Canvas()
    
    # Test 1: Add first shape
    print("\n1. Adding Line...")
    line = Line(QPointF(0, 0), QPointF(100, 100))
    canvas.editor.add_shape(line)
    canvas.save_to_history()
    print(f"   History: {len(canvas.history)} entries, index: {canvas.history_index}")
    
    # Test 2: Add second shape
    print("\n2. Adding Circle...")
    circle = Circle(QPointF(50, 50), 25)
    canvas.editor.add_shape(circle)
    canvas.save_to_history()
    print(f"   History: {len(canvas.history)} entries, index: {canvas.history_index}")
    
    # Test 3: Add third shape
    print("\n3. Adding Rectangle...")
    rect = Rectangle(QPointF(0, 0), QPointF(200, 200))
    canvas.editor.add_shape(rect)
    canvas.save_to_history()
    print(f"   History: {len(canvas.history)} entries, index: {canvas.history_index}")
    
    # Test 4: Undo once
    print("\n4. First Undo...")
    try:
        canvas.undo()
        print(f"   SUCCESS: History: {len(canvas.history)} entries, index: {canvas.history_index}")
        print(f"   Editor shapes: {len(canvas.editor.shapes)}")
    except Exception as e:
        print(f"   ERROR: {e}")
        traceback.print_exc()
    
    # Test 5: Undo twice
    print("\n5. Second Undo...")
    try:
        canvas.undo()
        print(f"   SUCCESS: History: {len(canvas.history)} entries, index: {canvas.history_index}")
        print(f"   Editor shapes: {len(canvas.editor.shapes)}")
    except Exception as e:
        print(f"   ERROR: {e}")
        traceback.print_exc()
    
    # Test 6: Redo once
    print("\n6. First Redo...")
    try:
        canvas.redo()
        print(f"   SUCCESS: History: {len(canvas.history)} entries, index: {canvas.history_index}")
        print(f"   Editor shapes: {len(canvas.editor.shapes)}")
    except Exception as e:
        print(f"   ERROR: {e}")
        traceback.print_exc()
    
    # Test 7: Add a new shape (should invalidate redo stack)
    print("\n7. Adding new shape after undo...")
    line2 = Line(QPointF(200, 200), QPointF(300, 300))
    canvas.editor.add_shape(line2)
    canvas.save_to_history()
    print(f"   History: {len(canvas.history)} entries, index: {canvas.history_index}")
    
    # Test 8: Try to redo (should be no-op)
    print("\n8. Attempting redo (should be no-op)...")
    try:
        canvas.redo()
        print(f"   SUCCESS: History: {len(canvas.history)} entries, index: {canvas.history_index}")
    except Exception as e:
        print(f"   ERROR: {e}")
    
    print("\nTest Complete!")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(test_simple_undo())
    except Exception as e:
        print(f"Test failed: {e}")
        traceback.print_exc()
        sys.exit(1)
