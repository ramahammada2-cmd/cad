#!/usr/bin/env python
"""
Test script for laser cutting optimization features
"""

import sys
sys.path.append('/workspace/fixed_cad')

from cad.image_to_vector import ImageToVectorConverter
import numpy as np
import cv2

def test_kerf_compensation():
    """Test kerf width compensation"""
    print("Testing Kerf Compensation...")
    converter = ImageToVectorConverter()
    
    # Create a simple test shape (circle)
    from cad.shapes import Circle
    from PyQt5.QtCore import QPointF
    
    test_circle = Circle(QPointF(50, 50), 25.0)
    shapes = [test_circle]
    
    # Apply kerf compensation
    compensated = converter.apply_kerf_compensation(shapes, 0.15)
    
    print(f"Original radius: {test_circle.radius}")
    print(f"Compensated radius: {compensated[0].radius}")
    print(f"Expected: {test_circle.radius + 0.15/2}")
    print()

def test_material_settings():
    """Test material-specific settings"""
    print("Testing Material Settings...")
    converter = ImageToVectorConverter()
    
    materials = ['plywood', 'acrylic', 'metal', 'cardboard']
    
    for material in materials:
        settings = converter.set_material_settings(material)
        print(f"{material}:")
        print(f"  Kerf: {settings['kerf_width']}mm")
        print(f"  Power: {settings['power']}%")
        print(f"  Speed: {settings['speed']}mm/min")
        print()

def test_cut_order_optimization():
    """Test cut order optimization"""
    print("Testing Cut Order Optimization...")
    converter = ImageToVectorConverter()
    
    # Create test shapes
    from cad.shapes import Circle, Rectangle
    from PyQt5.QtCore import QPointF
    
    shapes = [
        Circle(QPointF(100, 100), 10.0),  # Small circle
        Circle(QPointF(200, 200), 50.0),  # Large circle
        Rectangle(QPointF(50, 50), QPointF(150, 150)),  # Rectangle
    ]
    
    print(f"Original shapes count: {len(shapes)}")
    
    # Optimize cut order
    optimized = converter.optimize_cut_order(shapes, 'plywood')
    
    print(f"Optimized shapes count: {len(optimized)}")
    print("Cut order optimization completed")
    print()

def test_thermal_management():
    """Test thermal management"""
    print("Testing Thermal Management...")
    converter = ImageToVectorConverter()
    
    # Create test shapes
    from cad.shapes import Circle, Polyline
    from PyQt5.QtCore import QPointF
    
    # Simple shape
    simple_shape = Circle(QPointF(100, 100), 25.0)
    
    # Complex shape (mock)
    class MockComplexShape:
        def get_length(self):
            return 300  # Long path requiring thermal management
        
        def get_vertex_count(self):
            return 60  # High vertex count
        
        def set_thermal_priority(self, priority):
            self.thermal_priority = priority
    
    complex_shape = MockComplexShape()
    
    shapes = [simple_shape, complex_shape]
    
    # Apply thermal management
    managed = converter.apply_thermal_management(shapes, 'plywood')
    
    print("Thermal management applied")
    print(f"Shapes processed: {len(managed)}")
    print()

def test_gap_detection():
    """Test gap detection and feature analysis"""
    print("Testing Gap Detection...")
    converter = ImageToVectorConverter()
    
    # Create test shapes with gaps
    from cad.shapes import Circle, Rectangle
    from PyQt5.QtCore import QPointF
    
    shapes = [
        Circle(QPointF(50, 50), 20.0),
        Circle(QPointF(100, 50), 20.0),  # Close to first circle
        Rectangle(QPointF(200, 200), QPointF(250, 250))
    ]
    
    # Analyze gaps
    gap_analysis = converter.detect_gaps_and_features(shapes, min_gap_size=5.0)
    
    print(f"Total gaps detected: {gap_analysis['total_gaps']}")
    print(f"Critical gaps: {gap_analysis['critical_gaps']}")
    print(f"Recommendations: {len(gap_analysis['recommendations'])}")
    print()

def test_pattern_recognition():
    """Test decorative pattern recognition"""
    print("Testing Pattern Recognition...")
    converter = ImageToVectorConverter()
    
    # Create a simple test image
    test_image = np.zeros((200, 200, 3), dtype=np.uint8)
    
    # Add some circles to simulate honeycomb pattern
    cv2.circle(test_image, (50, 50), 15, (255, 255, 255), 2)
    cv2.circle(test_image, (100, 50), 15, (255, 255, 255), 2)
    cv2.circle(test_image, (75, 80), 15, (255, 255, 255), 2)
    
    # Add some lines to simulate geometric pattern
    cv2.line(test_image, (150, 150), (150, 180), (255, 255, 255), 2)
    cv2.line(test_image, (150, 165), (180, 165), (255, 255, 255), 2)
    
    # Recognize patterns
    pattern_analysis = converter.recognize_decorative_patterns(test_image)
    
    print(f"Patterns detected: {pattern_analysis['pattern_count']}")
    for pattern in pattern_analysis['patterns']:
        print(f"  - {pattern['type']} pattern")
    print()

def test_gcode_generation():
    """Test G-code generation"""
    print("Testing G-code Generation...")
    converter = ImageToVectorConverter()
    
    # Create simple test shapes
    from cad.shapes import Circle, Rectangle
    from PyQt5.QtCore import QPointF
    
    shapes = [
        Circle(QPointF(50, 50), 25.0),
        Rectangle(QPointF(150, 150), QPointF(200, 200))
    ]
    
    # Generate G-code
    gcode = converter.generate_laser_cutting_gcode(shapes, 'plywood')
    
    lines = gcode.split('\n')
    print(f"Generated G-code with {len(lines)} lines")
    print("First 10 lines:")
    for i, line in enumerate(lines[:10]):
        print(f"  {i+1}: {line}")
    print("...")
    print()

def main():
    """Run all tests"""
    print("=" * 60)
    print("LASER CUTTING FEATURES TEST SUITE")
    print("=" * 60)
    print()
    
    try:
        test_kerf_compensation()
        test_material_settings()
        test_cut_order_optimization()
        test_thermal_management()
        test_gap_detection()
        test_pattern_recognition()
        test_gcode_generation()
        
        print("=" * 60)
        print("ALL TESTS COMPLETED SUCCESSFULLY!")
        print("=" * 60)
        
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
