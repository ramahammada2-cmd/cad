#!/usr/bin/env python3
"""
Simple test script to verify text integration fixes without GUI dependencies.
This script tests the core text functionality.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PyQt5.QtCore import QPointF
from PyQt5.QtWidgets import QGraphicsItem
from PyQt5.QtGui import QFont, QColor

# Import the fixed modules
from cad.shapes import Text
from cad.editor import Editor

def test_text_creation():
    """Test that text can be created and positioned correctly."""
    print("Test 1: Text Creation and Positioning")
    print("-" * 50)
    
    # Create a text shape
    position = QPointF(100, 100)
    text = Text(position, "Test Text")
    
    # Check if position is set correctly
    actual_pos = text.pos()
    print(f"Expected position: ({position.x()}, {position.y()})")
    print(f"Actual position: ({actual_pos.x()}, {actual_pos.y()})")
    
    assert abs(actual_pos.x() - position.x()) < 0.01, "X position mismatch"
    assert abs(actual_pos.y() - position.y()) < 0.01, "Y position mismatch"
    
    # Check if text content is correct
    print(f"Text content: {text.get_text()}")
    assert text.get_text() == "Test Text", "Text content mismatch"
    
    # Check if text_item is at (0, 0) relative to parent
    text_item_pos = text.text_item.pos()
    print(f"Text item relative position: ({text_item_pos.x()}, {text_item_pos.y()})")
    assert abs(text_item_pos.x()) < 0.01, "Text item X position should be 0"
    assert abs(text_item_pos.y()) < 0.01, "Text item Y position should be 0"
    
    print("✓ Text creation and positioning test passed!\n")

def test_text_selection_flags():
    """Test that text items have correct selection flags."""
    print("Test 2: Text Item Flags")
    print("-" * 50)
    
    position = QPointF(50, 50)
    text = Text(position, "Flag Test")
    
    # Check that parent is selectable and movable
    assert text.flags() & 0x1, "Parent should be selectable"  # ItemIsSelectable
    assert text.flags() & 0x2, "Parent should be movable"  # ItemIsMovable
    
    # Check that child text_item is not independently selectable
    print(f"Parent flags: {text.flags()}")
    print(f"Text item flags: {text.text_item.flags()}")
    
    print("✓ Text item flags test passed!\n")

def test_text_clone():
    """Test that text can be cloned correctly."""
    print("Test 3: Text Cloning")
    print("-" * 50)
    
    position = QPointF(200, 200)
    text = Text(position, "Original")
    text.set_color("#FF0000")
    text.set_font_size(16)
    
    # Clone the text
    cloned = text.clone()
    
    # Check if position is preserved
    cloned_pos = cloned.pos()
    original_pos = text.pos()
    print(f"Original position: ({original_pos.x()}, {original_pos.y()})")
    print(f"Cloned position: ({cloned_pos.x()}, {cloned_pos.y()})")
    
    assert abs(cloned_pos.x() - original_pos.x()) < 0.01, "Cloned X position mismatch"
    assert abs(cloned_pos.y() - original_pos.y()) < 0.01, "Cloned Y position mismatch"
    
    # Check if text content is preserved
    print(f"Original text: {text.get_text()}")
    print(f"Cloned text: {cloned.get_text()}")
    assert cloned.get_text() == "Original", "Cloned text content mismatch"
    
    # Check if properties are preserved
    print(f"Original color: {text.get_color()}")
    print(f"Cloned color: {cloned.get_color()}")
    assert cloned.get_color() == "#FF0000", "Cloned color mismatch"
    
    print(f"Original font size: {text.get_font_size()}")
    print(f"Cloned font size: {cloned.get_font_size()}")
    assert cloned.get_font_size() == 16, "Cloned font size mismatch"
    
    print("✓ Text cloning test passed!\n")

def test_text_set_position():
    """Test that text position can be changed correctly."""
    print("Test 4: Text Position Setting")
    print("-" * 50)
    
    position = QPointF(100, 100)
    text = Text(position, "Position Test")
    
    # Change position
    new_position = QPointF(300, 400)
    text.set_position(new_position)
    
    # Check if position is updated
    actual_pos = text.pos()
    print(f"New position: ({new_position.x()}, {new_position.y()})")
    print(f"Actual position: ({actual_pos.x()}, {actual_pos.y()})")
    
    assert abs(actual_pos.x() - new_position.x()) < 0.01, "X position update failed"
    assert abs(actual_pos.y() - new_position.y()) < 0.01, "Y position update failed"
    
    print("✓ Text position setting test passed!\n")

def test_text_properties():
    """Test that text properties can be changed."""
    print("Test 5: Text Properties")
    print("-" * 50)
    
    position = QPointF(150, 150)
    text = Text(position, "Property Test")
    
    # Test text change
    text.set_text("Modified Text")
    assert text.get_text() == "Modified Text", "Text content update failed"
    print(f"✓ Text content changed: {text.get_text()}")
    
    # Test font change
    text.set_font("Times")
    assert text.get_font() == "Times", "Font update failed"
    print(f"✓ Font changed: {text.get_font()}")
    
    # Test font size change
    text.set_font_size(20)
    assert text.get_font_size() == 20, "Font size update failed"
    print(f"✓ Font size changed: {text.get_font_size()}")
    
    # Test color change
    text.set_color("#00FF00")
    assert text.get_color() == "#00FF00", "Color update failed"
    print(f"✓ Color changed: {text.get_color()}")
    
    print("✓ Text properties test passed!\n")

def test_bounding_rect():
    """Test that bounding rectangle is calculated correctly."""
    print("Test 6: Text Bounding Rectangle")
    print("-" * 50)
    
    position = QPointF(100, 100)
    text = Text(position, "Bounding Box Test")
    
    # Get bounding rect
    rect = text.boundingRect()
    print(f"Bounding rect: x={rect.x()}, y={rect.y()}, width={rect.width()}, height={rect.height()}")
    
    # Bounding rect should be valid (not null)
    assert rect.width() > 0, "Bounding rect width should be positive"
    assert rect.height() > 0, "Bounding rect height should be positive"
    
    print("✓ Text bounding rectangle test passed!\n")

def test_editor_integration():
    """Test that text integrates with the editor."""
    print("Test 7: Editor Integration")
    print("-" * 50)
    
    # Create editor
    editor = Editor()
    
    # Create a text shape
    position = QPointF(250, 250)
    text = Text(position, "Editor Test")
    
    # Add to editor
    editor.add_shape(text)
    
    # Check if shape is in editor's list
    shapes = editor.get_shapes()
    assert len(shapes) == 1, "Editor should have 1 shape"
    assert shapes[0] == text, "Editor should have the correct shape"
    print(f"✓ Text added to editor: {text.get_text()}")
    
    # Remove from editor
    editor.delete_shape(text)
    shapes = editor.get_shapes()
    assert len(shapes) == 0, "Editor should have 0 shapes after deletion"
    print("✓ Text removed from editor")
    
    print("✓ Editor integration test passed!\n")

def test_text_paint():
    """Test that text can be painted (basic test)."""
    print("Test 8: Text Painting")
    print("-" * 50)
    
    position = QPointF(100, 100)
    text = Text(position, "Paint Test")
    
    # Check that paint method exists and doesn't crash
    try:
        # We can't actually test painting without a QPainter, but we can verify
        # the method exists and the bounding rect is valid
        rect = text.boundingRect()
        assert rect.isValid(), "Bounding rect should be valid for painting"
        print(f"✓ Text is ready for painting (bounding rect: {rect.width()}x{rect.height()})")
    except Exception as e:
        print(f"✗ Paint test failed: {e}")
        raise
    
    print("✓ Text painting test passed!\n")

def main():
    """Run all tests."""
    print("=" * 50)
    print("TEXT INTEGRATION FIXES - SIMPLE TEST SUITE")
    print("=" * 50)
    print()
    
    try:
        test_text_creation()
        test_text_selection_flags()
        test_text_clone()
        test_text_set_position()
        test_text_properties()
        test_bounding_rect()
        test_editor_integration()
        test_text_paint()
        
        print("=" * 50)
        print("ALL TESTS PASSED! ✓")
        print("=" * 50)
        print()
        print("Text integration is working correctly!")
        print()
        print("Key fixes verified:")
        print("✓ Text appears at correct position after creation")
        print("✓ Text item is positioned at (0,0) relative to parent")
        print("✓ Parent Text shape handles all positioning")
        print("✓ Text is properly selectable and movable")
        print("✓ Text properties can be changed correctly")
        print("✓ Text cloning preserves all properties")
        print("✓ Text integrates properly with editor")
        return 0
        
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        return 1
    except Exception as e:
        print(f"\n❌ UNEXPECTED ERROR: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
