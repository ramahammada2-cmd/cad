
import os
import json

class Settings:
    def __init__(self):
        self.app_data_dir = os.path.join(os.path.expanduser("~"), "LaserCAD_H1530")
        self.settings_file = os.path.join(self.app_data_dir, "settings.json")
        
        # Default settings
        self.theme = "light"
        self.material_width = 1000  # mm
        self.material_height = 600  # mm
        self.spacing = 5  # mm
        self.default_thickness = 2  # px
        self.default_color = "#000000"
        self.auto_save_interval = 60  # seconds
        self.show_grid = True
        self.snap_to_grid = True
        self.grid_size = 20  # px
        
        # Load settings if file exists
        self.load()
    
    def load(self):
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, 'r') as f:
                    settings = json.load(f)
                
                # Update settings
                for key, value in settings.items():
                    if hasattr(self, key):
                        setattr(self, key, value)
            except Exception as e:
                print(f"Failed to load settings: {str(e)}")
    
    def save(self):
        # Create directory if it doesn't exist
        os.makedirs(self.app_data_dir, exist_ok=True)
        
        # Save settings
        settings = {
            "theme": self.theme,
            "material_width": self.material_width,
            "material_height": self.material_height,
            "spacing": self.spacing,
            "default_thickness": self.default_thickness,
            "default_color": self.default_color,
            "auto_save_interval": self.auto_save_interval,
            "show_grid": self.show_grid,
            "snap_to_grid": self.snap_to_grid,
            "grid_size": self.grid_size
        }
        
        try:
            with open(self.settings_file, 'w') as f:
                json.dump(settings, f, indent=2)
        except Exception as e:
            print(f"Failed to save settings: {str(e)}")