#!/usr/bin/env python3
"""Test script to verify the undo/redo fix"""

import sys
import os
import traceback
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QPointF

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_undo_redo_with_fix():
    """Test undo/redo with the proposed fix"""
    print("Testing Undo/Redo with Signal Blocking Fix")
    print("=" * 60)
    
    app = QApplication(sys.argv)
    
    from ui.canvas import Canvas
    from cad.shapes import Line, Circle, Rectangle
    
    canvas = Canvas()
    
    # Test the current broken implementation first
    print("\n=== Testing CURRENT (broken) Implementation ===")
    
    # Add shapes
    print("\n1. Adding shapes...")
    line = Line(QPointF(0, 0), QPointF(100, 100))
    canvas.editor.add_shape(line)
    canvas.save_to_history()
    
    circle = Circle(QPointF(50, 50), 25)
    canvas.editor.add_shape(circle)
    canvas.save_to_history()
    
    rectangle = Rectangle(QPointF(0, 0), QPointF(200, 200))
    canvas.editor.add_shape(rectangle)
    canvas.save_to_history()
    
    print(f"   History: {len(canvas.history)} entries, index: {canvas.history_index}")
    
    # Test undo (should fail)
    print("\n2. Testing undo (should fail with current implementation)...")
    try:
        canvas.undo()
        print(f"   SUCCESS: History: {len(canvas.history)} entries, index: {canvas.history_index}")
        print(f"   Editor shapes: {len(canvas.editor.shapes)}")
    except Exception as e:
        print(f"   EXPECTED ERROR: {e}")
    
    # Now test with the fixed implementation
    print("\n\n=== Testing FIXED Implementation ===")
    
    # Create a new canvas with the fix
    canvas_fixed = Canvas()
    
    # Monkey patch the restore_from_history method with the fix
    def restore_from_history_fixed(self):
        """Fixed version that blocks signals during restoration"""
        # Block signals to prevent on_all_shapes_cleared from clearing history
        self.editor.blockSignals(True)
        
        try:
            # Clear current scene and editor state
            self.scene.clear()
            self.selected_shapes = []
            self.editor.clear_all()
            
            # Validate history index
            if (self.history_index < 0 or 
                self.history_index >= len(self.history)):
                print(f"     Invalid history state: index={self.history_index}, len={len(self.history)}")
                return
            
            # Restore shapes from history
            shapes = self.history[self.history_index]
            if shapes:
                # Add all shapes to the scene
                for shape in shapes:
                    self.scene.addItem(shape)
                
                # Load shapes into editor without emitting signals
                self.editor.load_shapes_silent(shapes)
                print(f"     Restored {len(shapes)} shapes from history")
        finally:
            # Re-enable signals
            self.editor.blockSignals(False)
        
        self.logMessage.emit("History restored", "info")
    
    # Apply the fix
    import types
    canvas_fixed.restore_from_history = types.MethodType(restore_from_history_fixed, canvas_fixed)
    
    # Add shapes to the fixed canvas
    print("\n3. Adding shapes to fixed canvas...")
    line = Line(QPointF(0, 0), QPointF(100, 100))
    canvas_fixed.editor.add_shape(line)
    canvas_fixed.save_to_history()
    
    circle = Circle(QPointF(50, 50), 25)
    canvas_fixed.editor.add_shape(circle)
    canvas_fixed.save_to_history()
    
    rectangle = Rectangle(QPointF(0, 0), QPointF(200, 200))
    canvas_fixed.editor.add_shape(rectangle)
    canvas_fixed.save_to_history()
    
    print(f"   History: {len(canvas_fixed.history)} entries, index: {canvas_fixed.history_index}")
    
    # Test undo operations
    print("\n4. Testing first undo...")
    try:
        canvas_fixed.undo()
        print(f"   SUCCESS: History: {len(canvas_fixed.history)} entries, index: {canvas_fixed.history_index}")
        print(f"   Editor shapes: {len(canvas_fixed.editor.shapes)}")
    except Exception as e:
        print(f"   ERROR: {e}")
        traceback.print_exc()
    
    print("\n5. Testing second undo...")
    try:
        canvas_fixed.undo()
        print(f"   SUCCESS: History: {len(canvas_fixed.history)} entries, index: {canvas_fixed.history_index}")
        print(f"   Editor shapes: {len(canvas_fixed.editor.shapes)}")
    except Exception as e:
        print(f"   ERROR: {e}")
        traceback.print_exc()
    
    print("\n6. Testing redo operations...")
    try:
        canvas_fixed.redo()
        print(f"   SUCCESS: History: {len(canvas_fixed.history)} entries, index: {canvas_fixed.history_index}")
        print(f"   Editor shapes: {len(canvas_fixed.editor.shapes)}")
    except Exception as e:
        print(f"   ERROR: {e}")
        traceback.print_exc()
    
    try:
        canvas_fixed.redo()
        print(f"   SUCCESS: History: {len(canvas_fixed.history)} entries, index: {canvas_fixed.history_index}")
        print(f"   Editor shapes: {len(canvas_fixed.editor.shapes)}")
    except Exception as e:
        print(f"   ERROR: {e}")
        traceback.print_exc()
    
    # Test edge cases
    print("\n7. Testing edge cases...")
    
    # Try undo at beginning of history
    try:
        canvas_fixed.undo()  # Should be no-op or handle gracefully
        print(f"   Undo at beginning: History: {len(canvas_fixed.history)} entries, index: {canvas_fixed.history_index}")
    except Exception as e:
        print(f"   ERROR on undo at beginning: {e}")
    
    # Try redo at end of history  
    try:
        canvas_fixed.redo()  # Should be no-op or handle gracefully
        print(f"   Redo at end: History: {len(canvas_fixed.history)} entries, index: {canvas_fixed.history_index}")
    except Exception as e:
        print(f"   ERROR on redo at end: {e}")
    
    print("\n=== Test Complete ===")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(test_undo_redo_with_fix())
    except Exception as e:
        print(f"Test failed: {e}")
        traceback.print_exc()
        sys.exit(1)
