#!/usr/bin/env python3
"""Test script to identify undo/redo issues in LaserCAD"""

import sys
import traceback
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QPointF
from ui.canvas import Canvas
from cad.shapes import Line, Circle, Rectangle, Polygon, Text

def test_history_management():
    """Test history management system"""
    print("=" * 60)
    print("Testing History Management System")
    print("=" * 60)
    
    # Create a canvas instance
    canvas = Canvas()
    
    # Test 1: Initial state
    print("\n1. Initial State:")
    print(f"   History length: {len(canvas.history)}")
    print(f"   History index: {canvas.history_index}")
    print(f"   History: {canvas.history}")
    
    # Test 2: Add first shape
    print("\n2. Adding first shape (Line):")
    line = Line(QPointF(0, 0), QPointF(100, 100))
    canvas.editor.add_shape(line)
    canvas.save_to_history()
    print(f"   History length: {len(canvas.history)}")
    print(f"   History index: {canvas.history_index}")
    print(f"   First history entry (shapes): {len(canvas.history[0])}")
    
    # Test 3: Add second shape
    print("\n3. Adding second shape (Circle):")
    circle = Circle(QPointF(50, 50), 25)
    canvas.editor.add_shape(circle)
    canvas.save_to_history()
    print(f"   History length: {len(canvas.history)}")
    print(f"   History index: {canvas.history_index}")
    print(f"   Second history entry (shapes): {len(canvas.history[1])}")
    
    # Test 4: Add third shape
    print("\n4. Adding third shape (Rectangle):")
    rectangle = Rectangle(QPointF(0, 0), QPointF(200, 200))
    canvas.editor.add_shape(rectangle)
    canvas.save_to_history()
    print(f"   History length: {len(canvas.history)}")
    print(f"   History index: {canvas.history_index}")
    print(f"   Third history entry (shapes): {len(canvas.history[2])}")
    
    return canvas

def test_undo_operations(canvas):
    """Test undo operations"""
    print("\n" + "=" * 60)
    print("Testing Undo Operations")
    print("=" * 60)
    
    # Test undo
    print(f"\nBefore undo - History index: {canvas.history_index}")
    print(f"Editor shapes: {len(canvas.editor.shapes)}")
    print(f"Scene items: {len([item for item in canvas.scene.items() if isinstance(item, type(canvas.editor.shapes[0]))])}")
    
    canvas.undo()
    print(f"\nAfter first undo - History index: {canvas.history_index}")
    print(f"Editor shapes: {len(canvas.editor.shapes)}")
    print(f"Scene items: {len([item for item in canvas.scene.items() if isinstance(item, type(canvas.editor.shapes[0]))])}")
    
    canvas.undo()
    print(f"\nAfter second undo - History index: {canvas.history_index}")
    print(f"Editor shapes: {len(canvas.editor.shapes)}")
    print(f"Scene items: {len([item for item in canvas.scene.items() if isinstance(item, type(canvas.editor.shapes[0]))])}")
    
    # Try another undo (should be no-op)
    print("\nAttempting third undo (should be no-op):")
    try:
        canvas.undo()
        print(f"   History index after no-op undo: {canvas.history_index}")
    except Exception as e:
        print(f"   Error during undo: {e}")
        traceback.print_exc()

def test_redo_operations(canvas):
    """Test redo operations"""
    print("\n" + "=" * 60)
    print("Testing Redo Operations")
    print("=" * 60)
    
    # Test redo
    print(f"\nBefore redo - History index: {canvas.history_index}")
    print(f"Editor shapes: {len(canvas.editor.shapes)}")
    print(f"Scene items: {len([item for item in canvas.scene.items() if isinstance(item, type(canvas.editor.shapes[0]))])}")
    
    canvas.redo()
    print(f"\nAfter first redo - History index: {canvas.history_index}")
    print(f"Editor shapes: {len(canvas.editor.shapes)}")
    print(f"Scene items: {len([item for item in canvas.scene.items() if isinstance(item, type(canvas.editor.shapes[0]))])}")
    
    canvas.redo()
    print(f"\nAfter second redo - History index: {canvas.history_index}")
    print(f"Editor shapes: {len(canvas.editor.shapes)}")
    print(f"Scene items: {len([item for item in canvas.scene.items() if isinstance(item, type(canvas.editor.shapes[0]))])}")
    
    # Try another redo (should be no-op)
    print("\nAttempting third redo (should be no-op):")
    try:
        canvas.redo()
        print(f"   History index after no-op redo: {canvas.history_index}")
    except Exception as e:
        print(f"   Error during redo: {e}")
        traceback.print_exc()

def test_shape_movement():
    """Test undo/redo with shape movement"""
    print("\n" + "=" * 60)
    print("Testing Shape Movement and Undo/Redo")
    print("=" * 60)
    
    canvas = Canvas()
    
    # Add a shape
    print("\n1. Adding a line:")
    line = Line(QPointF(0, 0), QPointF(100, 100))
    canvas.editor.add_shape(line)
    canvas.save_to_history()
    print(f"   Line position: {line.pos()}")
    
    # Move the shape
    print("\n2. Moving the line:")
    print(f"   Before move - Position: {line.pos()}")
    line.setPos(QPointF(50, 50))
    print(f"   After move - Position: {line.pos()}")
    print(f"   Movement saved to history: {canvas.save_to_history()}")
    print(f"   History index: {canvas.history_index}")
    
    # Undo the movement
    print("\n3. Undoing the move:")
    canvas.undo()
    print(f"   After undo - Line position: {line.pos()}")
    print(f"   History index: {canvas.history_index}")
    
    # Redo the movement
    print("\n4. Redoing the move:")
    canvas.redo()
    print(f"   After redo - Line position: {line.pos()}")
    print(f"   History index: {canvas.history_index}")

def test_different_tools():
    """Test undo/redo with different drawing tools"""
    print("\n" + "=" * 60)
    print("Testing Different Drawing Tools")
    print("=" * 60)
    
    canvas = Canvas()
    
    tools_tests = [
        ("Circle", lambda: Circle(QPointF(0, 0), 50)),
        ("Rectangle", lambda: Rectangle(QPointF(0, 0), QPointF(100, 100))),
        ("Text", lambda: Text(QPointF(0, 0), "Test Text")),
    ]
    
    for tool_name, shape_creator in tools_tests:
        print(f"\n{tool_name} Test:")
        try:
            shape = shape_creator()
            canvas.editor.add_shape(shape)
            canvas.save_to_history()
            print(f"   {tool_name} added successfully")
            print(f"   History index: {canvas.history_index}")
        except Exception as e:
            print(f"   Error adding {tool_name}: {e}")
            traceback.print_exc()
    
    # Test undo with mixed tools
    print("\nTesting undo with mixed tools:")
    canvas.undo()
    print(f"   After undo: {canvas.history_index}")
    canvas.undo()
    print(f"   After second undo: {canvas.history_index}")

def test_special_cases():
    """Test special cases and edge conditions"""
    print("\n" + "=" * 60)
    print("Testing Special Cases")
    print("=" * 60)
    
    # Test with empty history
    print("\n1. Testing undo with empty history:")
    canvas = Canvas()
    try:
        canvas.undo()
        print("   Undo with empty history - no error")
    except Exception as e:
        print(f"   Error: {e}")
    
    # Test with empty history (redo)
    print("\n2. Testing redo with empty history:")
    try:
        canvas.redo()
        print("   Redo with empty history - no error")
    except Exception as e:
        print(f"   Error: {e}")
    
    # Test multiple undos in a row
    print("\n3. Testing multiple undos in a row:")
    canvas = Canvas()
    line1 = Line(QPointF(0, 0), QPointF(100, 100))
    canvas.editor.add_shape(line1)
    canvas.save_to_history()
    
    line2 = Line(QPointF(100, 100), QPointF(200, 200))
    canvas.editor.add_shape(line2)
    canvas.save_to_history()
    
    for i in range(5):  # Try more undos than we have history for
        print(f"   Attempting undo #{i+1}:")
        try:
            canvas.undo()
            print(f"     Success - History index: {canvas.history_index}")
        except Exception as e:
            print(f"     Error: {e}")

def main():
    """Main test function"""
    app = QApplication(sys.argv)
    
    print("LaserCAD Undo/Redo Functionality Test")
    print("=" * 60)
    
    try:
        # Run tests
        canvas = test_history_management()
        test_undo_operations(canvas)
        test_redo_operations(canvas)
        test_shape_movement()
        test_different_tools()
        test_special_cases()
        
        print("\n" + "=" * 60)
        print("Test Complete")
        print("=" * 60)
        
    except Exception as e:
        print(f"\nTest failed with error: {e}")
        traceback.print_exc()
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
