
from shapely.geometry import LineString, Polygon, Point
from shapely.ops import unary_union

class Analyzer:
    def __init__(self):
        pass
    
    def analyze(self, shapes):
        issues = []
        
        # Convert shapes to Shapely geometries
        geometries = []
        for shape in shapes:
            geom = self.shape_to_geometry(shape)
            if geom:
                geometries.append((shape, geom))
        
        # Check for open paths
        open_paths = self.check_open_paths(geometries)
        if open_paths:
            issues.append(f"Found {len(open_paths)} open paths")
        
        # Check for overlaps
        overlaps = self.check_overlaps(geometries)
        if overlaps:
            issues.append(f"Found {len(overlaps)} overlapping shapes")
        
        # Check for duplicate geometry
        duplicates = self.check_duplicates(geometries)
        if duplicates:
            issues.append(f"Found {len(duplicates)} duplicate shapes")
        
        # Check for small features that might be difficult to cut
        small_features = self.check_small_features(geometries)
        if small_features:
            issues.append(f"Found {len(small_features)} small features that might be difficult to cut")
        
        return issues
    
    def shape_to_geometry(self, shape):
        # Convert CAD shape to Shapely geometry
        shape_type = shape.__class__.__name__
        
        if shape_type == "Line":
            return LineString([(shape.get_start_point().x(), shape.get_start_point().y()),
                              (shape.get_end_point().x(), shape.get_end_point().y())])
        elif shape_type == "Circle":
            center = shape.get_center()
            radius = shape.get_radius()
            return Point(center.x(), center.y()).buffer(radius)
        elif shape_type == "Rectangle":
            rect = shape.boundingRect()
            return Polygon([(rect.left(), rect.top()),
                           (rect.right(), rect.top()),
                           (rect.right(), rect.bottom()),
                           (rect.left(), rect.bottom())])
        elif shape_type == "Polygon":
            points = [(p.x(), p.y()) for p in shape.get_points()]
            if len(points) >= 3:
                return Polygon(points)
        elif shape_type == "Polyline":
            points = [(p.x(), p.y()) for p in shape.get_points()]
            if len(points) >= 2:
                return LineString(points)
        
        return None
    
    def check_open_paths(self, geometries):
        open_paths = []
        
        for shape, geom in geometries:
            if isinstance(geom, LineString) and not geom.is_closed:
                open_paths.append(shape)
        
        return open_paths
    
    def check_overlaps(self, geometries):
        overlaps = []
        
        # Check each pair of geometries for overlap
        for i, (shape1, geom1) in enumerate(geometries):
            for shape2, geom2 in geometries[i+1:]:
                if geom1.intersects(geom2):
                    overlaps.append((shape1, shape2))
        
        return overlaps
    
    def check_duplicates(self, geometries):
        duplicates = []
        
        # Check each pair of geometries for equality
        for i, (shape1, geom1) in enumerate(geometries):
            for shape2, geom2 in geometries[i+1:]:
                if geom1.equals(geom2):
                    duplicates.append((shape1, shape2))
        
        return duplicates
    
    def check_small_features(self, geometries, min_size=1.0):
        small_features = []
        
        for shape, geom in geometries:
            if isinstance(geom, Polygon):
                if geom.area < min_size:
                    small_features.append(shape)
            elif isinstance(geom, LineString):
                if geom.length < min_size:
                    small_features.append(shape)
        
        return small_features