from PyQt5.QtCore import QObject, pyqtSignal

class Editor(QObject):
    shapeAdded = pyqtSignal(object)
    shapeUpdated = pyqtSignal(object)
    shapeDeleted = pyqtSignal(object)
    allShapesCleared = pyqtSignal()  # Add this new signal
    
    def __init__(self):
        super().__init__()
        
        # Shapes
        self.shapes = []
    
    def add_shape(self, shape):
        self.shapes.append(shape)
        self.shapeAdded.emit(shape)
    
    def update_shape(self, shape):
        if shape in self.shapes:
            self.shapeUpdated.emit(shape)
    
    def delete_shape(self, shape):
        if shape in self.shapes:
            self.shapes.remove(shape)
            self.shapeDeleted.emit(shape)
    
    def get_shapes(self):
        return self.shapes
    
    def clear_all(self):
        """Clear all shapes without emitting signals."""
        self.shapes.clear()
    
    def add_shapes_silent(self, shapes):
        """Add multiple shapes without emitting signals (for undo/redo operations)"""
        self.shapes.extend(shapes)
    
    def load_shapes_silent(self, shapes):
        """Load shapes without emitting signals (for undo/redo operations)"""
        self.shapes = list(shapes)  # Create a copy to avoid reference issues

    def load_shapes_silent(self, shapes):
        """Load shapes into the editor without emitting signals."""
        self.shapes = shapes
        # Note: We don't emit shapeAdded here to prevent recursive calls