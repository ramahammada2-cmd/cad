# cad/shapes_fixed.py - Enhanced shapes with improved Text handling
import math
from PyQt5.QtWidgets import QGraphicsItem, QGraphicsTextItem, QGraphicsRectItem
from PyQt5.QtCore import Qt, QPointF, QRectF, pyqtSignal, QSizeF
from PyQt5.QtGui import QPen, QBrush, QColor, QPainter, QPainterPath, QFont, QPolygonF, QTransform

class Shape(QGraphicsItem):
    def __init__(self):
        super().__init__()
        
        # Shape properties
        self.color = "#000000"
        self.thickness = 2
        self.fill = False
        self.fill_color = "#FFFFFF"
        self.layer = 0
        self.visible = True
        self.locked = False
        self.rotation = 0
        self.scale = (1.0, 1.0)
        
        # Selection properties
        self.setFlag(QGraphicsItem.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.ItemIsMovable, True)
        self.setFlag(QGraphicsItem.ItemSendsGeometryChanges, True)
        
        # Z-value
        self.setZValue(0)
        
        # New properties for enhanced converter
        self._weaving_pattern = False
        self._thermal_priority = False
        self._ellipse_data = None
        self._rotation_data = None
        self._arc_params = None
        self._is_arc = False
    
    def get_color(self):
        return self.color
    
    def set_color(self, color):
        self.color = color
        self.update()
    
    def get_thickness(self):
        return self.thickness
    
    def set_thickness(self, thickness):
        self.thickness = thickness
        self.update()
    
    def get_fill(self):
        return self.fill
    
    def set_fill(self, fill):
        self.fill = fill
        self.update()
    
    def get_fill_color(self):
        return self.fill_color
    
    def set_fill_color(self, fill_color):
        self.fill_color = fill_color
        self.update()
    
    def get_layer(self):
        return self.layer
    
    def set_layer(self, layer):
        self.layer = layer
        self.update()
    
    def is_visible(self):
        return self.visible
    
    def set_visible(self, visible):
        self.visible = visible
        self.setVisible(visible)
        self.update()
    
    def is_locked(self):
        return self.locked
    
    def set_locked(self, locked):
        self.locked = locked
        self.setFlag(QGraphicsItem.ItemIsMovable, not locked)
        self.setFlag(QGraphicsItem.ItemIsSelectable, not locked)
        self.update()
    
    def get_rotation(self):
        return self.rotation
    
    def set_rotation(self, rotation):
        self.rotation = rotation
        self.setRotation(rotation)
        self.update()
    
    def get_scale(self):
        return self.scale
    
    def set_scale(self, scale):
        self.scale = scale
        if isinstance(scale, tuple):
            self.setTransform(QTransform().scale(scale[0], scale[1]))
        else:
            self.setTransform(QTransform().scale(scale, scale))
        self.update()
    
    def update_properties(self, properties):
        if "color" in properties:
            self.set_color(properties["color"])
        if "thickness" in properties:
            self.set_thickness(properties["thickness"])
        if "fill" in properties:
            self.set_fill(properties["fill"])
        if "fill_color" in properties:
            self.set_fill_color(properties["fill_color"])
        if "layer" in properties:
            self.set_layer(properties["layer"])
        if "visible" in properties:
            self.set_visible(properties["visible"])
        if "locked" in properties:
            self.set_locked(properties["locked"])
        if "rotation" in properties:
            self.set_rotation(properties["rotation"])
        if "scale" in properties:
            self.set_scale(properties["scale"])
    
    def _copy_properties(self, target):
        target.color = self.color
        target.thickness = self.thickness
        target.fill = self.fill
        target.fill_color = self.fill_color
        target.layer = self.layer
        target.visible = self.visible
        target.locked = self.locked
        target.rotation = self.rotation
        target.scale = self.scale
        target.setZValue(self.zValue())
        target.setPos(self.pos())
        target.setRotation(self.rotation)
        target.setTransform(self.transform())
    
    def get_area(self):
        return 0.0
    
    def clone(self):
        raise NotImplementedError("Subclasses must implement clone()")


class Line(Shape):
    def __init__(self, start_point, end_point):
        super().__init__()
        self.start_point = start_point
        self.end_point = end_point
    
    def boundingRect(self):
        x1, y1 = self.start_point.x(), self.start_point.y()
        x2, y2 = self.end_point.x(), self.end_point.y()
        
        min_x = min(x1, x2)
        min_y = min(y1, y2)
        max_x = max(x1, x2)
        max_y = max(y1, y2)
        
        return QRectF(min_x, min_y, max_x - min_x, max_y - min_y).adjusted(
            -self.thickness, -self.thickness, self.thickness, self.thickness)
    
    def paint(self, painter, option, widget):
        pen = QPen(QColor(self.color), self.thickness)
        painter.setPen(pen)
        painter.drawLine(self.start_point, self.end_point)
        
        if self.isSelected():
            painter.setPen(QPen(QColor(0, 0, 255, 100), 1, Qt.DashLine))
            painter.setBrush(QBrush(QColor(0, 0, 255, 50)))
            painter.drawRect(self.boundingRect())
    
    def get_start_point(self):
        return self.start_point
    
    def set_start_point(self, start_point):
        self.start_point = start_point
        self.update()
    
    def get_end_point(self):
        return self.end_point
    
    def set_end_point(self, end_point):
        self.end_point = end_point
        self.update()
    
    def get_area(self):
        return 0.0
    
    def clone(self):
        new_line = Line(QPointF(self.start_point), QPointF(self.end_point))
        self._copy_properties(new_line)
        return new_line


class Circle(Shape):
    def __init__(self, center, radius):
        super().__init__()
        self.center = center
        self.radius = radius
    
    def boundingRect(self):
        return QRectF(
            self.center.x() - self.radius,
            self.center.y() - self.radius,
            2 * self.radius,
            2 * self.radius
        ).adjusted(-self.thickness, -self.thickness, self.thickness, self.thickness)
    
    def paint(self, painter, option, widget):
        pen = QPen(QColor(self.color), self.thickness)
        painter.setPen(pen)
        
        if self.fill:
            brush = QBrush(QColor(self.fill_color))
            painter.setBrush(brush)
        else:
            painter.setBrush(Qt.NoBrush)
        
        painter.drawEllipse(self.center, self.radius, self.radius)
        
        if self.isSelected():
            painter.setPen(QPen(QColor(0, 0, 255, 100), 1, Qt.DashLine))
            painter.setBrush(QBrush(QColor(0, 0, 255, 50)))
            painter.drawRect(self.boundingRect())
    
    def get_center(self):
        return self.center
    
    def set_center(self, center):
        self.center = center
        self.update()
    
    def get_radius(self):
        return self.radius
    
    def set_radius(self, radius):
        self.radius = radius
        self.update()
    
    def get_area(self):
        return math.pi * self.radius * self.radius
    
    def clone(self):
        new_circle = Circle(QPointF(self.center), self.radius)
        self._copy_properties(new_circle)
        return new_circle


class Rectangle(Shape):
    def __init__(self, top_left, bottom_right):
        super().__init__()
        self.top_left = top_left
        self.bottom_right = bottom_right
    
    def boundingRect(self):
        return QRectF(self.top_left, self.bottom_right).normalized().adjusted(
            -self.thickness, -self.thickness, self.thickness, self.thickness)
    
    def paint(self, painter, option, widget):
        pen = QPen(QColor(self.color), self.thickness)
        painter.setPen(pen)
        
        if self.fill:
            brush = QBrush(QColor(self.fill_color))
            painter.setBrush(brush)
        else:
            painter.setBrush(Qt.NoBrush)
        
        rect = QRectF(self.top_left, self.bottom_right).normalized()
        painter.drawRect(rect)
        
        if self.isSelected():
            painter.setPen(QPen(QColor(0, 0, 255, 100), 1, Qt.DashLine))
            painter.setBrush(QBrush(QColor(0, 0, 255, 50)))
            painter.drawRect(self.boundingRect())
    
    def get_top_left(self):
        return self.top_left
    
    def set_top_left(self, top_left):
        self.top_left = top_left
        self.update()
    
    def get_bottom_right(self):
        return self.bottom_right
    
    def set_bottom_right(self, bottom_right):
        self.bottom_right = bottom_right
        self.update()
    
    def get_area(self):
        rect = QRectF(self.top_left, self.bottom_right).normalized()
        return rect.width() * rect.height()
    
    def clone(self):
        new_rect = Rectangle(QPointF(self.top_left), QPointF(self.bottom_right))
        self._copy_properties(new_rect)
        return new_rect


class Polygon(Shape):
    def __init__(self, points):
        super().__init__()
        self.points = points
    
    def boundingRect(self):
        if not self.points:
            return QRectF(0, 0, 0, 0)
        
        min_x = min(p.x() for p in self.points)
        min_y = min(p.y() for p in self.points)
        max_x = max(p.x() for p in self.points)
        max_y = max(p.y() for p in self.points)
        
        return QRectF(min_x, min_y, max_x - min_x, max_y - min_y).adjusted(
            -self.thickness, -self.thickness, self.thickness, self.thickness)
    
    def paint(self, painter, option, widget):
        if len(self.points) < 2:
            return
        
        pen = QPen(QColor(self.color), self.thickness)
        painter.setPen(pen)
        
        if self.fill:
            brush = QBrush(QColor(self.fill_color))
            painter.setBrush(brush)
        else:
            painter.setBrush(Qt.NoBrush)
        
        polygon = QPolygonF(self.points)
        painter.drawPolygon(polygon)
        
        if self.isSelected():
            painter.setPen(QPen(QColor(0, 0, 255, 100), 1, Qt.DashLine))
            painter.setBrush(QBrush(QColor(0, 0, 255, 50)))
            painter.drawRect(self.boundingRect())
    
    def get_points(self):
        return self.points
    
    def set_points(self, points):
        self.points = points
        self.update()
    
    def add_point(self, point):
        self.points.append(point)
        self.update()
    
    def get_area(self):
        if len(self.points) < 3:
            return 0.0
        area = 0.0
        for i in range(len(self.points)):
            j = (i + 1) % len(self.points)
            area += self.points[i].x() * self.points[j].y()
            area -= self.points[j].x() * self.points[i].y()
        return abs(area) / 2.0
    
    def clone(self):
        new_polygon = Polygon([QPointF(p) for p in self.points])
        self._copy_properties(new_polygon)
        return new_polygon


class Text(Shape):
    """Enhanced Text shape with proper selection, movement, and scaling."""
    
    def __init__(self, position, text):
        super().__init__()
        self.text = text
        self.font = "Arial"
        self.font_size = 12
        self._scale_factor = 1.0
        
        # Create text item as child
        self.text_item = QGraphicsTextItem(text, self)
        self.text_item.setPos(0, 0)  # Position relative to parent
        self.text_item.setFont(QFont(self.font, self.font_size))
        self.text_item.setDefaultTextColor(QColor(self.color))
        
        # Make text item interactive
        self.text_item.setFlag(QGraphicsItem.ItemIsSelectable, False)  # Parent handles selection
        self.text_item.setFlag(QGraphicsItem.ItemIsMovable, False)  # Parent handles movement
        
        # Set position
        self.setPos(position)
    
    def boundingRect(self):
        return self.text_item.boundingRect()
    
    def paint(self, painter, option, widget):
        # Text is drawn by the text_item child
        # Draw selection rectangle if selected
        if self.isSelected():
            painter.setPen(QPen(QColor(0, 0, 255, 150), 2, Qt.DashLine))
            painter.setBrush(QBrush(QColor(0, 0, 255, 30)))
            painter.drawRect(self.boundingRect())
            
            # Draw resize handles
            rect = self.boundingRect()
            handle_size = 8
            handles = [
                rect.topLeft(),
                rect.topRight(),
                rect.bottomLeft(),
                rect.bottomRight(),
                QPointF(rect.center().x(), rect.top()),
                QPointF(rect.center().x(), rect.bottom()),
                QPointF(rect.left(), rect.center().y()),
                QPointF(rect.right(), rect.center().y())
            ]
            
            painter.setBrush(QBrush(QColor(0, 0, 255)))
            for handle in handles:
                painter.drawRect(
                    handle.x() - handle_size/2,
                    handle.y() - handle_size/2,
                    handle_size,
                    handle_size
                )
    
    def get_text(self):
        return self.text
    
    def set_text(self, text):
        self.text = text
        self.text_item.setPlainText(text)
        self.update()
    
    def get_font(self):
        return self.font
    
    def set_font(self, font):
        self.font = font
        self.text_item.setFont(QFont(font, int(self.font_size * self._scale_factor)))
        self.update()
    
    def get_font_size(self):
        return self.font_size
    
    def set_font_size(self, font_size):
        self.font_size = font_size
        self.text_item.setFont(QFont(self.font, int(font_size * self._scale_factor)))
        self.update()
    
    def set_scale(self, scale):
        """Override scale to properly scale text."""
        if isinstance(scale, tuple):
            self._scale_factor = (scale[0] + scale[1]) / 2
        else:
            self._scale_factor = scale
        
        # Update font size based on scale
        self.text_item.setFont(QFont(self.font, int(self.font_size * self._scale_factor)))
        super().set_scale(scale)
    
    def set_color(self, color):
        """Override to update text color."""
        self.color = color
        self.text_item.setDefaultTextColor(QColor(color))
        self.update()
    
    def itemChange(self, change, value):
        """Handle item changes to keep text_item synchronized."""
        if change == QGraphicsItem.ItemPositionChange:
            # Position is handled by parent, no need to update text_item
            pass
        return super().itemChange(change, value)
    
    def update_properties(self, properties):
        super().update_properties(properties)
        
        if "text" in properties:
            self.set_text(properties["text"])
        if "font" in properties:
            self.set_font(properties["font"])
        if "font_size" in properties:
            self.set_font_size(properties["font_size"])
        if "color" in properties:
            self.set_color(properties["color"])
    
    def clone(self):
        new_text = Text(self.pos(), self.text)
        self._copy_properties(new_text)
        # Copy text-specific properties
        new_text.font = self.font
        new_text.font_size = self.font_size
        new_text._scale_factor = self._scale_factor
        new_text.text_item.setFont(QFont(new_text.font, int(new_text.font_size * new_text._scale_factor)))
        new_text.text_item.setDefaultTextColor(QColor(new_text.color))
        return new_text


class Polyline(Shape):
    def __init__(self, points):
        super().__init__()
        self.points = points
        self._is_arc = False
        self._arc_params = None
    
    def boundingRect(self):
        if not self.points:
            return QRectF(0, 0, 0, 0)
        
        min_x = min(p.x() for p in self.points)
        min_y = min(p.y() for p in self.points)
        max_x = max(p.x() for p in self.points)
        max_y = max(p.y() for p in self.points)
        
        return QRectF(min_x, min_y, max_x - min_x, max_y - min_y).adjusted(
            -self.thickness, -self.thickness, self.thickness, self.thickness)
    
    def paint(self, painter, option, widget):
        if len(self.points) < 2:
            return
        
        pen = QPen(QColor(self.color), self.thickness)
        painter.setPen(pen)
        
        path = QPainterPath()
        path.moveTo(self.points[0])
        for point in self.points[1:]:
            path.lineTo(point)
        
        painter.drawPath(path)
        
        if self.isSelected():
            painter.setPen(QPen(QColor(0, 0, 255, 100), 1, Qt.DashLine))
            painter.setBrush(QBrush(QColor(0, 0, 255, 50)))
            painter.drawRect(self.boundingRect())
    
    def get_points(self):
        return self.points
    
    def set_points(self, points):
        self.points = points
        self.update()
    
    def add_point(self, point):
        self.points.append(point)
        self.update()
    
    def get_area(self):
        return 0.0
    
    def clone(self):
        new_polyline = Polyline([QPointF(p) for p in self.points])
        self._copy_properties(new_polyline)
        return new_polyline


class Bezier(Shape):
    def __init__(self, points):
        super().__init__()
        self.points = points  # Should have 4 points: start, control1, control2, end
    
    def boundingRect(self):
        if len(self.points) < 4:
            return QRectF(0, 0, 0, 0)
        
        min_x = min(p.x() for p in self.points)
        min_y = min(p.y() for p in self.points)
        max_x = max(p.x() for p in self.points)
        max_y = max(p.y() for p in self.points)
        
        return QRectF(min_x, min_y, max_x - min_x, max_y - min_y).adjusted(
            -self.thickness, -self.thickness, self.thickness, self.thickness)
    
    def paint(self, painter, option, widget):
        if len(self.points) < 4:
            return
        
        pen = QPen(QColor(self.color), self.thickness)
        painter.setPen(pen)
        
        path = QPainterPath()
        path.moveTo(self.points[0])
        path.cubicTo(self.points[1], self.points[2], self.points[3])
        
        painter.drawPath(path)
        
        if self.isSelected():
            # Draw control points
            painter.setPen(QPen(QColor(255, 0, 0), 1))
            for point in self.points:
                painter.drawEllipse(point, 3, 3)
            
            # Draw control lines
            painter.setPen(QPen(QColor(255, 0, 0, 100), 1, Qt.DashLine))
            painter.drawLine(self.points[0], self.points[1])
            painter.drawLine(self.points[2], self.points[3])
            
            # Draw selection rectangle
            painter.setPen(QPen(QColor(0, 0, 255, 100), 1, Qt.DashLine))
            painter.setBrush(QBrush(QColor(0, 0, 255, 50)))
            painter.drawRect(self.boundingRect())
    
    def get_points(self):
        return self.points
    
    def set_points(self, points):
        self.points = points
        self.update()
    
    def get_area(self):
        return 0.0
    
    def clone(self):
        new_bezier = Bezier([QPointF(p) for p in self.points])
        self._copy_properties(new_bezier)
        return new_bezier
