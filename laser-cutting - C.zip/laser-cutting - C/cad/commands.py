# cad/commands_fixed.py - Enhanced Command Pattern Implementation
from abc import ABC, abstractmethod

class Command(ABC):
    """Base class for all commands."""
    
    @abstractmethod
    def execute(self):
        """Execute the command."""
        pass
    
    @abstractmethod
    def undo(self):
        """Undo the command."""
        pass


class AddShapeCommand(Command):
    """Command to add a shape to the canvas."""
    
    def __init__(self, editor, shape, scene=None):
        self.editor = editor
        self.shape = shape
        self.scene = scene
    
    def execute(self):
        """Add shape to editor and scene."""
        if self.shape not in self.editor.shapes:
            self.editor.shapes.append(self.shape)
        if self.scene and self.shape.scene() != self.scene:
            self.scene.addItem(self.shape)
            # Handle Text shapes specially
            if hasattr(self.shape, 'text_item'):
                self.shape.text_item.setVisible(True)
    
    def undo(self):
        """Remove shape from editor and scene."""
        if self.shape in self.editor.shapes:
            self.editor.shapes.remove(self.shape)
        if self.scene and self.shape.scene() == self.scene:
            # Handle Text shapes specially
            if hasattr(self.shape, 'text_item') and self.shape.text_item.scene() == self.scene:
                self.scene.removeItem(self.shape.text_item)
            self.scene.removeItem(self.shape)


class DeleteShapeCommand(Command):
    """Command to delete a shape from the canvas."""
    
    def __init__(self, editor, shape, scene=None):
        self.editor = editor
        self.shape = shape
        self.scene = scene
    
    def execute(self):
        """Remove shape from editor and scene."""
        if self.shape in self.editor.shapes:
            self.editor.shapes.remove(self.shape)
        if self.scene and self.shape.scene() == self.scene:
            # Handle Text shapes specially
            if hasattr(self.shape, 'text_item') and self.shape.text_item.scene() == self.scene:
                self.scene.removeItem(self.shape.text_item)
            self.scene.removeItem(self.shape)
    
    def undo(self):
        """Add shape back to editor and scene."""
        if self.shape not in self.editor.shapes:
            self.editor.shapes.append(self.shape)
        if self.scene and self.shape.scene() != self.scene:
            self.scene.addItem(self.shape)
            # Handle Text shapes specially
            if hasattr(self.shape, 'text_item'):
                self.shape.text_item.setVisible(True)


class MoveShapeCommand(Command):
    """Command to move a shape."""
    
    def __init__(self, shape, old_pos, new_pos):
        self.shape = shape
        self.old_pos = old_pos
        self.new_pos = new_pos
    
    def execute(self):
        """Move shape to new position."""
        self.shape.setPos(self.new_pos)
        # Update text item position if it's a Text shape
        if hasattr(self.shape, 'text_item'):
            self.shape.text_item.setPos(self.new_pos)
    
    def undo(self):
        """Move shape back to old position."""
        self.shape.setPos(self.old_pos)
        # Update text item position if it's a Text shape
        if hasattr(self.shape, 'text_item'):
            self.shape.text_item.setPos(self.old_pos)


class ModifyShapeCommand(Command):
    """Command to modify shape properties."""
    
    def __init__(self, shape, old_props, new_props):
        self.shape = shape
        self.old_props = old_props
        self.new_props = new_props
    
    def execute(self):
        """Apply new properties."""
        self._apply_properties(self.new_props)
    
    def undo(self):
        """Restore old properties."""
        self._apply_properties(self.old_props)
    
    def _apply_properties(self, props):
        """Helper to apply properties to shape."""
        for key, value in props.items():
            if key == "x":
                self.shape.setPos(value, self.shape.pos().y())
            elif key == "y":
                self.shape.setPos(self.shape.pos().x(), value)
            elif key == "color":
                self.shape.set_color(value)
            elif key == "thickness":
                self.shape.set_thickness(value)
            elif key == "text":
                if hasattr(self.shape, 'set_text'):
                    self.shape.set_text(value)
            elif key == "font":
                if hasattr(self.shape, 'set_font'):
                    self.shape.set_font(value)
            elif key == "font_size":
                if hasattr(self.shape, 'set_font_size'):
                    self.shape.set_font_size(value)
            elif key == "fill":
                self.shape.set_fill(value)
            elif key == "fill_color":
                self.shape.set_fill_color(value)
        self.shape.update()


class RotateShapeCommand(Command):
    """Command to rotate a shape."""
    
    def __init__(self, shape, old_rotation, new_rotation):
        self.shape = shape
        self.old_rotation = old_rotation
        self.new_rotation = new_rotation
    
    def execute(self):
        """Rotate shape to new angle."""
        self.shape.set_rotation(self.new_rotation)
    
    def undo(self):
        """Rotate shape back to old angle."""
        self.shape.set_rotation(self.old_rotation)


class ScaleShapeCommand(Command):
    """Command to scale a shape."""
    
    def __init__(self, shape, old_scale, new_scale):
        self.shape = shape
        self.old_scale = old_scale
        self.new_scale = new_scale
    
    def execute(self):
        """Scale shape to new size."""
        self.shape.set_scale(self.new_scale)
    
    def undo(self):
        """Scale shape back to old size."""
        self.shape.set_scale(self.old_scale)
