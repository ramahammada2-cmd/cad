import cv2
import numpy as np
from PIL import Image
from shapely.geometry import Polygon, LineString, Point
from cad.shapes import Line, Circle, Rectangle, Polygon as CADPolygon, Polyline, Bezier
from PyQt5.QtCore import QPointF
from typing import List, Dict, Tuple, Optional, Union
import math
from collections import defaultdict
import time
from scipy import optimize
from scipy.signal import savgol_filter
from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score

class EnhancedImageToVectorConverter:
    """Enhanced image-to-vector converter with improved quality for decorative patterns."""
    
    def __init__(self):
        # Core processing parameters optimized for decorative patterns
        self.min_contour_area = 2  # Lowered for better small detail detection
        self.approximation_accuracy = 0.002  # Much more accurate for fine details
        self.min_circle_radius = 2  # Lowered for small pattern elements
        self.max_circle_error = 0.2  # Stricter for accuracy
        self.bezier_error_threshold = 0.5  # Maximum error for Bézier fitting
        self.max_bezier_control_points = 4  # Maximum control points per curve
        
        # Multi-scale processing parameters
        self.scale_levels = [1.0, 0.75, 0.5, 0.25]  # Multiple resolution levels
        self.scale_weights = [0.4, 0.3, 0.2, 0.1]  # Weights for combining scales
        
        # Quality assessment parameters
        self.quality_thresholds = {
            'excellent': 0.9,
            'good': 0.75,
            'acceptable': 0.6,
            'poor': 0.4
        }
        
        # Pattern recognition parameters
        self.pattern_confidence_threshold = 0.7
        self.symmetry_tolerance = 0.1  # 10% deviation for symmetry detection
        
        # Enhanced contour analysis
        self.contour_smoothing_kernel = 3
        self.edge_sensitivity = 0.3
        self.min_edge_strength = 0.1
        
        # Laser cutting specific attributes (preserved from original)
        self.laser_settings = {
            'kerf_width': 0.1,
            'power': 80,
            'speed': 1000,
            'passes': 1,
            'kerf_compensation': True,
            'cut_order_optimization': True,
            'thermal_management': True,
            'gap_detection': True,
            'pattern_recognition': True
        }
        
        # Material database (preserved)
        self.material_db = {
            'plywood': {
                'kerf_width': 0.15,
                'power': 70,
                'speed': 1200,
                'thickness': 6,
                'min_feature_size': 2.0,
                'thermal_limit': 200
            },
            'acrylic': {
                'kerf_width': 0.1,
                'power': 80,
                'speed': 800,
                'thickness': 3,
                'min_feature_size': 1.5,
                'thermal_limit': 150
            },
            'metal': {
                'kerf_width': 0.05,
                'power': 95,
                'speed': 500,
                'thickness': 2,
                'min_feature_size': 0.5,
                'thermal_limit': 300
            },
            'cardboard': {
                'kerf_width': 0.2,
                'power': 50,
                'speed': 2000,
                'thickness': 1,
                'min_feature_size': 3.0,
                'thermal_limit': 100
            }
        }
        
        # Enhanced pattern types with confidence scoring
        self.pattern_types = {
            'honeycomb': self._detect_honeycomb_pattern,
            'geometric': self._detect_geometric_pattern,
            'textured': self._detect_textured_pattern,
            'organic': self._detect_organic_pattern,
            'interwoven': self._detect_interwoven_pattern,
            'celtic_knot': self._detect_celtic_knot_pattern,
            'mandala': self._detect_mandala_pattern
        }
        
        # Quality tracking
        self.conversion_stats = {
            'total_processing_time': 0,
            'images_processed': 0,
            'average_quality_score': 0,
            'pattern_detection_accuracy': {}
        }

    def convert_image(self, file_path: str) -> Tuple[List, Dict]:
        """
        Enhanced image-to-vector conversion with multi-scale processing and pattern awareness.
        
        Args:
            file_path: Path to the input image
            
        Returns:
            Tuple of (shapes, quality_report)
        """
        start_time = time.time()
        
        # Load and validate image
        image = cv2.imread(file_path)
        if image is None:
            raise ValueError(f"Failed to load image: {file_path}")
        
        height, width = image.shape[:2]
        
        # Multi-scale processing for comprehensive feature detection
        multi_scale_results = []
        for scale in self.scale_levels:
            if scale == 1.0:
                scaled_image = image.copy()
            else:
                new_width = int(width * scale)
                new_height = int(height * scale)
                scaled_image = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)
            
            # Process at this scale
            scale_result = self._process_single_scale(scaled_image, scale)
            multi_scale_results.append(scale_result)
        
        # Combine results from all scales
        combined_shapes = self._combine_multi_scale_results(multi_scale_results)
        
        # Pattern-aware post-processing
        pattern_analysis = self._analyze_decorative_patterns(image)
        optimized_shapes = self._apply_pattern_specific_optimization(combined_shapes, pattern_analysis)
        
        # Quality assessment
        quality_report = self._assess_vectorization_quality(optimized_shapes, image, pattern_analysis)
        
        # Update statistics
        processing_time = time.time() - start_time
        self.conversion_stats['total_processing_time'] += processing_time
        self.conversion_stats['images_processed'] += 1
        
        return optimized_shapes, quality_report
    
    def _combine_multi_scale_results(self, multi_scale_results: List[Dict]) -> List:
        """Combine results from multiple scales using weighted fusion."""
        all_shapes = []
        shape_weights = []
        
        for result in multi_scale_results:
            shapes = result['shapes']
            scale = result['scale']
            weight = self.scale_weights[self.scale_levels.index(scale)]
            
            for shape in shapes:
                all_shapes.append(shape)
                shape_weights.append(weight)
        
        # Remove duplicates and merge overlapping shapes
        merged_shapes = self._merge_similar_shapes(all_shapes, shape_weights)
        
        return merged_shapes
    
    def _merge_similar_shapes(self, shapes: List, weights: List[float]) -> List:
        """Merge similar or overlapping shapes to reduce fragmentation."""
        if len(shapes) <= 1:
            return shapes
        
        merged = []
        used = set()
        
        for i, shape1 in enumerate(shapes):
            if i in used:
                continue
                
            # Find similar shapes
            similar_indices = [i]
            for j, shape2 in enumerate(shapes[i+1:], i+1):
                if j in used:
                    continue
                    
                similarity = self._calculate_shape_similarity(shape1, shape2)
                if similarity > 0.8:  # High similarity threshold
                    similar_indices.append(j)
                    used.add(j)
            
            if len(similar_indices) > 1:
                # Merge similar shapes
                merged_shape = self._merge_shape_group([shapes[idx] for idx in similar_indices])
                merged.append(merged_shape)
            else:
                merged.append(shape1)
            
            used.add(i)
        
        return merged
    
    def _calculate_shape_similarity(self, shape1, shape2) -> float:
        """Calculate similarity between two shapes."""
        # Simplified similarity based on bounding box overlap
        if not (hasattr(shape1, 'get_bounds') and hasattr(shape2, 'get_bounds')):
            return 0.0
        
        bounds1 = shape1.get_bounds()
        bounds2 = shape2.get_bounds()
        
        # Calculate intersection
        x1 = max(bounds1[0], bounds2[0])
        y1 = max(bounds1[1], bounds2[1])
        x2 = min(bounds1[2], bounds2[2])
        y2 = min(bounds1[3], bounds2[3])
        
        if x2 <= x1 or y2 <= y1:
            return 0.0  # No overlap
        
        intersection = (x2 - x1) * (y2 - y1)
        
        # Calculate union
        area1 = (bounds1[2] - bounds1[0]) * (bounds1[3] - bounds1[1])
        area2 = (bounds2[2] - bounds2[0]) * (bounds2[3] - bounds2[1])
        union = area1 + area2 - intersection
        
        return intersection / union if union > 0 else 0.0
    
    def _merge_shape_group(self, shapes: List) -> object:
        """Merge a group of similar shapes into one."""
        # For now, return the largest shape in the group
        # Future: Implement proper shape union
        largest_shape = max(shapes, key=lambda s: self._calculate_shape_area(s))
        return largest_shape
    
    def _calculate_shape_area(self, shape) -> float:
        """Calculate area of a shape."""
        if hasattr(shape, 'get_area'):
            return shape.get_area()
        elif hasattr(shape, 'get_bounds'):
            bounds = shape.get_bounds()
            return (bounds[2] - bounds[0]) * (bounds[3] - bounds[1])
        else:
            return 1.0  # Default area
    
    def _analyze_decorative_patterns(self, image: np.ndarray) -> Dict:
        """Analyze image to identify decorative pattern types."""
        pattern_results = {}
        
        for pattern_name, pattern_func in self.pattern_types.items():
            try:
                result = pattern_func(image)
                if result['confidence'] > self.pattern_confidence_threshold:
                    pattern_results[pattern_name] = result
            except Exception as e:
                print(f"Error detecting {pattern_name} pattern: {e}")
        
        # Determine dominant pattern type
        if pattern_results:
            dominant_pattern = max(pattern_results.items(), 
                                 key=lambda x: x[1]['confidence'])[0]
        else:
            dominant_pattern = 'geometric'  # Default fallback
        
        return {
            'detected_patterns': pattern_results,
            'dominant_pattern': dominant_pattern,
            'pattern_count': len(pattern_results),
            'confidence_scores': {name: result['confidence'] for name, result in pattern_results.items()}
        }
    
    def _apply_pattern_specific_optimization(self, shapes: List, pattern_analysis: Dict) -> List:
        """Apply pattern-specific optimization to shapes."""
        dominant_pattern = pattern_analysis['dominant_pattern']
        
        if dominant_pattern == 'organic':
            return self._optimize_for_organic_patterns(shapes)
        elif dominant_pattern == 'celtic_knot':
            return self._optimize_for_celtic_knots(shapes)
        elif dominant_pattern == 'geometric':
            return self._optimize_for_geometric_patterns(shapes)
        elif dominant_pattern == 'interwoven':
            return self._optimize_for_interwoven_patterns(shapes)
        else:
            return shapes
    
    def _optimize_for_organic_patterns(self, shapes: List) -> List:
        """Optimize shapes for organic/curved patterns."""
        optimized = []
        
        for shape in shapes:
            if hasattr(shape, 'get_points'):
                points = shape.get_points()
                if len(points) > 3:
                    # Try to fit Bézier curves
                    bezier_shape = self._fit_bezier_curves_to_shape(shape)
                    if bezier_shape:
                        optimized.append(bezier_shape)
                    else:
                        optimized.append(shape)
                else:
                    optimized.append(shape)
            else:
                optimized.append(shape)
        
        return optimized
    
    def _fit_bezier_curves_to_shape(self, shape) -> Optional[Bezier]:
        """Fit Bézier curves to a shape's points."""
        if not hasattr(shape, 'get_points'):
            return None
        
        points = shape.get_points()
        if len(points) < 4:
            return None
        
        # Simplify points for Bézier fitting
        simplified_points = self._adaptive_point_reduction(points)
        
        if len(simplified_points) < 4:
            return None
        
        # Fit cubic Bézier curves
        bezier_curves = []
        for i in range(0, len(simplified_points) - 1, 3):
            if i + 3 < len(simplified_points):
                curve_points = simplified_points[i:i+4]
                try:
                    control_points = self._fit_single_bezier_curve(curve_points)
                    if control_points:
                        bezier_curves.extend(control_points)
                except:
                    # Fall back to original points if Bézier fitting fails
                    return None
        
        if len(bezier_curves) >= 4:
            return Bezier(bezier_curves[:4])  # Use first 4 points for now
        
        return None
    
    def _fit_single_bezier_curve(self, points: List[QPointF]) -> Optional[List[QPointF]]:
        """Fit a single Bézier curve to 4 points."""
        if len(points) != 4:
            return None
        
        try:
            # Use the points as control points with some optimization
            # This is a simplified approach - could be enhanced with proper curve fitting
            
            # Apply Catmull-Rom to Bézier conversion for better results
            optimized_points = self._catmull_rom_to_bezier(points)
            return optimized_points
        except:
            return None
    
    def _catmull_rom_to_bezier(self, points: List[QPointF]) -> List[QPointF]:
        """Convert Catmull-Rom spline points to Bézier control points."""
        if len(points) < 4:
            return points
        
        # Catmull-Rom to Bézier conversion
        bezier_points = [points[0]]  # Start point
        
        for i in range(1, len(points) - 2):
            p0 = points[i-1]
            p1 = points[i]
            p2 = points[i+1]
            p3 = points[i+2]
            
            # Calculate Bézier control points
            c1 = QPointF(
                p1.x() + (p2.x() - p0.x()) / 6,
                p1.y() + (p2.y() - p0.y()) / 6
            )
            c2 = QPointF(
                p2.x() - (p3.x() - p1.x()) / 6,
                p2.y() - (p3.y() - p1.y()) / 6
            )
            
            bezier_points.extend([c1, c2, p2])
        
        bezier_points.append(points[-1])  # End point
        return bezier_points[:4]  # Return exactly 4 points
    
    def _adaptive_point_reduction(self, points: List[QPointF], tolerance: float = 2.0) -> List[QPointF]:
        """Adaptively reduce points while preserving important features."""
        if len(points) <= 4:
            return points
        
        # Use Douglas-Peucker algorithm for point reduction
        simplified = self._douglas_peucker(points, tolerance)
        
        # Ensure we have at least 4 points for Bézier fitting
        if len(simplified) < 4:
            # Interpolate additional points
            return self._interpolate_points(simplified, 4)
        
        return simplified
    
    def _douglas_peucker(self, points: List[QPointF], tolerance: float) -> List[QPointF]:
        """Douglas-Peucker algorithm for line simplification."""
        if len(points) <= 2:
            return points
        
        # Find the point with maximum distance from line between first and last points
        first_point = points[0]
        last_point = points[-1]
        
        max_distance = 0
        max_index = 0
        
        for i in range(1, len(points) - 1):
            distance = self._point_to_line_distance(points[i], first_point, last_point)
            if distance > max_distance:
                max_distance = distance
                max_index = i
        
        # If max distance is greater than tolerance, recursively simplify
        if max_distance > tolerance:
            # Recursive call
            left_results = self._douglas_peucker(points[:max_index + 1], tolerance)
            right_results = self._douglas_peucker(points[max_index:], tolerance)
            
            # Combine results (remove duplicate point at junction)
            return left_results[:-1] + right_results
        else:
            # All points can be approximated by the line
            return [first_point, last_point]
    
    def _point_to_line_distance(self, point: QPointF, line_start: QPointF, line_end: QPointF) -> float:
        """Calculate perpendicular distance from point to line segment."""
        x0, y0 = point.x(), point.y()
        x1, y1 = line_start.x(), line_start.y()
        x2, y2 = line_end.x(), line_end.y()
        
        # Calculate distance using cross product formula
        numerator = abs((y2 - y1) * x0 - (x2 - x1) * y0 + x2 * y1 - y2 * x1)
        denominator = math.sqrt((y2 - y1)**2 + (x2 - x1)**2)
        
        return numerator / denominator if denominator > 0 else 0
    
    def _interpolate_points(self, points: List[QPointF], target_count: int) -> List[QPointF]:
        """Interpolate points to reach target count."""
        if len(points) >= target_count:
            return points
        
        # Simple linear interpolation
        interpolated = []
        for i in range(len(points) - 1):
            interpolated.append(points[i])
            
            # Calculate how many points to add between this pair
            points_to_add = max(0, (target_count - len(points)) // (len(points) - 1))
            
            for j in range(1, points_to_add + 1):
                t = j / (points_to_add + 1)
                x = points[i].x() + t * (points[i+1].x() - points[i].x())
                y = points[i].y() + t * (points[i+1].y() - points[i].y())
                interpolated.append(QPointF(x, y))
        
        interpolated.append(points[-1])
        return interpolated[:target_count]
    
    def _optimize_for_celtic_knots(self, shapes: List) -> List:
        """Optimize shapes for Celtic knot patterns."""
        # Celtic knots require special handling for interweaving
        # For now, enhance the existing shapes
        optimized = []
        for shape in shapes:
            if hasattr(shape, 'get_bounds'):
                # Apply weaving-aware optimization
                enhanced_shape = self._apply_weaving_enhancement(shape)
                optimized.append(enhanced_shape)
            else:
                optimized.append(shape)
        
        return optimized
    
    def _apply_weaving_enhancement(self, shape) -> object:
        """Apply weaving pattern enhancements to shapes."""
        # Mark shape as part of interwoven pattern
        if hasattr(shape, 'set_weaving_pattern'):
            shape.set_weaving_pattern(True)
        
        return shape
    
    def _optimize_for_geometric_patterns(self, shapes: List) -> List:
        """Optimize shapes for geometric patterns."""
        # Geometric patterns benefit from straight line detection
        optimized = []
        for shape in shapes:
            if hasattr(shape, 'get_points'):
                points = shape.get_points()
                if len(points) > 4:
                    # Straighten lines while preserving corners
                    straightened = self._straighten_geometric_lines(points)
                    if len(straightened) > 0:
                        new_shape = Polyline(straightened)
                        new_shape.set_fill(shape.get_fill())
                        optimized.append(new_shape)
                    else:
                        optimized.append(shape)
                else:
                    optimized.append(shape)
            else:
                optimized.append(shape)
        
        return optimized
    
    def _straighten_geometric_lines(self, points: List[QPointF]) -> List[QPointF]:
        """Straighten lines while preserving important vertices."""
        if len(points) < 3:
            return points
        
        straightened = [points[0]]
        
        for i in range(1, len(points) - 1):
            prev_point = points[i - 1]
            current_point = points[i]
            next_point = points[i + 1]
            
            # Calculate angles
            angle1 = math.atan2(current_point.y() - prev_point.y(), 
                              current_point.x() - prev_point.x())
            angle2 = math.atan2(next_point.y() - current_point.y(), 
                              next_point.x() - current_point.x())
            
            # Check if this is a corner (significant angle change)
            angle_diff = abs(angle2 - angle1)
            if angle_diff > 0.2:  # Threshold for corner detection
                straightened.append(current_point)
        
        straightened.append(points[-1])
        return straightened
    
    def _optimize_for_interwoven_patterns(self, shapes: List) -> List:
        """Optimize shapes for interwoven patterns."""
        # Interwoven patterns need continuity preservation
        # Sort shapes by connectivity for better processing order
        sorted_shapes = self._sort_by_connectivity(shapes)
        return sorted_shapes
    
    def _sort_by_connectivity(self, shapes: List) -> List:
        """Sort shapes by their connectivity for optimal processing."""
        # Simple connectivity-based sorting
        # Could be enhanced with proper graph analysis
        return shapes  # For now, return unchanged
    
    def _process_single_scale(self, image: np.ndarray, scale: float) -> Dict:
        """Process image at a single scale level."""
        # Enhanced preprocessing
        preprocessed = self._enhanced_preprocessing(image)
        
        # Pattern-agnostic contour detection
        contours, hierarchy = self._find_enhanced_contours(preprocessed)
        
        # Convert to shapes with Bézier curve support
        scale_shapes = []
        for i, contour in enumerate(contours):
            area = cv2.contourArea(contour)
            if area < self.min_contour_area * (scale ** 2):  # Scale-aware area threshold
                continue
            
            is_hole = self._is_hole_contour(i, hierarchy)
            shape = self.contour_to_shape(contour, is_hole, scale) # Corrected method name
            if shape:
                scale_shapes.append(shape)
        
        return {
            'shapes': scale_shapes,
            'scale': scale,
            'contour_count': len(contours),
            'image_size': image.shape[:2]
        }
    
    def _enhanced_preprocessing(self, image: np.ndarray) -> np.ndarray:
        """Enhanced preprocessing with adaptive filtering."""
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Multi-stage denoising while preserving edges
        # Stage 1: Bilateral filter for edge-preserving smoothing
        denoised = cv2.bilateralFilter(gray, 9, 75, 75)
        
        # Stage 2: Adaptive histogram equalization for contrast enhancement
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(denoised)
        
        # Stage 3: Edge-aware sharpening
        kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
        sharpened = cv2.filter2D(enhanced, -1, kernel)
        
        # Adaptive thresholding based on local image characteristics
        binary = self._adaptive_threshold(sharpened)
        
        return binary
    
    def _adaptive_threshold(self, gray: np.ndarray) -> np.ndarray:
        """Adaptive thresholding for different image types."""
        # Analyze image characteristics
        is_line_art = self._analyze_image_type(gray)
        
        if is_line_art:
            # For line art, use Otsu thresholding with custom post-processing
            _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
            
            # Minimal morphological operations for line art
            kernel = np.ones((2, 2), np.uint8)
            binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=1)
            
        else:
            # For filled shapes, use adaptive thresholding
            binary = cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
            )
            
            # More aggressive morphological operations
            kernel = np.ones((3, 3), np.uint8)
            binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=2)
            binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel, iterations=1)
        
        return binary
    
    def _find_enhanced_contours(self, binary: np.ndarray) -> Tuple[List, np.ndarray]:
        """Enhanced contour finding with improved hierarchy analysis."""
        # Find contours with external hierarchy for better parent-child relationships
        contours, hierarchy = cv2.findContours(
            binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE
        )
        
        # Post-process contours for quality
        enhanced_contours = []
        for contour in contours:
            # Smooth contours to remove noise
            smoothed = self._smooth_contour(contour)
            
            # Remove duplicate points
            deduped = self._remove_duplicate_points(smoothed)
            
            if len(deduped) >= 3:  # Minimum points for a valid contour
                enhanced_contours.append(deduped)
        
        return enhanced_contours, hierarchy
    
    def _smooth_contour(self, contour: np.ndarray) -> np.ndarray:
        """Smooth contour while preserving important features."""
        if len(contour) < 5:
            return contour
        
        # Apply Savitzky-Golay filter for smooth approximation
        try:
            # Prepare data for smoothing
            points = contour.reshape(-1, 2)
            
            # Separate x and y coordinates
            x = points[:, 0]
            y = points[:, 1]
            
            # Apply smoothing with appropriate window length
            window_length = min(5, len(x) if len(x) % 2 == 1 else len(x) - 1)
            if window_length >= 3:
                x_smooth = savgol_filter(x, window_length, 2)
                y_smooth = savgol_filter(y, window_length, 2)
                
                smoothed_points = np.column_stack([x_smooth, y_smooth])
                return smoothed_points.reshape(-1, 1, 2)
        except:
            pass  # Fall back to original contour if smoothing fails
        
        return contour
    
    def _remove_duplicate_points(self, contour: np.ndarray) -> np.ndarray:
        """Remove duplicate and near-duplicate points from contour."""
        if len(contour) < 3:
            return contour
        
        points = contour.reshape(-1, 2)
        unique_points = [points[0]]
        
        for i in range(1, len(points)):
            current_point = points[i]
            last_point = unique_points[-1]
            
            # Calculate distance to last point
            distance = np.sqrt((current_point[0] - last_point[0])**2 + 
                             (current_point[1] - last_point[1])**2)
            
            # Keep point if it's far enough from the last one
            if distance > 1.0:  # Minimum distance threshold
                unique_points.append(current_point)
        
        if len(unique_points) >= 3:
            return np.array(unique_points).reshape(-1, 1, 2)
        else:
            return contour

    def contour_to_shape(self, contour, is_hole=False, is_line_contour=False):
        """Enhanced contour to shape conversion with improved shape detection.
        
        Args:
            contour: OpenCV contour
            is_hole: Whether this contour represents a hole
            is_line_contour: Whether this contour represents line art
        """
        # Convert OpenCV contour to CAD shape
        points = [QPointF(point[0][0], point[0][1]) for point in contour]
        
        if len(points) < 2:
            return None

        # Try to detect different shape types in order of specificity
        
        # 1. Check for circles first
        if self.is_circle(contour):
            center, radius = cv2.minEnclosingCircle(contour)
            center_qt = QPointF(center[0], center[1])
            if radius >= self.min_circle_radius:
                circle = Circle(center_qt, radius)
                circle.set_fill(not is_hole and not is_line_contour)
                return circle
        
        # 2. Check for ellipses (if not a circle and has enough points)
        if len(contour) >= 5 and self.is_ellipse(contour):
            ellipse_params = cv2.fitEllipse(contour)
            center_qt = QPointF(ellipse_params[0][0], ellipse_params[0][1])
            # Extract axes lengths and angle
            (center, axes, angle) = ellipse_params
            major_axis = max(axes) / 2
            minor_axis = min(axes) / 2
            
            # For ellipses, create a circle with ellipse data stored
            # (can be enhanced with proper ellipse support later)
            if major_axis >= self.min_circle_radius:
                circle = Circle(center_qt, major_axis)
                circle.set_fill(not is_hole and not is_line_contour)
                # Store ellipse data for potential future enhancement
                circle.ellipse_data = {
                    'center': center,
                    'major_axis': major_axis,
                    'minor_axis': minor_axis,
                    'angle': angle
                }
                return circle
        
        # 3. Check for arcs (if enabled and contour is relatively simple)
        if len(contour) < 100 and self.is_arc(contour):
            arc_params = self._detect_arc(contour)
            if arc_params:
                # Create a polyline representing the arc
                arc_points = self._generate_arc_points(arc_params)
                if len(arc_points) >= 2:
                    polyline = Polyline(arc_points)
                    # Mark as arc for special handling
                    polyline.is_arc = True
                    polyline.arc_params = arc_params
                    return polyline
        
        # 4. Check for rectangles (including rotated ones)
        if self.is_rectangle(contour):
            # Use minAreaRect to handle rotated rectangles
            rect = cv2.minAreaRect(contour)
            box = cv2.boxPoints(rect)
            box = box.astype(int)
            
            # Create points for the rectangle
            rect_points = [QPointF(point[0], point[1]) for point in box]
            
            # If it's axis-aligned, use Rectangle, otherwise use Polygon
            if abs(rect[2]) < 1.0:  # Almost axis-aligned
                x, y, w, h = map(int, cv2.boundingRect(contour))
                top_left = QPointF(x, y)
                bottom_right = QPointF(x + w, y + h)
                rectangle = Rectangle(top_left, bottom_right)
                rectangle.set_fill(not is_hole and not is_line_contour)
                return rectangle
            else:
                # Rotated rectangle - use polygon
                polygon = CADPolygon(rect_points)
                polygon.set_fill(not is_hole and not is_line_contour)
                # Store rotation data
                polygon.rotation_data = {'angle': rect[2]}
                return polygon

        # 5. For other shapes, use enhanced polygon approximation
        epsilon = self.approximation_accuracy * cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, epsilon, True)

        # Classify based on number of vertices and shape characteristics
        if len(approx) == 4:
            # Check if it's a rotated rectangle that wasn't caught above
            points = [QPointF(point[0][0], point[0][1]) for point in approx]
            polygon = CADPolygon(points)
            polygon.set_fill(not is_hole and not is_line_contour)
            return polygon
        elif len(approx) == 3:
            points = [QPointF(point[0][0], point[0][1]) for point in approx]
            polygon = CADPolygon(points)
            polygon.set_fill(not is_hole and not is_line_contour)
            return polygon
        elif len(approx) >= 3:
            # Complex polygon - use simplified points
            points = [QPointF(point[0][0], point[0][1]) for point in approx]
            polygon = CADPolygon(points)
            polygon.set_fill(not is_hole and not is_line_contour)
            return polygon
        elif len(approx) == 2:
            # Line or very simple shape
            start = QPointF(approx[0][0][0], approx[0][0][1])
            end = QPointF(approx[1][0][0], approx[1][0][1])
            line = Line(start, end)
            return line
        else:
            # Fallback for very complex shapes - use adaptive simplification
            if len(points) > 50:
                # Use higher accuracy for complex shapes
                epsilon_adaptive = 0.02 * cv2.arcLength(contour, True)
                approx_adaptive = cv2.approxPolyDP(contour, epsilon_adaptive, True)
                if len(approx_adaptive) < len(points) * 0.5:  # Significant simplification
                    points = [QPointF(point[0][0], point[0][1]) for point in approx_adaptive]
            
            polyline = Polyline(points)
            return polyline

    def is_circle(self, contour):
        # Enhanced circle detection with relaxed thresholds
        area = cv2.contourArea(contour)
        perimeter = cv2.arcLength(contour, True)
        
        if perimeter == 0 or area < self.min_contour_area:
            return False
        
        circularity = 4 * np.pi * area / (perimeter * perimeter)
        
        # A perfect circle has circularity of 1
        # Use relaxed threshold for better decorative pattern recognition
        return circularity > (1 - 0.3)  # Relaxed from 0.1 to 0.3 for better detection
    
    def is_ellipse(self, contour):
        """Detect ellipses using contour analysis."""
        if len(contour) < 5:
            return False
        
        area = cv2.contourArea(contour)
        if area < self.min_contour_area:
            return False
        
        # Check if it passes ellipse fitting
        try:
            ellipse = cv2.fitEllipse(contour)
            (center, axes, angle) = ellipse
            
            # Check aspect ratio
            major_axis = max(axes)
            minor_axis = min(axes)
            aspect_ratio = minor_axis / major_axis if major_axis > 0 else 0
            
            # Must have significant difference from circle but not too extreme
            if aspect_ratio < 0.1 or aspect_ratio > 0.95:
                return False
            
            # Check how well the ellipse fits the contour
            ellipse_points = cv2.ellipse2Poly(
                tuple(map(int, center)), 
                tuple(map(int, axes)), 
                int(angle), 0, 360, 5
            )
            
            # Calculate fitting error
            distances = []
            for point in contour:
                dist = cv2.pointPolygonTest(ellipse_points, tuple(point[0]), True)
                distances.append(abs(dist))
            
            avg_error = np.mean(distances)
            max_axis = max(axes)
            error_ratio = avg_error / max_axis if max_axis > 0 else 1
            
            return error_ratio < 0.4  # Maximum ellipse fitting error
        except:
            return False
    
    def is_arc(self, contour):
        """Detect if contour represents an arc/curve rather than a closed shape."""
        if len(contour) < 10:
            return False
        
        # Check if contour is open (not closed)
        start_point = contour[0][0]
        end_point = contour[-1][0]
        
        # Calculate distance between start and end points
        distance = np.sqrt((start_point[0] - end_point[0])**2 + (start_point[1] - end_point[1])**2)
        
        # If start and end points are close, it's likely a closed shape
        perimeter = cv2.arcLength(contour, True)
        if distance > perimeter * 0.1:  # More than 10% of perimeter apart
            # Analyze curvature to confirm it's an arc
            return self._analyze_curvature(contour)
        
        return False
    
    def _analyze_curvature(self, contour):
        """Analyze curvature of contour to determine if it's arc-like."""
        if len(contour) < 10:
            return False
        
        # Calculate curvature at each point
        curvatures = []
        for i in range(1, len(contour) - 1):
            p0 = contour[i-1][0]
            p1 = contour[i][0]
            p2 = contour[i+1][0]
            
            # Calculate vectors
            v1 = p1 - p0
            v2 = p2 - p1
            
            # Calculate curvature using cross product
            cross_product = np.cross(v1, v2)
            v1_mag = np.linalg.norm(v1)
            v2_mag = np.linalg.norm(v2)
            
            if v1_mag > 0 and v2_mag > 0:
                curvature = abs(cross_product) / (v1_mag * v2_mag)
                curvatures.append(curvature)
        
        if not curvatures:
            return False
        
        # Check if curvature is relatively consistent (arc-like)
        mean_curvature = np.mean(curvatures)
        std_curvature = np.std(curvatures)
        
        # Coefficient of variation should be low for smooth arcs
        cv = std_curvature / mean_curvature if mean_curvature > 0 else float('inf')
        
        return cv < 0.2  # Maximum curvature deviation

    def is_rectangle(self, contour):
        # Enhanced rectangle detection with support for rotated rectangles
        area = cv2.contourArea(contour)
        if area < self.min_contour_area:
            return False
        
        # Check using minAreaRect for rotated rectangles
        rect = cv2.minAreaRect(contour)
        box = cv2.boxPoints(rect)
        box = box.astype(int)
        
        # Calculate how well the rectangle fits the contour
        rect_area = cv2.contourArea(box)
        if rect_area == 0:
            return False
        
        area_ratio = area / rect_area
        
        # Use relaxed threshold for better detection of imperfect rectangles
        # (common in decorative patterns and hand-drawn shapes)
        if area_ratio > 0.8:  # Relaxed from 0.95 to 0.8
            # Additional check: ensure it's not a circle that passed the test
            if not self.is_circle(contour) and not self.is_ellipse(contour):
                return True
        
        return False
    
    def _detect_arc(self, contour):
        """Detect arc parameters from contour."""
        if len(contour) < 10:
            return None
        
        try:
            # Fit a circle to the points
            (center_x, center_y), radius = cv2.minEnclosingCircle(contour)
            
            # Calculate angles of first and last points relative to center
            start_point = contour[0][0]
            end_point = contour[-1][0]
            
            start_angle = math.atan2(start_point[1] - center_y, start_point[0] - center_x)
            end_angle = math.atan2(end_point[1] - center_y, end_point[0] - center_x)
            
            # Convert to degrees and normalize
            start_angle = math.degrees(start_angle)
            end_angle = math.degrees(end_angle)
            
            # Calculate arc angle (taking the smaller angle)
            angle_diff = abs(end_angle - start_angle)
            if angle_diff > 180:
                angle_diff = 360 - angle_diff
            
            if angle_diff >= 30:  # Minimum 30 degree arc
                return {
                    'center': (center_x, center_y),
                    'radius': radius,
                    'start_angle': start_angle,
                    'end_angle': end_angle,
                    'sweep_angle': angle_diff
                }
        except:
            pass
        
        return None
    
    def _generate_arc_points(self, arc_params, num_points=20):
        """Generate points along an arc for polyline representation."""
        points = []
        center = arc_params['center']
        radius = arc_params['radius']
        start_angle = math.radians(arc_params['start_angle'])
        end_angle = math.radians(arc_params['end_angle'])
        sweep_angle = math.radians(arc_params['sweep_angle'])
        
        # Determine direction (clockwise vs counterclockwise)
        if end_angle < start_angle:
            sweep_angle = -sweep_angle
        
        for i in range(num_points + 1):
            t = i / num_points
            angle = start_angle + t * sweep_angle
            x = center[0] + radius * math.cos(angle)
            y = center[1] + radius * math.sin(angle)
            points.append(QPointF(x, y))
        
        return points
    
    def _analyze_image_type(self, binary_image):
        """Analyze image to determine if it's primarily line art or filled shapes."""
        # Calculate total black pixels
        black_pixels = np.sum(binary_image == 0)
        total_pixels = binary_image.shape[0] * binary_image.shape[1]
        
        if total_pixels == 0:
            return False
        
        black_ratio = black_pixels / total_pixels
        
        # If less than 30% of image is black, likely line art
        # If more than 50% is black, likely filled shapes
        # Between 30-50% is ambiguous
        
        if black_ratio < 0.3:
            return True  # Line art
        elif black_ratio > 0.5:
            return False  # Filled shapes
        else:
            # Ambiguous case - analyze edge density
            edges = cv2.Canny(binary_image, 50, 150)
            edge_pixels = np.sum(edges > 0)
            edge_density = edge_pixels / total_pixels
            
            # High edge density suggests line art
            return edge_density > 0.1
    
    def _is_line_contour(self, contour, is_line_art_image):
        """Determine if a contour represents a line rather than a filled shape."""
        area = cv2.contourArea(contour)
        perimeter = cv2.arcLength(contour, True)
        
        if perimeter == 0:
            return False
        
        # Calculate compactness (perimeter^2 / area)
        # Higher values indicate more linear features
        compactness = (perimeter * perimeter) / area if area > 0 else float('inf')
        
        # For line art images, be more aggressive in detecting lines
        threshold = 30 if is_line_art_image else 50
        
        return compactness > threshold

    def _is_hole_contour(self, index, hierarchy):
        """Check if a contour is a hole based on hierarchy."""
        if hierarchy is None:
            return False
        return hierarchy[0][index][3] != -1

    def _assess_vectorization_quality(self, shapes, image, pattern_analysis):
        """Assess the quality of the vectorization result."""
        # This is a placeholder for a more complex quality assessment
        # In a real implementation, you would compare the vectorized result
        # with the original image to calculate quality metrics
        
        total_shapes = len(shapes)
        shape_types = {}
        for shape in shapes:
            shape_type = shape.__class__.__name__
            shape_types[shape_type] = shape_types.get(shape_type, 0) + 1
        
        # Simple quality score based on number of shapes and pattern detection
        quality_score = min(1.0, total_shapes / 100)  # Normalize to 0-1
        if pattern_analysis['pattern_count'] > 0:
            quality_score += 0.2  # Bonus for pattern detection
        
        quality_score = min(1.0, quality_score)
        
        return {
            'quality_score': quality_score,
            'total_shapes': total_shapes,
            'shape_types': shape_types,
            'pattern_analysis': pattern_analysis
        }

    # Placeholder methods for pattern detection (would need full implementation)
    def _detect_honeycomb_pattern(self, image):
        return {'confidence': 0.0, 'pattern': 'honeycomb'}
    
    def _detect_geometric_pattern(self, image):
        return {'confidence': 0.0, 'pattern': 'geometric'}
    
    def _detect_textured_pattern(self, image):
        return {'confidence': 0.0, 'pattern': 'textured'}
    
    def _detect_organic_pattern(self, image):
        return {'confidence': 0.0, 'pattern': 'organic'}
    
    def _detect_interwoven_pattern(self, image):
        return {'confidence': 0.0, 'pattern': 'interwoven'}
    
    def _detect_celtic_knot_pattern(self, image):
        return {'confidence': 0.0, 'pattern': 'celtic_knot'}
    
    def _detect_mandala_pattern(self, image):
        return {'confidence': 0.0, 'pattern': 'mandala'}

    # Placeholder methods for laser cutting optimization (would need full implementation)
    def apply_kerf_compensation(self, shapes, kerf_width): return shapes
    def optimize_cut_order(self, shapes, material='plywood'): return shapes
    def apply_thermal_management(self, shapes, material='plywood'): return shapes
    def detect_gaps_and_features(self, shapes, min_gap_size=1.0): return {'gaps': [], 'recommendations': []}
    def recognize_decorative_patterns(self, image): return {'patterns': [], 'recommendations': []}
    def generate_laser_cutting_gcode(self, shapes, material='plywood'): return "; G-code placeholder"