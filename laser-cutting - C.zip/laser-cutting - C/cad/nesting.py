# cad/nesting_fixed.py - Enhanced Nesting Optimizer with Better Algorithm
import random
import numpy as np
from shapely.geometry import Point, Polygon, box, LineString
from shapely.ops import unary_union
from shapely import affinity
import math

class NestingOptimizer:
    """Enhanced nesting optimizer using Bottom-Left algorithm with rotation support."""
    
    def __init__(self):
        self.material_width = 1000  # Default material width in mm
        self.material_height = 600  # Default material height in mm
        self.spacing = 5  # Minimum spacing between shapes in mm
        self.allow_rotation = True  # Allow shape rotation for better packing
        self.rotation_angles = [0, 90, 180, 270]  # Allowed rotation angles
    
    def optimize(self, shapes, max_iterations=50):
        """Optimize shape placement using Bottom-Left algorithm."""
        if not shapes:
            return []
        
        # Convert shapes to Shapely geometries
        geometries = []
        for shape in shapes:
            geom = self.shape_to_geometry(shape)
            if geom:
                geometries.append((shape, geom))
        
        if not geometries:
            return []
        
        # Sort shapes by area (largest first) for better packing
        geometries.sort(key=lambda x: x[1].area, reverse=True)
        
        # Try Bottom-Left algorithm
        positions = self.bottom_left_algorithm(geometries)
        
        # If rotation is allowed, try with rotations
        if self.allow_rotation:
            rotated_positions = self.bottom_left_with_rotation(geometries)
            # Compare efficiency and choose better result
            if self.calculate_efficiency(geometries, rotated_positions) > \
               self.calculate_efficiency(geometries, positions):
                positions = rotated_positions
        
        return positions
    
    def shape_to_geometry(self, shape):
        """Convert CAD shape to Shapely geometry."""
        shape_type = shape.__class__.__name__
        
        if shape_type == "Line":
            start = shape.get_start_point()
            end = shape.get_end_point()
            thickness = max(shape.get_thickness() / 10, 0.5)
            return LineString([(start.x(), start.y()), (end.x(), end.y())]).buffer(thickness)
            
        elif shape_type == "Circle":
            center = shape.get_center()
            radius = shape.get_radius() / 10
            return Point(center.x(), center.y()).buffer(radius)
            
        elif shape_type == "Rectangle":
            rect = shape.boundingRect()
            return box(rect.left()/10, rect.top()/10, rect.right()/10, rect.bottom()/10)
            
        elif shape_type == "Polygon":
            points = [(p.x()/10, p.y()/10) for p in shape.get_points()]
            if len(points) >= 3:
                return Polygon(points)
                
        elif shape_type == "Polyline":
            points = [(p.x()/10, p.y()/10) for p in shape.get_points()]
            if len(points) >= 2:
                return LineString(points).buffer(0.5)
                
        elif shape_type == "Bezier":
            points = [(p.x()/10, p.y()/10) for p in shape.get_points()]
            if len(points) >= 4:
                return LineString([points[0], points[1], points[2], points[3]]).buffer(0.5)
        
        return None
    
    def bottom_left_algorithm(self, geometries):
        """Bottom-Left algorithm for nesting."""
        positions = []
        placed_geometries = []
        
        for shape, geom in geometries:
            # Find the bottom-left position for this shape
            best_pos = self.find_bottom_left_position(geom, placed_geometries)
            positions.append(best_pos)
            
            # Add placed geometry to the list
            placed_geom = affinity.translate(geom, xoff=best_pos[0], yoff=best_pos[1])
            placed_geometries.append(placed_geom)
        
        return positions
    
    def find_bottom_left_position(self, geom, placed_geometries):
        """Find the bottom-left position for a geometry."""
        bounds = geom.bounds
        width = bounds[2] - bounds[0]
        height = bounds[3] - bounds[1]
        
        # Start from bottom-left corner
        best_x = 0
        best_y = 0
        
        # If no shapes placed yet, place at origin
        if not placed_geometries:
            return (0 - bounds[0], 0 - bounds[1])
        
        # Try to find the lowest leftmost position
        # Create a grid of candidate positions
        step = max(width, height) / 4  # Coarse grid for speed
        
        candidates = []
        for y in np.arange(0, self.material_height - height, step):
            for x in np.arange(0, self.material_width - width, step):
                test_geom = affinity.translate(geom, xoff=x - bounds[0], yoff=y - bounds[1])
                
                # Check if position is valid (no overlaps and within bounds)
                if self.is_valid_position(test_geom, placed_geometries):
                    # Score: prefer lower and lefter positions
                    score = y * 2 + x  # Weight y more than x (bottom-left priority)
                    candidates.append((score, x - bounds[0], y - bounds[1]))
        
        # Choose the best candidate (lowest score = bottom-left)
        if candidates:
            candidates.sort(key=lambda c: c[0])
            return (candidates[0][1], candidates[0][2])
        
        # If no valid position found in grid, try stacking vertically
        if placed_geometries:
            union = unary_union(placed_geometries)
            max_y = union.bounds[3]
            return (0 - bounds[0], max_y + self.spacing - bounds[1])
        
        return (0 - bounds[0], 0 - bounds[1])
    
    def bottom_left_with_rotation(self, geometries):
        """Bottom-Left algorithm with rotation support."""
        positions = []
        placed_geometries = []
        
        for shape, geom in geometries:
            # Try different rotations and find the best one
            best_pos = None
            best_angle = 0
            best_area = float('inf')
            
            for angle in self.rotation_angles:
                # Rotate geometry
                rotated_geom = affinity.rotate(geom, angle, origin='centroid')
                
                # Find position for rotated geometry
                pos = self.find_bottom_left_position(rotated_geom, placed_geometries)
                
                # Calculate bounding box area of all placed shapes
                test_placed = placed_geometries + [affinity.translate(rotated_geom, xoff=pos[0], yoff=pos[1])]
                union = unary_union(test_placed)
                area = (union.bounds[2] - union.bounds[0]) * (union.bounds[3] - union.bounds[1])
                
                # Choose rotation that minimizes total bounding box
                if area < best_area:
                    best_area = area
                    best_pos = pos
                    best_angle = angle
            
            # Store position and rotation
            positions.append((best_pos[0], best_pos[1], best_angle))
            
            # Add placed geometry
            rotated_geom = affinity.rotate(geom, best_angle, origin='centroid')
            placed_geom = affinity.translate(rotated_geom, xoff=best_pos[0], yoff=best_pos[1])
            placed_geometries.append(placed_geom)
        
        # Convert to simple (x, y) positions (rotation is not applied to shapes yet)
        return [(p[0], p[1]) for p in positions]
    
    def is_valid_position(self, test_geom, placed_geometries):
        """Check if a position is valid (no overlaps, within bounds)."""
        # Check material bounds
        material = box(0, 0, self.material_width, self.material_height)
        if not material.contains(test_geom):
            return False
        
        # Check overlaps with placed geometries (with spacing)
        test_geom_buffered = test_geom.buffer(self.spacing)
        for placed_geom in placed_geometries:
            if test_geom_buffered.intersects(placed_geom):
                return False
        
        return True
    
    def calculate_efficiency(self, geometries, positions):
        """Calculate packing efficiency (0-1, higher is better)."""
        if not positions:
            return 0
        
        # Create placed geometries
        placed_geometries = []
        for (shape, geom), (x, y) in zip(geometries, positions):
            placed_geom = affinity.translate(geom, xoff=x, yoff=y)
            placed_geometries.append(placed_geom)
        
        # Calculate total shape area
        total_shape_area = sum(geom.area for geom in placed_geometries)
        
        # Calculate bounding box area
        union = unary_union(placed_geometries)
        bounds = union.bounds
        bounding_area = (bounds[2] - bounds[0]) * (bounds[3] - bounds[1])
        
        # Efficiency = shape area / bounding area
        if bounding_area > 0:
            return total_shape_area / bounding_area
        return 0
    
    def translate_geometry(self, geom, x, y):
        """Translate geometry by (x, y)."""
        return affinity.translate(geom, xoff=x, yoff=y)
