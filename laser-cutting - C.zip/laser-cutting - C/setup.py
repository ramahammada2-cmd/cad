from setuptools import setup, find_packages

setup(
    name="LaserCAD_H1530",
    version="1.0.0",
    description="Professional CAD application for laser-cutting machines",
    author="XT Laser Solutions",
    packages=find_packages(),
    install_requires=[
        "PyQt5==5.15.9",
        "opencv-python==4.7.0.72",
        "Pillow==9.5.0",
        "numpy==1.24.3",
        "shapely==2.0.1",
        "ezdxf==1.0.3"
    ],
    python_requires=">=3.10",
    entry_points={
        "console_scripts": [
            "lasercad=main:main"
        ]
    }
)