#!/usr/bin/env python3
"""
Test script to verify that all required icons are present and can be loaded.
This addresses the warning: "Icon resources\icons\[name].png not found"
"""

import os
import sys
from pathlib import Path

def test_icons():
    """Test that all required tool icons are present and valid."""
    
    # Define required icons
    required_icons = [
        'select.png',
        'line.png', 
        'circle.png',
        'rectangle.png',
        'polygon.png',
        'text.png',
        'polyline.png',
        'bezier.png'
    ]
    
    # Get the resources directory path
    script_dir = Path(__file__).parent
    resources_dir = script_dir / 'resources' / 'icons'
    
    print(f"Checking for icons in: {resources_dir}")
    print("-" * 50)
    
    missing_icons = []
    present_icons = []
    
    for icon in required_icons:
        icon_path = resources_dir / icon
        if icon_path.exists():
            file_size = icon_path.stat().st_size
            present_icons.append((icon, file_size))
            print(f"✓ {icon} - Found ({file_size} bytes)")
        else:
            missing_icons.append(icon)
            print(f"✗ {icon} - Missing")
    
    print("-" * 50)
    print(f"Summary:")
    print(f"  Present: {len(present_icons)}/{len(required_icons)}")
    print(f"  Missing: {len(missing_icons)}/{len(required_icons)}")
    
    if missing_icons:
        print(f"\nMissing icons: {', '.join(missing_icons)}")
        return False
    else:
        print("\n✅ All required icons are present!")
        return True

def test_icon_loading():
    """Test that we can actually load the PNG files using PIL."""
    try:
        from PIL import Image
    except ImportError:
        print("PIL not available, skipping image loading test")
        return True
        
    script_dir = Path(__file__).parent
    resources_dir = script_dir / 'resources' / 'icons'
    
    required_icons = [
        'select.png', 'line.png', 'circle.png', 'rectangle.png',
        'polygon.png', 'text.png', 'polyline.png', 'bezier.png'
    ]
    
    print("\nTesting icon image loading...")
    print("-" * 30)
    
    for icon in required_icons:
        try:
            icon_path = resources_dir / icon
            with Image.open(icon_path) as img:
                width, height = img.size
                mode = img.mode
                print(f"✓ {icon} - {width}x{height}, mode: {mode}")
        except Exception as e:
            print(f"✗ {icon} - Error loading: {e}")
            return False
    
    print("-" * 30)
    print("✅ All icons can be loaded successfully!")
    return True

if __name__ == "__main__":
    print("Testing CAD Application Icons")
    print("=" * 40)
    
    icons_present = test_icons()
    icons_loadable = test_icon_loading()
    
    if icons_present and icons_loadable:
        print("\n🎉 All icon issues have been resolved!")
        print("The application should no longer show 'Icon not found' warnings.")
        sys.exit(0)
    else:
        print("\n❌ Some icon issues remain.")
        sys.exit(1)