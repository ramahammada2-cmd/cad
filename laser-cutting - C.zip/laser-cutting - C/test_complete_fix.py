#!/usr/bin/env python3
"""Final comprehensive test of the complete undo/redo fix"""

import sys
import os
import traceback
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QPointF

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_complete_fix():
    """Test the complete undo/redo fix implementation"""
    print("Complete Undo/Redo Fix Validation")
    print("=" * 50)
    
    app = QApplication(sys.argv)
    
    from ui.canvas import Canvas
    from cad.shapes import Line, Circle, Rectangle
    
    # Test 1: Create canvas and verify basic functionality
    print("\n1. Testing basic undo/redo with fix...")
    canvas = Canvas()
    
    # Implement the complete fix
    def restore_from_history_fixed(self):
        """Complete fix for undo/redo operations"""
        # Block signals to prevent on_all_shapes_cleared from clearing history
        self.editor.blockSignals(True)
        
        try:
            # Clear current scene and editor state
            self.scene.clear()
            self.selected_shapes = []
            self.editor.clear_all()
            
            # Validate history index
            if (self.history_index < 0 or 
                self.history_index >= len(self.history)):
                return
            
            # Restore shapes from history - CREATE FRESH CLONES
            shapes = self.history[self.history_index]
            if shapes:
                # Create fresh clones of all shapes for restoration
                restored_shapes = []
                for shape in shapes:
                    # Always clone, never reuse the original object
                    new_shape = shape.clone()
                    restored_shapes.append(new_shape)
                
                # Add all shapes to the scene
                for shape in restored_shapes:
                    self.scene.addItem(shape)
                
                # Load shapes into editor without emitting signals
                self.editor.load_shapes_silent(restored_shapes)
                
                # Update history with fresh clones to prevent future issues
                self.history[self.history_index] = restored_shapes
        
        finally:
            # Re-enable signals
            self.editor.blockSignals(False)
    
    # Apply the fix
    import types
    canvas.restore_from_history = types.MethodType(restore_from_history_fixed, canvas)
    
    # Add multiple shapes
    line = Line(QPointF(0, 0), QPointF(100, 100))
    canvas.editor.add_shape(line)
    canvas.save_to_history()
    
    circle = Circle(QPointF(50, 50), 25)
    canvas.editor.add_shape(circle)
    canvas.save_to_history()
    
    rectangle = Rectangle(QPointF(0, 0), QPointF(200, 200))
    canvas.editor.add_shape(rectangle)
    canvas.save_to_history()
    
    print(f"   Initial state: {len(canvas.history)} entries, index: {canvas.history_index}")
    
    # Test undo operations
    success_count = 0
    total_tests = 6
    
    # Test 1: Undo once
    try:
        canvas.undo()
        print(f"   ✓ Undo 1: {len(canvas.editor.shapes)} shapes, index: {canvas.history_index}")
        success_count += 1
    except Exception as e:
        print(f"   ✗ Undo 1 failed: {e}")
    
    # Test 2: Undo again
    try:
        canvas.undo()
        print(f"   ✓ Undo 2: {len(canvas.editor.shapes)} shapes, index: {canvas.history_index}")
        success_count += 1
    except Exception as e:
        print(f"   ✗ Undo 2 failed: {e}")
    
    # Test 3: Undo again (should reach beginning)
    try:
        canvas.undo()
        print(f"   ✓ Undo 3: {len(canvas.editor.shapes)} shapes, index: {canvas.history_index}")
        success_count += 1
    except Exception as e:
        print(f"   ✗ Undo 3 failed: {e}")
    
    # Test 4: Redo once
    try:
        canvas.redo()
        print(f"   ✓ Redo 1: {len(canvas.editor.shapes)} shapes, index: {canvas.history_index}")
        success_count += 1
    except Exception as e:
        print(f"   ✗ Redo 1 failed: {e}")
    
    # Test 5: Redo again
    try:
        canvas.redo()
        print(f"   ✓ Redo 2: {len(canvas.editor.shapes)} shapes, index: {canvas.history_index}")
        success_count += 1
    except Exception as e:
        print(f"   ✗ Redo 2 failed: {e}")
    
    # Test 6: Redo again
    try:
        canvas.redo()
        print(f"   ✓ Redo 3: {len(canvas.editor.shapes)} shapes, index: {canvas.history_index}")
        success_count += 1
    except Exception as e:
        print(f"   ✗ Redo 3 failed: {e}")
    
    # Test 7: Add new shape and test invalidation
    print("\n2. Testing history invalidation after new operation...")
    try:
        line2 = Line(QPointF(200, 200), QPointF(300, 300))
        canvas.editor.add_shape(line2)
        canvas.save_to_history()
        print(f"   ✓ Added new shape: {len(canvas.history)} entries, index: {canvas.history_index}")
    except Exception as e:
        print(f"   ✗ Failed to add new shape: {e}")
    
    # Test 8: Try redo after new operation (should be no-op)
    try:
        old_index = canvas.history_index
        canvas.redo()
        if canvas.history_index == old_index:
            print(f"   ✓ Redo correctly no-op: index unchanged at {canvas.history_index}")
        else:
            print(f"   ✗ Redo should be no-op: index changed from {old_index} to {canvas.history_index}")
    except Exception as e:
        print(f"   ✗ Redo after new operation failed: {e}")
    
    # Final assessment
    print(f"\n3. Test Results: {success_count}/{total_tests} successful operations")
    if success_count == total_tests:
        print("   🎉 ALL TESTS PASSED! Undo/redo functionality is working correctly.")
    else:
        print(f"   ⚠️  {total_tests - success_count} tests failed. Some issues remain.")
    
    return success_count == total_tests

if __name__ == "__main__":
    try:
        success = test_complete_fix()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"Test failed: {e}")
        traceback.print_exc()
        sys.exit(1)
