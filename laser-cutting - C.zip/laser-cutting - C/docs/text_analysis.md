# LaserCAD Text Rendering Implementation Analysis

## Overview
This document analyzes the text rendering implementation in the LaserCAD application, focusing on how text objects are created, displayed, and manipulated. The analysis examines three key files: `cad/shapes.py`, `ui/canvas.py`, and `ui/main_window.py`.

## 1. Text Object Creation and Display

### Current Implementation (cad/shapes.py, lines 333-426)

The `Text` class follows a parent-child item pattern:

```python
class Text(Shape):
    def __init__(self, position, text):
        super().__init__()
        self.position = position
        self.text = text
        self.font = "Arial"
        self.font_size = 12
        
        # Create text item
        self.text_item = QGraphicsTextItem(text)
        self.text_item.setParentItem(self)  # Attach to this shape item
        self.text_item.setPos(position)
        self.text_item.setFont(QFont(self.font, self.font_size))
        self.text_item.setDefaultTextColor(QColor(self.color))
```

**Key Design Decisions:**
- Uses `QGraphicsTextItem` as a child of the `Text` shape
- The parent `Text` shape handles transformation (scale, rotation, movement)
- The child `text_item` handles actual text rendering
- Position is stored in both the parent and child items

## 2. Critical Issues Identified

### Issue 1: Inconsistent Position Management (CRITICAL)

**Location:** `cad/shapes.py`, lines 368-377

```python
def set_position(self, position):
    self.position = position
    # Set the text item position relative to the parent's coordinate system
    # The parent shape's position is controlled by Qt's item position system
    # We want the text to appear at the desired position on the scene
    current_pos = self.pos()
    dx = position.x() - current_pos.x()
    dy = position.y() - current_pos.y()
    self.moveBy(dx, dy)
    self.update()
```

**Problem:** 
- The `position` attribute stores absolute scene coordinates
- The `text_item` position is set to this absolute position
- But `text_item` is a child of the `Text` shape, which has its own position
- This creates a double transformation effect
- The text item's position should be relative to the parent, not absolute

**Impact:** Text appears at incorrect positions, especially after operations that move the shape.

### Issue 2: Text Item Not Properly Positioned During Initialization

**Location:** `cad/shapes.py`, line 344

```python
self.text_item.setPos(position)
```

**Problem:**
- `position` is an absolute scene coordinate
- `text_item` is a child of `self` (the Text shape)
- When the Text shape is added to the scene, both positions are applied
- Result: Text appears offset from the intended position

**Expected Behavior:** Text item should be positioned at (0, 0) relative to the parent Text shape, and the parent shape should be positioned at the desired absolute location.

### Issue 3: Scaling Doesn't Affect Child Text Item

**Location:** `cad/shapes.py`, lines 92-95 (inherited from Shape)

```python
def set_scale(self, scale):
    self.scale = scale
    self.setScale(scale[0])  # Use uniform scaling for simplicity
    self.update()
```

**Problem:**
- The parent `Text` shape is scaled
- The child `text_item` should inherit this scale transformation
- However, the text item's font size is a separate property
- This creates a conflict: should the text scale with the shape or maintain its font size?

**Impact:** When scaling a text object, the text content doesn't scale visually, making the scaling operation appear broken.

### Issue 4: Text Not Visible After Creation (CRITICAL)

**Location:** `ui/canvas.py`, lines 124-127

```python
elif self.current_tool == "text":
    self.temp_shape = Text(self.start_point, "Text")
    # For text, we're done after setting position
    self.finish_drawing()
```

**Location:** `ui/canvas.py`, lines 257-266

```python
def finish_drawing(self):
    if self.temp_shape:
        # Remove temporary shape from scene
        self.scene.removeItem(self.temp_shape)
        # Add shape through editor
        self.editor.add_shape(self.temp_shape)
        # Clear temporary shape
        self.temp_shape = None
        # Save to history
        self.save_to_history()
```

**Problem Sequence:**
1. User clicks to place text
2. `Text` object is created with `text_item` as a child
3. `text_item` is added to the scene
4. Immediately removed in `finish_drawing()`
5. Parent `Text` shape is added through editor
6. Editor adds the Text shape to the scene
7. Since `text_item` is a child, it should be added too

**Issue:** The child `text_item` is not properly re-added to the scene when the parent is added. Qt should handle this automatically, but there may be z-order or visibility issues.

### Issue 5: Selection Handling for Child Items

**Location:** `ui/canvas.py`, line 83

```python
item = self.scene.itemAt(pos, self.transform())
if item and isinstance(item, Shape):
```

**Problem:**
- The `itemAt()` method returns the topmost item at the position
- For text, the child `text_item` might be returned instead of the parent `Text` shape
- The `isinstance(item, Shape)` check would fail for the text_item
- Result: Text objects might not be selectable

**Impact:** Users cannot select or manipulate text objects.

### Issue 6: Clone Method Inconsistency

**Location:** `cad/shapes.py`, lines 418-426

```python
def clone(self):
    new_text = Text(self.position, self.text)
    self._copy_properties(new_text)
    # Copy text-specific properties
    new_text.font = self.font
    new_text.font_size = self.font_size
    new_text.text_item.setFont(QFont(new_text.font, new_text.font_size))
    new_text.text_item.setDefaultTextColor(QColor(new_text.color))
    return new_text
```

**Problem:**
- New Text is created with `self.position`
- Properties are copied via `_copy_properties()` which sets position again
- Text item font and color are set manually
- The text item position is never set on the cloned object

**Impact:** Cloned text objects may not appear correctly or may not be visible.

## 3. Text Positioning Logic During Operations

### Moving/Scaling Operations

When a Text shape is moved:
1. The parent `Text` shape moves via inherited `moveBy()` method
2. The child `text_item` should move with it (Qt handles this automatically)
3. However, the `position` attribute is not updated
4. This causes issues when `set_position()` is called later

### Coordinate System Confusion

The implementation has dual coordinate systems:
1. **Parent coordinate system**: Used by Qt's item hierarchy
2. **Absolute coordinate system**: Stored in `self.position`

This dual system causes:
- Position calculations to be off
- Text to appear at wrong locations
- Inconsistent behavior between different operations

## 4. Recommended Solutions

### Solution 1: Simplify Position Management

Replace the dual position system with Qt's parent-child system:

```python
def __init__(self, position, text):
    super().__init__()
    self.text = text
    self.font = "Arial"
    self.font_size = 12
    
    # Create text item at (0, 0) relative to parent
    self.text_item = QGraphicsTextItem(text)
    self.text_item.setParentItem(self)
    self.text_item.setFont(QFont(self.font, self.font_size))
    self.text_item.setDefaultTextColor(QColor(self.color))
    
    # Set parent position to absolute position
    self.setPos(position)

def set_position(self, position):
    # Simply set the parent position
    self.setPos(position)
```

### Solution 2: Fix Visibility Issue

Ensure the text item is properly added to the scene:

```python
def add_shape(self, shape):
    self.scene.addItem(shape)
    # If shape is Text, ensure text_item is also visible
    if isinstance(shape, Text):
        shape.text_item.setVisible(True)
        shape.text_item.setZValue(shape.zValue())
```

### Solution 3: Fix Clone Method

```python
def clone(self):
    new_text = Text(QPointF(0, 0), self.text)  # Create at origin
    new_text.setPos(self.pos())  # Set absolute position
    self._copy_properties(new_text)
    new_text.font = self.font
    new_text.font_size = self.font_size
    new_text.text_item.setFont(QFont(new_text.font, new_text.font_size))
    new_text.text_item.setDefaultTextColor(QColor(new_text.color))
    return new_text
```

### Solution 4: Handle Text Item Selection

In the canvas mouse handling:

```python
item = self.scene.itemAt(pos, self.transform())
if item:
    # If text item is clicked, get parent Text shape
    if hasattr(item, 'parentItem') and isinstance(item.parentItem(), Text):
        item = item.parentItem()
    
    if isinstance(item, Shape):
        # Handle selection...
```

### Solution 5: Scale Font with Shape

```python
def set_scale(self, scale):
    self.scale = scale
    self.setScale(scale[0])
    
    # Scale the font size for Text items
    if hasattr(self, 'text_item'):
        scaled_font_size = int(self.font_size * scale[0])
        self.text_item.setFont(QFont(self.font, scaled_font_size))
    
    self.update()
```

## 5. Testing Recommendations

To verify the fixes:

1. **Create a text object** and verify it appears immediately
2. **Select the text** and verify selection handles appear
3. **Move the text** and verify it moves smoothly
4. **Scale the text** and verify it scales properly
5. **Change font properties** and verify updates
6. **Clone the text** and verify the clone is identical
7. **Undo/Redo** and verify text objects persist correctly
8. **Load a project** with text and verify all text is visible

## 6. Conclusion

The current text implementation has several critical issues that prevent text from being properly visible and functional:

1. **Position management is inconsistent** - dual coordinate systems
2. **Child item positioning is incorrect** - absolute vs. relative coordinates
3. **Visibility issues** - text not appearing after creation
4. **Selection problems** - text items not properly selectable
5. **Clone method issues** - cloned text may not be visible

These issues are interconnected and stem from a fundamental design flaw in how the parent-child item relationship is managed. The recommended solutions focus on:

- Simplifying the position management to use Qt's built-in parent-child system
- Ensuring child items are properly managed during scene operations
- Making sure text objects behave consistently with other shape types

Implementing these fixes will make the text functionality work reliably and consistently with the rest of the application.