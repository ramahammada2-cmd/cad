import os

def write_file(filename, content):
    with open(filename, 'w') as f:
        f.write(content)
    print(f"Created file: {filename}")

def main():
    # Create project structure
    os.makedirs("ui", exist_ok=True)
    os.makedirs("cad", exist_ok=True)
    os.makedirs("io", exist_ok=True)
    os.makedirs("utils", exist_ok=True)
    os.makedirs("resources/icons", exist_ok=True)
    
    # Create __init__.py files
    for package in ["ui", "cad", "io", "utils"]:
        write_file(f"{package}/__init__.py", "# Package initialization file\n")
    
    # Write main.py
    write_file("main.py", '''import sys
import os
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
from ui.main_window import MainWindow

def main():
    # Set application attributes
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    
    # Create application
    app = QApplication(sys.argv)
    app.setApplicationName("LaserCAD H1530")
    app.setOrganizationName("XT Laser Solutions")
    
    # Create and show main window
    window = MainWindow()
    window.show()
    
    # Run application
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
''')

    # Write requirements.txt
    write_file("requirements.txt", '''PyQt5==5.15.9
opencv-python==4.7.0.72
Pillow==9.5.0
numpy==1.24.3
shapely==2.0.1
ezdxf==1.0.3
''')

    # Write build.py
    write_file("build.py", '''import os
import sys
import subprocess
import shutil

def build_exe():
    # Check if PyInstaller is installed
    try:
        import PyInstaller
    except ImportError:
        print("PyInstaller not found. Installing...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
    
    # Create resources directory if it doesn't exist
    resources_dir = "resources"
    if not os.path.exists(resources_dir):
        os.makedirs(resources_dir)
        os.makedirs(os.path.join(resources_dir, "icons"))
        
        # Create placeholder icon files (in a real application, you would have actual icon files)
        icon_files = ["select.png", "line.png", "circle.png", "rectangle.png", 
                     "polygon.png", "text.png", "polyline.png", "bezier.png"]
        
        for icon_file in icon_files:
            icon_path = os.path.join(resources_dir, "icons", icon_file)
            if not os.path.exists(icon_path):
                # Create a simple placeholder icon
                from PIL import Image, ImageDraw
                img = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
                draw = ImageDraw.Draw(img)
                draw.rectangle([2, 2, 30, 30], outline=(0, 0, 0), width=2)
                img.save(icon_path)
    
    # Build the executable
    print("Building executable...")
    subprocess.check_call([
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--windowed",
        "--add-data", f"{resources_dir}{os.pathsep}resources",
        "--icon", "resources/icons/select.png",
        "main.py"
    ])
    
    print("Build complete!")
    print(f"Executable created at: dist/LaserCAD_H1530.exe")

if __name__ == "__main__":
    build_exe()
''')

    print("\nAll files created successfully!")
    print("\nTo run the application:")
    print("1. Install dependencies: pip install -r requirements.txt")
    print("2. Run the application: python main.py")
    print("\nTo build the executable:")
    print("1. Run the build script: python build.py")
    print("2. Find the executable in the dist/ directory")

if __name__ == "__main__":
    main()