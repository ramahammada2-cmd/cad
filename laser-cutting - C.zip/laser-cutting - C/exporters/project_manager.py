
import os
import json
import sqlite3
import tempfile
from datetime import datetime
from PyQt5.QtCore import QPointF
from cad.shapes import Line, Circle, Rectangle, Polygon, Text, Polyline, Bezier

class ProjectManager:
    def __init__(self):
        self.file_path = None
        self.temp_dir = tempfile.gettempdir()
        self.auto_save_file = os.path.join(self.temp_dir, "lasercad_autosave.xlt")
    
    def new_project(self):
        self.file_path = None
    
    def save_project(self, shapes, file_path=None):
        if file_path:
            self.file_path = file_path
        
        if not self.file_path:
            raise ValueError("No file path specified")
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(self.file_path), exist_ok=True)
        
        # Save shapes to JSON
        shapes_data = []
        for shape in shapes:
            shape_data = self.shape_to_dict(shape)
            shapes_data.append(shape_data)
        
        # Create project data
        project_data = {
            "version": "1.0",
            "created": datetime.now().isoformat(),
            "shapes": shapes_data
        }
        
        # Save to JSON file
        with open(self.file_path, 'w') as f:
            json.dump(project_data, f, indent=2)
        
        # Save to SQLite database
        self.save_to_database(shapes_data)
    
    def load_project(self, file_path):
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Project file not found: {file_path}")
        
        self.file_path = file_path
        
        # Load from JSON file
        with open(file_path, 'r') as f:
            project_data = json.load(f)
        
        # Load shapes from database
        shapes_data = self.load_from_database()
        
        # If database is empty, use JSON data
        if not shapes_data:
            shapes_data = project_data.get("shapes", [])
        
        return shapes_data
    
    def get_shapes(self):
        if not self.file_path:
            return []
        
        return self.load_project(self.file_path)
    
    def save_auto_save(self, shapes):
        # Save shapes to JSON
        shapes_data = []
        for shape in shapes:
            shape_data = self.shape_to_dict(shape)
            shapes_data.append(shape_data)
        
        # Create project data
        project_data = {
            "version": "1.0",
            "created": datetime.now().isoformat(),
            "shapes": shapes_data
        }
        
        # Save to JSON file
        with open(self.auto_save_file, 'w') as f:
            json.dump(project_data, f, indent=2)
    
    def restore_auto_save(self):
        if not os.path.exists(self.auto_save_file):
            raise FileNotFoundError(f"Auto-save file not found: {self.auto_save_file}")
        
        # Load from JSON file
        with open(self.auto_save_file, 'r') as f:
            project_data = json.load(f)
        
        return project_data.get("shapes", [])
    
    def has_auto_save(self):
        return os.path.exists(self.auto_save_file)
    
    def shape_to_dict(self, shape):
        # Convert shape to dictionary
        shape_type = shape.__class__.__name__
        shape_data = {
            "type": shape_type,
            "color": shape.get_color(),
            "thickness": shape.get_thickness(),
            "fill": shape.get_fill(),
            "fill_color": shape.get_fill_color(),
            "layer": shape.get_layer(),
            "visible": shape.is_visible(),
            "locked": shape.is_locked(),
            "rotation": shape.get_rotation(),
            "scale": shape.get_scale(),
            "position": {"x": shape.pos().x(), "y": shape.pos().y()}
        }
        
        # Add shape-specific data
        if shape_type == "Line":
            shape_data["start_point"] = {"x": shape.get_start_point().x(), "y": shape.get_start_point().y()}
            shape_data["end_point"] = {"x": shape.get_end_point().x(), "y": shape.get_end_point().y()}
        elif shape_type == "Circle":
            shape_data["center"] = {"x": shape.get_center().x(), "y": shape.get_center().y()}
            shape_data["radius"] = shape.get_radius()
        elif shape_type == "Rectangle":
            shape_data["top_left"] = {"x": shape.get_top_left().x(), "y": shape.get_top_left().y()}
            shape_data["bottom_right"] = {"x": shape.get_bottom_right().x(), "y": shape.get_bottom_right().y()}
        elif shape_type == "Polygon":
            shape_data["points"] = [{"x": p.x(), "y": p.y()} for p in shape.get_points()]
        elif shape_type == "Text":
            shape_data["position"] = {"x": shape.get_position().x(), "y": shape.get_position().y()}
            shape_data["text"] = shape.get_text()
            shape_data["font"] = shape.get_font()
            shape_data["font_size"] = shape.get_font_size()
        elif shape_type == "Polyline":
            shape_data["points"] = [{"x": p.x(), "y": p.y()} for p in shape.get_points()]
        elif shape_type == "Bezier":
            shape_data["points"] = [{"x": p.x(), "y": p.y()} for p in shape.get_points()]
        
        return shape_data
    
    def dict_to_shape(self, shape_data):
        shape_type = shape_data.get("type")
        if not shape_type:
            return None

        shape_classes = {
            "Line": Line,
            "Circle": Circle,
            "Rectangle": Rectangle,
            "Polygon": Polygon,
            "Text": Text,
            "Polyline": Polyline,
            "Bezier": Bezier,
        }

        shape_class = shape_classes.get(shape_type)
        if not shape_class:
            return None
        
        shape = None
        # Create a basic shape instance with minimal required parameters
        if shape_type == "Line":
            start = QPointF(shape_data["start_point"]["x"], shape_data["start_point"]["y"])
            end = QPointF(shape_data["end_point"]["x"], shape_data["end_point"]["y"])
            shape = shape_class(start, end)
        elif shape_type == "Circle":
            center = QPointF(shape_data["center"]["x"], shape_data["center"]["y"])
            shape = shape_class(center, shape_data["radius"])
        elif shape_type == "Rectangle":
            top_left = QPointF(shape_data["top_left"]["x"], shape_data["top_left"]["y"])
            bottom_right = QPointF(shape_data["bottom_right"]["x"], shape_data["bottom_right"]["y"])
            shape = shape_class(top_left, bottom_right)
        elif shape_type in ["Polygon", "Polyline", "Bezier"]:
            points = [QPointF(p["x"], p["y"]) for p in shape_data["points"]]
            shape = shape_class(points)
        elif shape_type == "Text":
            pos = QPointF(shape_data["position"]["x"], shape_data["position"]["y"])
            shape = shape_class(pos, shape_data["text"])
        
        if shape:
            # Set position and then use update_properties for all other attributes
            shape.setPos(QPointF(shape_data["position"]["x"], shape_data["position"]["y"]))
            shape.update_properties(shape_data)
        
        return shape
    
    def save_to_database(self, shapes_data):
        # Create database file path
        db_file_path = self.file_path.replace('.xlt', '.db')
        
        # Connect to database
        conn = sqlite3.connect(db_file_path)
        cursor = conn.cursor()
        
        # Create table if it doesn't exist
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS shapes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            data TEXT NOT NULL
        )
        ''')
        
        # Clear existing data
        cursor.execute('DELETE FROM shapes')
        
        # Insert shapes
        for shape_data in shapes_data:
            cursor.execute('INSERT INTO shapes (type, data) VALUES (?, ?)',
                          (shape_data["type"], json.dumps(shape_data)))
        
        # Commit and close
        conn.commit()
        conn.close()
    
    def load_from_database(self):
        # Create database file path
        db_file_path = self.file_path.replace('.xlt', '.db')
        
        if not os.path.exists(db_file_path):
            return []
        
        # Connect to database
        conn = sqlite3.connect(db_file_path)
        cursor = conn.cursor()
        
        # Get shapes
        cursor.execute('SELECT data FROM shapes')
        rows = cursor.fetchall()
        
        # Close connection
        conn.close()
        
        # Parse shapes
        shapes_data = []
        for row in rows:
            shape_data = json.loads(row[0])
            shapes_data.append(shape_data)
        
        return shapes_data