
import ezdxf
from ezdxf.entities import Line as DXFLine, Circle as DXFCircle, LWPolyline as DXFPolyline

class DXFExporter:
    def __init__(self):
        pass
    
    def export(self, shapes, file_path):
        # Create a new DXF document
        doc = ezdxf.new('R2010')
        msp = doc.modelspace()
        
        # Add shapes to model space
        for shape in shapes:
            self.add_shape_to_dxf(shape, msp)
        
        # Save DXF file
        doc.saveas(file_path)
    
    def add_shape_to_dxf(self, shape, msp):
        shape_type = shape.__class__.__name__
        
        # Get shape properties
        color = self.color_to_aci(shape.get_color())
        thickness = shape.get_thickness() / 10  # Convert to mm
        
        if shape_type == "Line":
            start = shape.get_start_point()
            end = shape.get_end_point()
            dxf_line = msp.add_line(
                (start.x() / 10, start.y() / 10),  # Convert to mm
                (end.x() / 10, end.y() / 10)      # Convert to mm
            )
            dxf_line.dxf.color = color
            dxf_line.dxf.lineweight = thickness * 100  # DXF lineweight is in hundredths of mm
        
        elif shape_type == "Circle":
            center = shape.get_center()
            radius = shape.get_radius() / 10  # Convert to mm
            dxf_circle = msp.add_circle(
                (center.x() / 10, center.y() / 10),  # Convert to mm
                radius
            )
            dxf_circle.dxf.color = color
            dxf_circle.dxf.lineweight = thickness * 100  # DXF lineweight is in hundredths of mm
        
        elif shape_type == "Rectangle":
            rect = shape.boundingRect()
            points = [
                (rect.left() / 10, rect.top() / 10),      # Convert to mm
                (rect.right() / 10, rect.top() / 10),     # Convert to mm
                (rect.right() / 10, rect.bottom() / 10),  # Convert to mm
                (rect.left() / 10, rect.bottom() / 10)    # Convert to mm
            ]
            dxf_polyline = msp.add_lwpolyline(points, close=True)
            dxf_polyline.dxf.color = color
            dxf_polyline.dxf.lineweight = thickness * 100  # DXF lineweight is in hundredths of mm
        
        elif shape_type == "Polygon":
            points = [(p.x() / 10, p.y() / 10) for p in shape.get_points()]  # Convert to mm
            dxf_polyline = msp.add_lwpolyline(points, close=True)
            dxf_polyline.dxf.color = color
            dxf_polyline.dxf.lineweight = thickness * 100  # DXF lineweight is in hundredths of mm
        
        elif shape_type == "Polyline":
                    points = [(p.x() / 10, p.y() / 10) for p in shape.get_points()]  # Convert to mm
                    dxf_polyline = msp.add_lwpolyline(points, close=False)
                    dxf_polyline.dxf.color = color
                    dxf_polyline.dxf.lineweight = thickness * 100  # DXF lineweight is in hundredths of mm
        
        elif shape_type == "Bezier":
            # Convert bezier to polyline (simplified)
            points = [(p.x() / 10, p.y() / 10) for p in shape.get_points()]  # Convert to mm
            dxf_polyline = msp.add_lwpolyline(points, close=False)
            dxf_polyline.dxf.color = color
            dxf_polyline.dxf.lineweight = thickness * 100  # DXF lineweight is in hundredths of mm
        
        elif shape_type == "Text":
            # Text is not typically cut with laser, but we can add it as a reference
            position = shape.get_position()
            text = shape.get_text()
            font_size = shape.get_font_size() / 10  # Convert to mm
            msp.add_text(
                text,
                dxfattribs={
                    'height': font_size,
                    'color': color,
                    'layer': f'Layer {shape.get_layer() + 1}'
                }
            ).set_pos((position.x() / 10, position.y() / 10))  # Convert to mm
    
    def color_to_aci(self, color):
        # Convert hex color to AutoCAD Color Index (ACI)
        # This is a simplified mapping - in a real application, you would use a more comprehensive mapping
        color_map = {
            "#000000": 7,   # Black/White
            "#FF0000": 1,   # Red
            "#00FF00": 3,   # Green
            "#0000FF": 5,   # Blue
            "#FFFF00": 2,   # Yellow
            "#00FFFF": 4,   # Cyan
            "#FF00FF": 6    # Magenta
        }
        return color_map.get(color.upper(), 7)  # Default to Black/White