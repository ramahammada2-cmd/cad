
from xml.etree.ElementTree import Element, SubElement, tostring
from xml.dom import minidom

class SVGExporter:
    def __init__(self):
        pass
    
    def export(self, shapes, file_path):
        # Create SVG root element
        svg = Element('svg')
        svg.set('xmlns', 'http://www.w3.org/2000/svg')
        svg.set('version', '1.1')
        
        # Calculate canvas size
        min_x, min_y, max_x, max_y = self.calculate_bounds(shapes)
        width = max_x - min_x + 20  # Add padding
        height = max_y - min_y + 20  # Add padding
        
        svg.set('width', str(width))
        svg.set('height', str(height))
        svg.set('viewBox', f"{min_x - 10} {min_y - 10} {width} {height}")
        
        # Add shapes to SVG
        for shape in shapes:
            self.add_shape_to_svg(shape, svg)
        
        # Pretty print XML
        rough_string = tostring(svg, 'utf-8')
        reparsed = minidom.parseString(rough_string)
        
        # Save SVG file
        with open(file_path, 'w') as f:
            f.write(reparsed.toprettyxml(indent="  "))
    
    def calculate_bounds(self, shapes):
        if not shapes:
            return 0, 0, 100, 100
        
        min_x = min(shape.boundingRect().left() for shape in shapes)
        min_y = min(shape.boundingRect().top() for shape in shapes)
        max_x = max(shape.boundingRect().right() for shape in shapes)
        max_y = max(shape.boundingRect().bottom() for shape in shapes)
        
        return min_x, min_y, max_x, max_y
    
    def add_shape_to_svg(self, shape, svg):
        shape_type = shape.__class__.__name__
        
        # Get shape properties
        color = shape.get_color()
        thickness = shape.get_thickness()
        fill = shape.get_fill()
        fill_color = shape.get_fill_color()
        
        if shape_type == "Line":
            start = shape.get_start_point()
            end = shape.get_end_point()
            line = SubElement(svg, 'line')
            line.set('x1', str(start.x()))
            line.set('y1', str(start.y()))
            line.set('x2', str(end.x()))
            line.set('y2', str(end.y()))
            line.set('stroke', color)
            line.set('stroke-width', str(thickness))
            if fill:
                line.set('fill', fill_color)
            else:
                line.set('fill', 'none')
        
        elif shape_type == "Circle":
            center = shape.get_center()
            radius = shape.get_radius()
            circle = SubElement(svg, 'circle')
            circle.set('cx', str(center.x()))
            circle.set('cy', str(center.y()))
            circle.set('r', str(radius))
            circle.set('stroke', color)
            circle.set('stroke-width', str(thickness))
            if fill:
                circle.set('fill', fill_color)
            else:
                circle.set('fill', 'none')
        
        elif shape_type == "Rectangle":
            rect = shape.boundingRect()
            rectangle = SubElement(svg, 'rect')
            rectangle.set('x', str(rect.left()))
            rectangle.set('y', str(rect.top()))
            rectangle.set('width', str(rect.width()))
            rectangle.set('height', str(rect.height()))
            rectangle.set('stroke', color)
            rectangle.set('stroke-width', str(thickness))
            if fill:
                rectangle.set('fill', fill_color)
            else:
                rectangle.set('fill', 'none')
        
        elif shape_type == "Polygon":
            points = shape.get_points()
            points_str = ' '.join(f"{p.x()},{p.y()}" for p in points)
            polygon = SubElement(svg, 'polygon')
            polygon.set('points', points_str)
            polygon.set('stroke', color)
            polygon.set('stroke-width', str(thickness))
            if fill:
                polygon.set('fill', fill_color)
            else:
                polygon.set('fill', 'none')
        
        elif shape_type == "Polyline":
            points = shape.get_points()
            points_str = ' '.join(f"{p.x()},{p.y()}" for p in points)
            polyline = SubElement(svg, 'polyline')
            polyline.set('points', points_str)
            polyline.set('stroke', color)
            polyline.set('stroke-width', str(thickness))
            if fill:
                polyline.set('fill', fill_color)
            else:
                polyline.set('fill', 'none')
        
        elif shape_type == "Bezier":
            # Convert bezier to SVG path
            points = shape.get_points()
            if len(points) >= 4:
                path = SubElement(svg, 'path')
                d = f"M {points[0].x()} {points[0].y()} C {points[1].x()} {points[1].y()}, {points[2].x()} {points[2].y()}, {points[3].x()} {points[3].y()}"
                path.set('d', d)
                path.set('stroke', color)
                path.set('stroke-width', str(thickness))
                if fill:
                    path.set('fill', fill_color)
                else:
                    path.set('fill', 'none')
        
        elif shape_type == "Text":
            position = shape.get_position()
            text = shape.get_text()
            font = shape.get_font()
            font_size = shape.get_font_size()
            
            text_elem = SubElement(svg, 'text')
            text_elem.set('x', str(position.x()))
            text_elem.set('y', str(position.y()))
            text_elem.set('font-family', font)
            text_elem.set('font-size', str(font_size))
            text_elem.set('fill', color)
            text_elem.text = text