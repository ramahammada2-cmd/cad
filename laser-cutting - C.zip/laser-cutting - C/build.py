import os
import sys
import subprocess
import shutil

def build_exe():
    # Check if PyInstaller is installed
    try:
        import PyInstaller
    except ImportError:
        print("PyInstaller not found. Installing...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
    
    # Create resources directory if it doesn't exist
    resources_dir = "resources"
    if not os.path.exists(resources_dir):
        os.makedirs(resources_dir)
        os.makedirs(os.path.join(resources_dir, "icons"))
        
        # Create placeholder icon files (in a real application, you would have actual icon files)
        icon_files = ["select.png", "line.png", "circle.png", "rectangle.png", 
                     "polygon.png", "text.png", "polyline.png", "bezier.png"]
        
        for icon_file in icon_files:
            icon_path = os.path.join(resources_dir, "icons", icon_file)
            if not os.path.exists(icon_path):
                # Create a simple placeholder icon
                from PIL import Image, ImageDraw
                img = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
                draw = ImageDraw.Draw(img)
                draw.rectangle([2, 2, 30, 30], outline=(0, 0, 0), width=2)
                img.save(icon_path)
    
    # Build the executable
    print("Building executable...")
    subprocess.check_call([
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--windowed",
        "--add-data", f"{resources_dir}{os.pathsep}resources",
        "--icon", "resources/icons/select.png",
        "main.py"
    ])
    
    print("Build complete!")
    print(f"Executable created at: dist/LaserCAD_H1530.exe")

if __name__ == "__main__":
    build_exe()
