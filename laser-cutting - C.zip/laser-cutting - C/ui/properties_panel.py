
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QFormLayout, QLabel, QLineEdit, QSpinBox, QDoubleSpinBox, QPushButton, QColorDialog, QComboBox, QGroupBox, QCheckBox, QHBoxLayout
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QColor

class PropertiesPanel(QWidget):
    propertyChanged = pyqtSignal(dict)
    
    def __init__(self):
        super().__init__()
        
        # Current shape
        self.current_shape = None
        
        # Set up UI
        self.init_ui()
    
    def init_ui(self):
        # Main layout
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("Properties")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(title)
        
        # Shape properties group
        self.shape_group = QGroupBox("Shape Properties")
        shape_layout = QFormLayout(self.shape_group)
        
        # Shape type
        self.shape_type_label = QLabel("None")
        shape_layout.addRow("Type:", self.shape_type_label)
        
        # Position
        self.x_spin = QDoubleSpinBox()
        self.x_spin.setRange(-10000, 10000)
        self.x_spin.setDecimals(2)
        self.x_spin.valueChanged.connect(self.on_property_changed)
        shape_layout.addRow("X:", self.x_spin)
        
        self.y_spin = QDoubleSpinBox()
        self.y_spin.setRange(-10000, 10000)
        self.y_spin.setDecimals(2)
        self.y_spin.valueChanged.connect(self.on_property_changed)
        shape_layout.addRow("Y:", self.y_spin)
        
        # Size/Dimensions
        self.width_spin = QDoubleSpinBox()
        self.width_spin.setRange(0, 10000)
        self.width_spin.setDecimals(2)
        self.width_spin.valueChanged.connect(self.on_property_changed)
        shape_layout.addRow("Width:", self.width_spin)
        
        self.height_spin = QDoubleSpinBox()
        self.height_spin.setRange(0, 10000)
        self.height_spin.setDecimals(2)
        self.height_spin.valueChanged.connect(self.on_property_changed)
        shape_layout.addRow("Height:", self.height_spin)
        
        # Radius (for circles)
        self.radius_spin = QDoubleSpinBox()
        self.radius_spin.setRange(0, 10000)
        self.radius_spin.setDecimals(2)
        self.radius_spin.valueChanged.connect(self.on_property_changed)
        shape_layout.addRow("Radius:", self.radius_spin)
        
        # Style properties group
        self.style_group = QGroupBox("Style Properties")
        style_layout = QFormLayout(self.style_group)
        
        # Color
        self.color_button = QPushButton()
        self.color_button.clicked.connect(self.choose_color)
        self.color_button.setStyleSheet("background-color: black;")
        style_layout.addRow("Color:", self.color_button)
        
        # Thickness
        self.thickness_spin = QSpinBox()
        self.thickness_spin.setRange(1, 20)
        self.thickness_spin.valueChanged.connect(self.on_property_changed)
        style_layout.addRow("Thickness:", self.thickness_spin)
        
        # Fill
        self.fill_check = QCheckBox()
        self.fill_check.stateChanged.connect(self.on_property_changed)
        style_layout.addRow("Fill:", self.fill_check)
        
        # Fill color
        self.fill_color_button = QPushButton()
        self.fill_color_button.clicked.connect(self.choose_fill_color)
        self.fill_color_button.setStyleSheet("background-color: white;")
        style_layout.addRow("Fill Color:", self.fill_color_button)
        
        # Text properties group
        self.text_group = QGroupBox("Text Properties")
        text_layout = QFormLayout(self.text_group)
        
        # Text content
        self.text_edit = QLineEdit()
        self.text_edit.textChanged.connect(self.on_property_changed)
        text_layout.addRow("Text:", self.text_edit)
        
        # Font
        self.font_combo = QComboBox()
        self.font_combo.addItems(["Arial", "Times New Roman", "Courier New", "Verdana", "Helvetica"])
        self.font_combo.currentTextChanged.connect(self.on_property_changed)
        text_layout.addRow("Font:", self.font_combo)
        
        # Font size
        self.font_size_spin = QSpinBox()
        self.font_size_spin.setRange(6, 72)
        self.font_size_spin.valueChanged.connect(self.on_property_changed)
        text_layout.addRow("Size:", self.font_size_spin)
        
        # Formatting options
        format_layout = QHBoxLayout()
        self.bold_check = QCheckBox("Bold")
        self.bold_check.stateChanged.connect(self.on_property_changed)
        self.italic_check = QCheckBox("Italic")
        self.italic_check.stateChanged.connect(self.on_property_changed)
        self.underline_check = QCheckBox("Underline")
        self.underline_check.stateChanged.connect(self.on_property_changed)
        
        format_layout.addWidget(self.bold_check)
        format_layout.addWidget(self.italic_check)
        format_layout.addWidget(self.underline_check)
        format_layout.addStretch()
        
        format_widget = QWidget()
        format_widget.setLayout(format_layout)
        text_layout.addRow("Format:", format_widget)
        
        # Layer properties group
        self.layer_group = QGroupBox("Layer Properties")
        layer_layout = QFormLayout(self.layer_group)
        
        # Layer
        self.layer_combo = QComboBox()
        self.layer_combo.addItems(["Layer 1", "Layer 2", "Layer 3", "Layer 4", "Layer 5"])
        self.layer_combo.currentIndexChanged.connect(self.on_property_changed)
        layer_layout.addRow("Layer:", self.layer_combo)
        
        # Visible
        self.visible_check = QCheckBox()
        self.visible_check.setChecked(True)
        self.visible_check.stateChanged.connect(self.on_property_changed)
        layer_layout.addRow("Visible:", self.visible_check)
        
        # Locked
        self.locked_check = QCheckBox()
        self.locked_check.setChecked(False)
        self.locked_check.stateChanged.connect(self.on_property_changed)
        layer_layout.addRow("Locked:", self.locked_check)
        
        # Transform properties group
        self.transform_group = QGroupBox("Transform Properties")
        transform_layout = QFormLayout(self.transform_group)
        
        # Rotation
        self.rotation_spin = QDoubleSpinBox()
        self.rotation_spin.setRange(-360, 360)
        self.rotation_spin.setDecimals(2)
        self.rotation_spin.valueChanged.connect(self.on_property_changed)
        transform_layout.addRow("Rotation:", self.rotation_spin)
        
        # Scale X
        self.scale_x_spin = QDoubleSpinBox()
        self.scale_x_spin.setRange(0.1, 10)
        self.scale_x_spin.setDecimals(2)
        self.scale_x_spin.setValue(1.0)
        self.scale_x_spin.valueChanged.connect(self.on_property_changed)
        transform_layout.addRow("Scale X:", self.scale_x_spin)
        
        # Scale Y
        self.scale_y_spin = QDoubleSpinBox()
        self.scale_y_spin.setRange(0.1, 10)
        self.scale_y_spin.setDecimals(2)
        self.scale_y_spin.setValue(1.0)
        self.scale_y_spin.valueChanged.connect(self.on_property_changed)
        transform_layout.addRow("Scale Y:", self.scale_y_spin)
        
        # Add groups to layout
        layout.addWidget(self.shape_group)
        layout.addWidget(self.style_group)
        layout.addWidget(self.text_group)
        layout.addWidget(self.layer_group)
        layout.addWidget(self.transform_group)
        
        # Add stretch to push everything to the top
        layout.addStretch()
        
        # Initially hide all groups
        self.shape_group.hide()
        self.style_group.hide()
        self.text_group.hide()
        self.layer_group.hide()
        self.transform_group.hide()
    
    def set_shape(self, shape):
        self.current_shape = shape
        
        if shape:
            # Show all groups
            self.shape_group.show()
            self.style_group.show()
            self.layer_group.show()
            self.transform_group.show()
            
            # Update shape type
            self.shape_type_label.setText(shape.__class__.__name__)
            
            # Update position
            rect = shape.boundingRect()
            self.x_spin.setValue(rect.x())
            self.y_spin.setValue(rect.y())
            
            # Update dimensions based on shape type
            if shape.__class__.__name__ in ["Rectangle", "Polygon"]:
                self.width_spin.setValue(rect.width())
                self.height_spin.setValue(rect.height())
                self.width_spin.setEnabled(True)
                self.height_spin.setEnabled(True)
                self.radius_spin.setEnabled(False)
            elif shape.__class__.__name__ == "Circle":
                self.radius_spin.setValue(shape.get_radius())
                self.width_spin.setEnabled(False)
                self.height_spin.setEnabled(False)
                self.radius_spin.setEnabled(True)
            else:
                self.width_spin.setEnabled(False)
                self.height_spin.setEnabled(False)
                self.radius_spin.setEnabled(False)
            
            # Update style properties
            color = shape.get_color()
            self.color_button.setStyleSheet(f"background-color: {color};")
            self.thickness_spin.setValue(shape.get_thickness())
            self.fill_check.setChecked(shape.get_fill())
            fill_color = shape.get_fill_color()
            self.fill_color_button.setStyleSheet(f"background-color: {fill_color};")
            
            # Update text properties if applicable
            if shape.__class__.__name__ == "Text":
                self.text_group.show()
                self.text_edit.setText(shape.get_text())
                self.font_combo.setCurrentText(shape.get_font())
                self.font_size_spin.setValue(shape.get_font_size())
                # Update formatting options
                self.bold_check.setChecked(shape.is_bold())
                self.italic_check.setChecked(shape.is_italic())
                self.underline_check.setChecked(shape.is_underlined())
            else:
                self.text_group.hide()
            
            # Update layer properties
            self.layer_combo.setCurrentIndex(shape.get_layer())
            self.visible_check.setChecked(shape.is_visible())
            self.locked_check.setChecked(shape.is_locked())
            
            # Update transform properties
            self.rotation_spin.setValue(shape.get_rotation())
            scale = shape.get_scale()
            self.scale_x_spin.setValue(scale[0])
            self.scale_y_spin.setValue(scale[1])
        else:
            # Hide all groups
            self.shape_group.hide()
            self.style_group.hide()
            self.text_group.hide()
            self.layer_group.hide()
            self.transform_group.hide()
    
    def on_property_changed(self):
        if not self.current_shape:
            return
        
        # Collect properties
        properties = {}
        
        # Position
        properties["x"] = self.x_spin.value()
        properties["y"] = self.y_spin.value()
        
        # Dimensions
        if self.current_shape.__class__.__name__ in ["Rectangle", "Polygon"]:
            properties["width"] = self.width_spin.value()
            properties["height"] = self.height_spin.value()
        elif self.current_shape.__class__.__name__ == "Circle":
            properties["radius"] = self.radius_spin.value()
        
        # Style
        properties["color"] = self.color_button.palette().button().color().name()
        properties["thickness"] = self.thickness_spin.value()
        properties["fill"] = self.fill_check.isChecked()
        properties["fill_color"] = self.fill_color_button.palette().button().color().name()
        
        # Text
        if self.current_shape.__class__.__name__ == "Text":
            properties["text"] = self.text_edit.text()
            properties["font"] = self.font_combo.currentText()
            properties["font_size"] = self.font_size_spin.value()
            # Formatting options
            properties["bold"] = self.bold_check.isChecked()
            properties["italic"] = self.italic_check.isChecked()
            properties["underline"] = self.underline_check.isChecked()
        
        # Layer
        properties["layer"] = self.layer_combo.currentIndex()
        properties["visible"] = self.visible_check.isChecked()
        properties["locked"] = self.locked_check.isChecked()
        
        # Transform
        properties["rotation"] = self.rotation_spin.value()
        properties["scale_x"] = self.scale_x_spin.value()
        properties["scale_y"] = self.scale_y_spin.value()
        
        # Emit signal
        self.propertyChanged.emit(properties)
    
    def choose_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.color_button.setStyleSheet(f"background-color: {color.name()};")
            self.on_property_changed()
    
    def choose_fill_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.fill_color_button.setStyleSheet(f"background-color: {color.name()};")
            self.on_property_changed()