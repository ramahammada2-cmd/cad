# ui/canvas_fixed.py - Enhanced Canvas with Professional Drawing Features
import math
import os
import numpy as np
from PyQt5.QtWidgets import (QWidget, QGraphicsView, QGraphicsScene, QGraphicsItem,
                             QMenu, QInputDialog, QLineEdit, QGraphicsLineItem,
                             QGraphicsEllipseItem, QGraphicsRectItem)
from PyQt5.QtCore import Qt, QPointF, QRectF, pyqtSignal, QLineF, QEvent
from PyQt5.QtGui import (QPen, QBrush, QColor, QPainter, QPolygonF,
                         QMouseEvent, QWheelEvent, QKeyEvent, QFont)

from cad.shapes import Shape, Line, Circle, Rectangle, Polygon, Text, Polyline, Bezier
from cad.editor import Editor
from cad.analyzer import Analyzer
from cad.nesting import NestingOptimizer
from cad.image_to_vector import EnhancedImageToVectorConverter as ImageToVectorConverter
from exporters.dxf_exporter import DXFExporter
from exporters.svg_exporter import SVGExporter
from cad.commands import AddShapeCommand, DeleteShapeCommand, MoveShapeCommand, ModifyShapeCommand
from cad.history import History


class Canvas(QGraphicsView):
    shapeSelected = pyqtSignal(object)
    logMessage = pyqtSignal(str, str)
    undoRedoStateChanged = pyqtSignal(bool, bool)

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    def __init__(self):
        super().__init__()

        # Initialize editor FIRST
        self.editor = Editor()

        # Initialize other components
        self.analyzer = Analyzer()
        self.nesting_optimizer = NestingOptimizer()
        self.image_converter = ImageToVectorConverter()
        self.dxf_exporter = DXFExporter()
        self.svg_exporter = SVGExporter()

        # Scene
        self.scene = QGraphicsScene()
        self.setScene(self.scene)

        # Canvas properties
        self.setRenderHint(QPainter.Antialiasing)
        self.setRenderHint(QPainter.TextAntialiasing)
        self.setRenderHint(QPainter.SmoothPixmapTransform)
        self.setDragMode(QGraphicsView.NoDrag)  # Changed to NoDrag for better control
        self.setMouseTracking(True)

        # Grid
        self.grid_size = 20
        self.show_grid = True
        self.snap_to_grid = True
        self.snap_tolerance = 10  # Snap tolerance in pixels

        # Tools & drawing state
        self.current_tool = "select"
        self.drawing = False
        self.start_point = QPointF()
        self.current_point = QPointF()
        self.current_shape = None
        self.temp_shape = None
        self.multi_click_points = []  # For polygon/polyline
        
        # Drawing guides
        self.guide_lines = []  # Store guide line items
        self.show_guides = True
        self.show_dimensions = True

        # Selection
        self.selected_shapes = []
        self.selection_start = None
        self.is_dragging = False
        self.drag_start_positions = {}

        # Snap points
        self.snap_points = []  # Store snap points from existing shapes
        self.snap_indicator = None  # Visual indicator for snap point

        # NEW command-based history
        self.history = History()

        # Background
        self.setBackgroundBrush(QBrush(QColor(240, 240, 240)))

        # Connect editor signals (after creation)
        self.editor.shapeAdded.connect(self.add_shape)
        self.editor.shapeUpdated.connect(self.update_shape)
        self.editor.shapeDeleted.connect(self.delete_shape)
        self.editor.allShapesCleared.connect(self.on_all_shapes_cleared)
        
        # Update undo/redo state initially
        self.update_undo_redo_state()

    # ------------------------------------------------------------------
    # Tool & cursor
    # ------------------------------------------------------------------
    def set_tool(self, tool):
        self.current_tool = tool
        self.drawing = False
        self.temp_shape = None
        self.multi_click_points = []
        self.clear_guides()
        self.update_cursor()

    def update_cursor(self):
        if self.current_tool == "select":
            self.setCursor(Qt.ArrowCursor)
        else:
            self.setCursor(Qt.CrossCursor)

    # ------------------------------------------------------------------
    # Snap functionality - Professional CAD-like snapping
    # ------------------------------------------------------------------
    def update_snap_points(self):
        """Update snap points from all shapes in the scene."""
        self.snap_points = []
        for item in self.scene.items():
            if isinstance(item, Shape) and not isinstance(item, Text):
                self.snap_points.extend(self.get_shape_snap_points(item))
    
    def get_shape_snap_points(self, shape):
        """Get snap points for a shape (endpoints, midpoints, center)."""
        points = []
        shape_type = shape.__class__.__name__
        
        if shape_type == "Line":
            start = shape.get_start_point()
            end = shape.get_end_point()
            mid = QPointF((start.x() + end.x()) / 2, (start.y() + end.y()) / 2)
            points = [start, mid, end]
            
        elif shape_type == "Circle":
            center = shape.get_center()
            radius = shape.get_radius()
            points = [
                center,
                QPointF(center.x() + radius, center.y()),
                QPointF(center.x() - radius, center.y()),
                QPointF(center.x(), center.y() + radius),
                QPointF(center.x(), center.y() - radius)
            ]
            
        elif shape_type == "Rectangle":
            rect = shape.boundingRect()
            tl = rect.topLeft()
            tr = rect.topRight()
            bl = rect.bottomLeft()
            br = rect.bottomRight()
            center = rect.center()
            points = [
                tl, tr, bl, br, center,
                QPointF((tl.x() + tr.x()) / 2, tl.y()),  # Top mid
                QPointF((bl.x() + br.x()) / 2, bl.y()),  # Bottom mid
                QPointF(tl.x(), (tl.y() + bl.y()) / 2),  # Left mid
                QPointF(tr.x(), (tr.y() + br.y()) / 2)   # Right mid
            ]
            
        elif shape_type in ["Polygon", "Polyline"]:
            shape_points = shape.get_points()
            points = list(shape_points)
            # Add midpoints
            for i in range(len(shape_points)):
                p1 = shape_points[i]
                p2 = shape_points[(i + 1) % len(shape_points)]
                mid = QPointF((p1.x() + p2.x()) / 2, (p1.y() + p2.y()) / 2)
                points.append(mid)
        
        return points
    
    def find_snap_point(self, pos):
        """Find the nearest snap point to the given position."""
        if not self.snap_to_grid:
            return pos
        
        # First check for object snap points
        self.update_snap_points()
        min_dist = self.snap_tolerance
        snap_point = None
        
        for point in self.snap_points:
            dist = math.sqrt((pos.x() - point.x())**2 + (pos.y() - point.y())**2)
            if dist < min_dist:
                min_dist = dist
                snap_point = point
        
        if snap_point:
            self.show_snap_indicator(snap_point)
            return snap_point
        else:
            self.hide_snap_indicator()
            # Fall back to grid snap
            return self.snap_to_grid_point(pos)
    
    def show_snap_indicator(self, pos):
        """Show visual indicator at snap point."""
        if self.snap_indicator:
            self.scene.removeItem(self.snap_indicator)
        
        # Create a small circle to indicate snap point
        self.snap_indicator = QGraphicsEllipseItem(pos.x() - 5, pos.y() - 5, 10, 10)
        self.snap_indicator.setPen(QPen(QColor(255, 0, 0), 2))
        self.snap_indicator.setBrush(QBrush(QColor(255, 0, 0, 100)))
        self.snap_indicator.setZValue(1000)  # Always on top
        self.scene.addItem(self.snap_indicator)
    
    def hide_snap_indicator(self):
        """Hide snap indicator."""
        if self.snap_indicator:
            self.scene.removeItem(self.snap_indicator)
            self.snap_indicator = None

    # ------------------------------------------------------------------
    # Drawing guides - Professional CAD-like guides
    # ------------------------------------------------------------------
    def update_guides(self, pos):
        """Update drawing guides based on current position."""
        self.clear_guides()
        
        if not self.show_guides or not self.drawing:
            return
        
        if self.current_tool in ["line", "rectangle", "circle"]:
            # Horizontal guide
            h_line = QGraphicsLineItem(-10000, pos.y(), 10000, pos.y())
            h_line.setPen(QPen(QColor(0, 255, 0, 100), 1, Qt.DashLine))
            h_line.setZValue(999)
            self.scene.addItem(h_line)
            self.guide_lines.append(h_line)
            
            # Vertical guide
            v_line = QGraphicsLineItem(pos.x(), -10000, pos.x(), 10000)
            v_line.setPen(QPen(QColor(0, 255, 0, 100), 1, Qt.DashLine))
            v_line.setZValue(999)
            self.scene.addItem(v_line)
            self.guide_lines.append(v_line)
            
            # Draw dimension text
            if self.show_dimensions and self.current_tool in ["line", "rectangle"]:
                self.draw_dimension_text(self.start_point, pos)
    
    def draw_dimension_text(self, start, end):
        """Draw dimension text showing distance."""
        dx = abs(end.x() - start.x())
        dy = abs(end.y() - start.y())
        distance = math.sqrt(dx**2 + dy**2)
        
        # Create text item
        text = self.scene.addText(f"{distance:.1f}", QFont("Arial", 10))
        text.setDefaultTextColor(QColor(0, 0, 255))
        text.setPos((start.x() + end.x()) / 2, (start.y() + end.y()) / 2 - 20)
        text.setZValue(999)
        self.guide_lines.append(text)
        
        # Add width and height for rectangle
        if self.current_tool == "rectangle":
            w_text = self.scene.addText(f"W: {dx:.1f}", QFont("Arial", 9))
            w_text.setDefaultTextColor(QColor(0, 0, 255))
            w_text.setPos((start.x() + end.x()) / 2 - 30, end.y() + 10)
            w_text.setZValue(999)
            self.guide_lines.append(w_text)
            
            h_text = self.scene.addText(f"H: {dy:.1f}", QFont("Arial", 9))
            h_text.setDefaultTextColor(QColor(0, 0, 255))
            h_text.setPos(end.x() + 10, (start.y() + end.y()) / 2 - 10)
            h_text.setZValue(999)
            self.guide_lines.append(h_text)
    
    def clear_guides(self):
        """Clear all drawing guides."""
        for item in self.guide_lines:
            self.scene.removeItem(item)
        self.guide_lines = []

    # ------------------------------------------------------------------
    # Mouse events - Enhanced for professional drawing
    # ------------------------------------------------------------------
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            pos = self.mapToScene(event.pos())
            pos = self.find_snap_point(pos)
            
            if self.current_tool == "select":
                item = self.scene.itemAt(pos, self.transform())
                
                # Check if clicking on a shape or its text item
                shape_item = None
                if isinstance(item, Shape):
                    shape_item = item
                elif isinstance(item, QGraphicsItem):
                    # Check if it's a text item belonging to a Text shape
                    parent = item.parentItem()
                    if isinstance(parent, Text):
                        shape_item = parent
                
                if shape_item:
                    if event.modifiers() & Qt.ControlModifier:
                        if shape_item in self.selected_shapes:
                            self.selected_shapes.remove(shape_item)
                            shape_item.setSelected(False)
                        else:
                            self.selected_shapes.append(shape_item)
                            shape_item.setSelected(True)
                    else:
                        for sh in self.selected_shapes:
                            sh.setSelected(False)
                        self.selected_shapes = [shape_item]
                        shape_item.setSelected(True)
                    self.shapeSelected.emit(shape_item)
                else:
                    for sh in self.selected_shapes:
                        sh.setSelected(False)
                    self.selected_shapes = []
                    self.shapeSelected.emit(None)
                
                if self.selected_shapes:
                    self.is_dragging = True
                    self.start_point = pos
                    # Store original positions for undo
                    self.drag_start_positions = {sh: sh.pos() for sh in self.selected_shapes}
                    
            elif self.current_tool in ["polygon", "polyline"]:
                # Multi-click drawing
                self.multi_click_points.append(pos)
                if not self.temp_shape:
                    self.drawing = True
                    self.create_temp_shape(pos)
                    if self.temp_shape:
                        self.scene.addItem(self.temp_shape)
                else:
                    self.temp_shape.add_point(pos)
                    self.temp_shape.update()
                    
            else:
                # Single drag drawing (line, circle, rectangle, bezier)
                self.start_point = pos
                self.drawing = True
                self.create_temp_shape(pos)
                if self.temp_shape and self.current_tool != "text":
                    self.scene.addItem(self.temp_shape)
                    
        elif event.button() == Qt.MiddleButton:
            # Pan with middle mouse button
            self.setDragMode(QGraphicsView.ScrollHandDrag)
            self.setCursor(Qt.ClosedHandCursor)
            
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent):
        pos = self.mapToScene(event.pos())
        self.current_point = pos
        
        # Apply snapping
        snapped_pos = self.find_snap_point(pos)
        
        if self.drawing:
            if self.current_tool == "select" and self.is_dragging and self.selected_shapes:
                # Move selected shapes
                dx = snapped_pos.x() - self.start_point.x()
                dy = snapped_pos.y() - self.start_point.y()
                for sh in self.selected_shapes:
                    sh.moveBy(dx, dy)
                self.start_point = snapped_pos
                
            elif self.temp_shape and self.current_tool not in ["polygon", "polyline"]:
                # Update temp shape
                self.update_temp_shape(snapped_pos)
                self.update_guides(snapped_pos)
                
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            if self.current_tool == "select" and self.is_dragging and self.selected_shapes:
                # Create move command for undo/redo
                for sh in self.selected_shapes:
                    old_pos = self.drag_start_positions.get(sh)
                    new_pos = sh.pos()
                    if old_pos and old_pos != new_pos:
                        cmd = MoveShapeCommand(sh, old_pos, new_pos)
                        self.history.execute(cmd)
                self.is_dragging = False
                self.drag_start_positions = {}
                self.update_undo_redo_state()
                
            elif self.temp_shape and self.current_tool in ["line", "circle", "rectangle", "bezier"]:
                self.finish_drawing()
                self.drawing = False
                
        elif event.button() == Qt.MiddleButton:
            self.setDragMode(QGraphicsView.NoDrag)
            self.update_cursor()
            
        self.clear_guides()
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            if self.current_tool in ["polygon", "polyline"] and self.temp_shape:
                if len(self.multi_click_points) >= 2:
                    self.finish_drawing()
                    self.multi_click_points = []
                    self.drawing = False
        super().mouseDoubleClickEvent(event)

    # ------------------------------------------------------------------
    # Keyboard / Wheel / Context menu
    # ------------------------------------------------------------------
    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key_Delete and self.selected_shapes:
            self.delete_selected()
        elif event.key() == Qt.Key_Escape:
            self.cancel_drawing()
        elif event.key() in (Qt.Key_Return, Qt.Key_Enter):
            if self.temp_shape and self.current_tool in ["polygon", "polyline"]:
                if len(self.multi_click_points) >= 2:
                    self.finish_drawing()
                    self.multi_click_points = []
                    self.drawing = False
        elif event.key() == Qt.Key_F2 and len(self.selected_shapes) == 1 and isinstance(self.selected_shapes[0], Text):
            self.edit_selected_text()
        elif event.key() == Qt.Key_Z and event.modifiers() & Qt.ControlModifier:
            if event.modifiers() & Qt.ShiftModifier:
                self.redo()
            else:
                self.undo()
        elif event.key() == Qt.Key_Y and event.modifiers() & Qt.ControlModifier:
            self.redo()
        elif event.key() == Qt.Key_D and event.modifiers() & Qt.ControlModifier:
            self.duplicate_selected()
        elif event.key() == Qt.Key_A and event.modifiers() & Qt.ControlModifier:
            self.select_all()
        elif event.key() == Qt.Key_G:
            # Toggle grid
            self.toggle_grid()
        elif event.key() == Qt.Key_S and not (event.modifiers() & Qt.ControlModifier):
            # Toggle snap
            self.toggle_snap()
        super().keyPressEvent(event)

    def wheelEvent(self, event: QWheelEvent):
        # Zoom with mouse wheel
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        self.scale(factor, factor)

    def contextMenuEvent(self, event):
        if self.selected_shapes:
            menu = QMenu(self)
            menu.addAction("Delete").triggered.connect(self.delete_selected)
            menu.addAction("Duplicate").triggered.connect(self.duplicate_selected)
            menu.addSeparator()
            menu.addAction("Bring to Front").triggered.connect(self.bring_to_front)
            menu.addAction("Send to Back").triggered.connect(self.send_to_back)
            if len(self.selected_shapes) == 1 and isinstance(self.selected_shapes[0], Text):
                menu.addSeparator()
                menu.addAction("Edit Text (F2)").triggered.connect(self.edit_selected_text)
            menu.exec_(event.globalPos())

    # ------------------------------------------------------------------
    # Drawing helpers
    # ------------------------------------------------------------------
    def create_temp_shape(self, pos):
        t = self.current_tool
        if t == "line":
            self.temp_shape = Line(pos, pos)
        elif t == "circle":
            self.temp_shape = Circle(pos, 0)
        elif t == "rectangle":
            self.temp_shape = Rectangle(pos, pos)
        elif t == "polygon":
            self.temp_shape = Polygon([pos])
        elif t == "text":
            text, ok = QInputDialog.getText(self, "Text", "Enter text:")
            if ok and text:
                self.temp_shape = Text(pos, text)
                self.finish_drawing()
            else:
                self.drawing = False
                self.temp_shape = None
        elif t == "polyline":
            self.temp_shape = Polyline([pos])
        elif t == "bezier":
            self.temp_shape = Bezier([pos, pos, pos, pos])

    def update_temp_shape(self, pos):
        if not self.temp_shape:
            return
        t = self.current_tool
        if t == "line":
            self.temp_shape.set_end_point(pos)
        elif t == "circle":
            r = math.sqrt((pos.x() - self.start_point.x()) ** 2 +
                          (pos.y() - self.start_point.y()) ** 2)
            self.temp_shape.set_radius(r)
        elif t == "rectangle":
            self.temp_shape.set_bottom_right(pos)
        elif t == "bezier":
            pts = self.temp_shape.get_points()
            pts[1] = QPointF((self.start_point.x() + pos.x()) / 3 * 2,
                            (self.start_point.y() + pos.y()) / 3 * 2)
            pts[2] = QPointF((self.start_point.x() + pos.x()) / 3,
                            (self.start_point.y() + pos.y()) / 3)
            pts[3] = pos
            self.temp_shape.set_points(pts)

    def cancel_drawing(self):
        self.drawing = False
        self.multi_click_points = []
        if self.temp_shape:
            if isinstance(self.temp_shape, Text) and \
               hasattr(self.temp_shape, 'text_item') and \
               self.temp_shape.text_item.scene() == self.scene:
                self.scene.removeItem(self.temp_shape.text_item)
            if self.temp_shape.scene() == self.scene:
                self.scene.removeItem(self.temp_shape)
            self.temp_shape = None
        self.clear_guides()
        self.hide_snap_indicator()

    def edit_selected_text(self):
        if not self.selected_shapes or not isinstance(self.selected_shapes[0], Text):
            return
        sh = self.selected_shapes[0]
        current = sh.get_text()
        text, ok = QInputDialog.getText(self, "Edit Text", "Text content:",
                                        QLineEdit.Normal, current)
        if ok and text.strip():
            old_text = current
            new_text = text.strip()
            sh.set_text(new_text)
            # Create command for undo
            cmd = ModifyShapeCommand(sh, {'text': old_text}, {'text': new_text})
            self.history.execute(cmd)
            self.update_undo_redo_state()
            self.logMessage.emit("Text updated", "info")

    # ------------------------------------------------------------------
    # Finish drawing (NEW command-based)
    # ------------------------------------------------------------------
    def finish_drawing(self):
        if not self.temp_shape:
            return
        if self.current_tool != "text" and self.temp_shape.scene() == self.scene:
            self.scene.removeItem(self.temp_shape)
        
        command = AddShapeCommand(self.editor, self.temp_shape, self.scene)
        self.history.execute(command)
        self.update_undo_redo_state()
        self.temp_shape = None
        self.clear_guides()
        self.hide_snap_indicator()

    # ------------------------------------------------------------------
    # Grid snap
    # ------------------------------------------------------------------
    def snap_to_grid_point(self, point):
        gs = self.grid_size
        x = round(point.x() / gs) * gs
        y = round(point.y() / gs) * gs
        return QPointF(x, y)

    # ------------------------------------------------------------------
    # Scene-Editor synchronization
    # ------------------------------------------------------------------
    def add_shape(self, shape):
        if shape.scene() != self.scene:
            self.scene.addItem(shape)
        if isinstance(shape, Text):
            shape.text_item.setFlag(QGraphicsItem.ItemIsSelectable, True)
            shape.text_item.setFlag(QGraphicsItem.ItemIsMovable, True)
            shape.text_item.setFlag(QGraphicsItem.ItemSendsGeometryChanges, True)
            shape.text_item.setVisible(True)
            shape.text_item.setZValue(shape.zValue())
        self.logMessage.emit(f"Added {shape.__class__.__name__}", "info")

    def update_shape(self, shape):
        shape.update()
        self.scene.update()
        self.logMessage.emit(f"Updated {shape.__class__.__name__}", "info")

    def delete_shape(self, shape):
        if shape.scene() == self.scene:
            if isinstance(shape, Text) and \
               hasattr(shape, 'text_item') and \
               shape.text_item.scene() == self.scene:
                self.scene.removeItem(shape.text_item)
            self.scene.removeItem(shape)
        self.logMessage.emit(f"Deleted {shape.__class__.__name__}", "info")

    # ------------------------------------------------------------------
    # Selection operations
    # ------------------------------------------------------------------
    def delete_selected(self):
        if not self.selected_shapes:
            return
        for shape in self.selected_shapes[:]:  # Copy list to avoid modification during iteration
            cmd = DeleteShapeCommand(self.editor, shape, self.scene)
            self.history.execute(cmd)
        self.selected_shapes = []
        self.shapeSelected.emit(None)
        self.update_undo_redo_state()

    def duplicate_selected(self):
        if not self.selected_shapes:
            return
        new_shapes = []
        for sh in self.selected_shapes:
            new_sh = sh.clone()
            new_sh.moveBy(20, 20)
            cmd = AddShapeCommand(self.editor, new_sh, self.scene)
            self.history.execute(cmd)
            new_shapes.append(new_sh)
        # Switch selection
        for sh in self.selected_shapes:
            sh.setSelected(False)
        self.selected_shapes = new_shapes
        for sh in self.selected_shapes:
            sh.setSelected(True)
        self.update_undo_redo_state()

    def bring_to_front(self):
        for sh in self.selected_shapes:
            sh.setZValue(sh.zValue() + 1)

    def send_to_back(self):
        for sh in self.selected_shapes:
            sh.setZValue(sh.zValue() - 1)

    def select_all(self):
        for item in self.scene.items():
            if isinstance(item, Shape):
                item.setSelected(True)
                if item not in self.selected_shapes:
                    self.selected_shapes.append(item)

    def clear_selection(self):
        for sh in self.selected_shapes:
            sh.setSelected(False)
        self.selected_shapes = []
        self.shapeSelected.emit(None)

    def on_all_shapes_cleared(self):
        items = [it for it in self.scene.items() if isinstance(it, Shape)]
        for it in items:
            if it.scene() == self.scene:
                self.scene.removeItem(it)
        self.selected_shapes = []
        self.logMessage.emit("Canvas cleared", "info")

    # ------------------------------------------------------------------
    # Clear all (NEW)
    # ------------------------------------------------------------------
    def clear_all(self):
        """Clear all shapes and history."""
        self.history.clear()
        self.editor.shapes.clear()
        self.scene.clear()
        self.selected_shapes = []
        self.update_undo_redo_state()
        self.logMessage.emit("Canvas cleared", "info")

    # ------------------------------------------------------------------
    # History (NEW command-based)
    # ------------------------------------------------------------------
    def update_undo_redo_state(self):
        """Update undo/redo button states."""
        can_undo = len(self.history.undo_stack) > 0
        can_redo = len(self.history.redo_stack) > 0
        self.undoRedoStateChanged.emit(can_undo, can_redo)

    def undo(self):
        if self.history.undo():
            self.update_undo_redo_state()
            self.logMessage.emit("Undo", "info")
        else:
            self.logMessage.emit("Nothing to undo", "warning")

    def redo(self):
        if self.history.redo():
            self.update_undo_redo_state()
            self.logMessage.emit("Redo", "info")
        else:
            self.logMessage.emit("Nothing to redo", "warning")

    # ------------------------------------------------------------------
    # View
    # ------------------------------------------------------------------
    def zoom_in(self):
        self.scale(1.25, 1.25)

    def zoom_out(self):
        self.scale(0.8, 0.8)

    def zoom_fit(self):
        rect = self.scene.itemsBoundingRect()
        if not rect.isNull():
            self.fitInView(rect, Qt.KeepAspectRatio)
        else:
            self.resetTransform()

    def toggle_grid(self):
        self.show_grid = not self.show_grid
        self.viewport().update()

    def toggle_snap(self):
        self.snap_to_grid = not self.snap_to_grid
        msg = "Snap enabled" if self.snap_to_grid else "Snap disabled"
        self.logMessage.emit(msg, "info")

    # ------------------------------------------------------------------
    # Background grid - Enhanced
    # ------------------------------------------------------------------
    def drawBackground(self, painter, rect):
        super().drawBackground(painter, rect)
        if not self.show_grid:
            return
        
        # Draw major and minor grid lines
        painter.setPen(QPen(QColor(220, 220, 220), 0.5))
        
        left = int(rect.left()) - (int(rect.left()) % self.grid_size)
        top = int(rect.top()) - (int(rect.top()) % self.grid_size)

        # Draw vertical lines
        x = left
        while x < rect.right():
            if x % (self.grid_size * 5) == 0:
                painter.setPen(QPen(QColor(180, 180, 180), 1))
            else:
                painter.setPen(QPen(QColor(220, 220, 220), 0.5))
            painter.drawLine(int(x), int(rect.top()), int(x), int(rect.bottom()))
            x += self.grid_size

        # Draw horizontal lines
        y = top
        while y < rect.bottom():
            if y % (self.grid_size * 5) == 0:
                painter.setPen(QPen(QColor(180, 180, 180), 1))
            else:
                painter.setPen(QPen(QColor(220, 220, 220), 0.5))
            painter.drawLine(int(rect.left()), int(y), int(rect.right()), int(y))
            y += self.grid_size

    # ------------------------------------------------------------------
    # Import / Export / Analyze / Nest
    # ------------------------------------------------------------------
    def get_shapes(self):
        return [it for it in self.scene.items() if isinstance(it, Shape)]

    def load_shapes(self, shapes):
        self.clear_all()
        for sh in shapes:
            cmd = AddShapeCommand(self.editor, sh, self.scene)
            self.history.execute(cmd)
        self.update_undo_redo_state()

    def import_image(self, file_path):
        try:
            self.clear_all()
            shapes, report = self.image_converter.convert_image(file_path)
            if not shapes:
                self.logMessage.emit("No shapes found in the image", "warning")
                return []
            for sh in shapes:
                cmd = AddShapeCommand(self.editor, sh, self.scene)
                self.history.execute(cmd)
            self.zoom_fit()
            score = report.get('quality_score', 0) * 100
            self.logMessage.emit(f"Imported {len(shapes)} shapes ({score:.1f}% quality)", "info")
            pat = report.get('pattern_analysis', {})
            if pat.get('pattern_count', 0) > 0:
                self.logMessage.emit(f"Dominant pattern: {pat.get('dominant_pattern', 'unknown')}", "info")
            self.update_undo_redo_state()
            return shapes
        except Exception as e:
            self.logMessage.emit(f"Failed to import image: {str(e)}", "error")
            raise

    def export_dxf(self, file_path):
        try:
            self.dxf_exporter.export(self.get_shapes(), file_path)
            self.logMessage.emit(f"DXF exported to {file_path}", "info")
        except Exception as e:
            self.logMessage.emit(f"Failed to export DXF: {str(e)}", "error")
            raise

    def export_svg(self, file_path):
        try:
            self.svg_exporter.export(self.get_shapes(), file_path)
            self.logMessage.emit(f"SVG exported to {file_path}", "info")
        except Exception as e:
            self.logMessage.emit(f"Failed to export SVG: {str(e)}", "error")
            raise

    def analyze_design(self):
        try:
            return self.analyzer.analyze(self.get_shapes())
        except Exception as e:
            self.logMessage.emit(f"Failed to analyze design: {str(e)}", "error")
            raise

    def optimize_nesting(self):
        try:
            shapes = self.get_shapes()
            if not shapes:
                self.logMessage.emit("No shapes to optimize", "warning")
                return
            poses = self.nesting_optimizer.optimize(shapes)
            for i, sh in enumerate(shapes):
                if i < len(poses):
                    x, y = poses[i]
                    old_pos = sh.pos()
                    new_pos = QPointF(x, y)
                    sh.setPos(new_pos)
                    # Create move command for undo
                    cmd = MoveShapeCommand(sh, old_pos, new_pos)
                    self.history.execute(cmd)
            self.update_undo_redo_state()
            self.logMessage.emit("Nesting optimization completed", "info")
        except Exception as e:
            self.logMessage.emit(f"Failed to optimize nesting: {str(e)}", "error")
            raise

    # ------------------------------------------------------------------
    # Properties panel
    # ------------------------------------------------------------------
    def update_shape_properties(self, props):
        if not self.selected_shapes:
            return
        for sh in self.selected_shapes:
            old_props = {}
            new_props = {}
            
            # Collect old and new properties
            if "x" in props:
                old_props["x"] = sh.pos().x()
                new_props["x"] = props["x"]
            if "y" in props:
                old_props["y"] = sh.pos().y()
                new_props["y"] = props["y"]
            if "color" in props:
                old_props["color"] = sh.get_color()
                new_props["color"] = props["color"]
            if "thickness" in props:
                old_props["thickness"] = sh.get_thickness()
                new_props["thickness"] = props["thickness"]
            
            # Apply properties
            sh.update_properties(props)
            if "x" in props or "y" in props:
                sh.setPos(props.get("x", sh.pos().x()), props.get("y", sh.pos().y()))
            
            # Create command for undo
            if old_props:
                cmd = ModifyShapeCommand(sh, old_props, new_props)
                self.history.execute(cmd)
        
        self.update_undo_redo_state()

    def has_unsaved_changes(self):
        return len(self.history.undo_stack) > 0
