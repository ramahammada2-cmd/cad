from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTextEdit, QPushButton, QHBoxLayout, QComboBox
from PyQt5.QtCore import Qt, QDateTime
from PyQt5.QtGui import QTextCursor, QColor

class LogPanel(QWidget):
    def __init__(self):
        super().__init__()
        
        # Set up UI
        self.init_ui()
    
    def init_ui(self):
        # Main layout
        layout = QVBoxLayout(self)
        
        # Toolbar
        toolbar_layout = QHBoxLayout()
        
        # Clear button
        self.clear_button = QPushButton("Clear")
        self.clear_button.clicked.connect(self.clear_log)
        toolbar_layout.addWidget(self.clear_button)
        
        # Filter combo
        self.filter_combo = QComboBox()
        self.filter_combo.addItems(["All", "Info", "Warning", "Error"])
        self.filter_combo.currentTextChanged.connect(self.filter_log)
        toolbar_layout.addWidget(self.filter_combo)
        
        # Export button
        self.export_button = QPushButton("Export")
        self.export_button.clicked.connect(self.export_log)
        toolbar_layout.addWidget(self.export_button)
        
        toolbar_layout.addStretch()
        
        layout.addLayout(toolbar_layout)
        
        # Log text area
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        layout.addWidget(self.log_text)
    
    def add_log(self, message, level="info"):
        # Get current timestamp
        timestamp = QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss")
        
        # Format message
        formatted_message = f"[{timestamp}] [{level.upper()}] {message}"
        
        # Move cursor to end
        cursor = self.log_text.textCursor()
        cursor.movePosition(QTextCursor.End)
        
        # Set color based on level
        if level == "error":
            self.log_text.setTextColor(QColor(255, 0, 0))
        elif level == "warning":
            self.log_text.setTextColor(QColor(255, 165, 0))
        else:
            self.log_text.setTextColor(QColor(0, 0, 0))
        
        # Insert message
        cursor.insertText(formatted_message + "\n")
        
        # Scroll to bottom
        self.log_text.setTextCursor(cursor)
        self.log_text.ensureCursorVisible()
    
    def clear_log(self):
        self.log_text.clear()
    
    def filter_log(self, filter_text):
        # In a real application, you would implement filtering here
        # For now, we'll just clear the log
        self.clear_log()
        self.add_log(f"Log filtered to show: {filter_text}", "info")
    
    def export_log(self):
        # In a real application, you would implement log export here
        self.add_log("Log export not implemented yet", "warning")