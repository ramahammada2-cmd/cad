import os
import json
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                            QSplitter, QFileDialog, QMessageBox, QAction, 
                            QMenu, QMenuBar, QStatusBar, QDockWidget)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QPointF
from PyQt5.QtGui import QIcon, QKeySequence

from ui.canvas import Canvas
from ui.toolbar import Toolbar
from ui.properties_panel import PropertiesPanel
from ui.log_panel import LogPanel
from exporters.project_manager import ProjectManager  # <-- CORRECTED IMPORT
from utils.settings import Settings
# Import all shape classes for reconstruction
from cad.shapes import Line, Circle, Rectangle, Polygon, Text, Polyline, Bezier

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("LaserCAD H1530 - Professional Laser Cutting CAD")
        self.setGeometry(100, 100, 1200, 800)
        
        # Initialize settings
        self.settings = Settings()
        
        # Initialize project manager
        self.project_manager = ProjectManager()
        
        # Set up UI
        self.setup_ui()
        self.setup_menu()
        self.setup_statusbar()
        
        # Auto-save timer
        self.auto_save_timer = QTimer()
        self.auto_save_timer.timeout.connect(self.auto_save)
        self.auto_save_timer.start(60000)  # Auto-save every minute
        
        # Restore previous session if exists
        self.restore_session()
    
    def setup_ui(self):
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Create main layout
        main_layout = QHBoxLayout(central_widget)
        
        # Create splitter for main content
        main_splitter = QSplitter(Qt.Horizontal)
        main_layout.addWidget(main_splitter)
        
        # Create toolbar
        self.toolbar = Toolbar()
        self.addToolBar(self.toolbar)
        
        # Create canvas
        self.canvas = Canvas()
        
        # Create properties panel
        self.properties_panel = PropertiesPanel()
        
        # Create log panel
        self.log_panel = LogPanel()
        
        # --- Now connect the signals ---
        self.toolbar.toolSelected.connect(self.canvas.set_tool)
        self.canvas.shapeSelected.connect(self.properties_panel.set_shape)
        self.canvas.logMessage.connect(self.log_panel.add_log)
        self.properties_panel.propertyChanged.connect(self.canvas.update_shape_properties)
        
        # Connect undo/redo signals
        self.toolbar.undoRequested.connect(self.canvas.undo)
        self.toolbar.redoRequested.connect(self.canvas.redo)
        self.canvas.undoRedoStateChanged.connect(self.toolbar.update_undo_redo_buttons)
        
        # Add widgets to splitter
        main_splitter.addWidget(self.canvas)
        main_splitter.addWidget(self.properties_panel)
        
        # Create dock widget for log panel
        log_dock = QDockWidget("Log", self)
        log_dock.setWidget(self.log_panel)
        log_dock.setAllowedAreas(Qt.BottomDockWidgetArea)
        self.addDockWidget(Qt.BottomDockWidgetArea, log_dock)
        
        # Set splitter sizes
        main_splitter.setSizes([800, 400])
    
    def setup_menu(self):
        # Create menu bar
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("File")
        
        new_action = QAction("New Project", self)
        new_action.setShortcut(QKeySequence.New)
        new_action.triggered.connect(self.new_project)
        file_menu.addAction(new_action)
        
        open_action = QAction("Open Project", self)
        open_action.setShortcut(QKeySequence.Open)
        open_action.triggered.connect(self.open_project)
        file_menu.addAction(open_action)
        
        save_action = QAction("Save Project", self)
        save_action.setShortcut(QKeySequence.Save)
        save_action.triggered.connect(self.save_project)
        file_menu.addAction(save_action)
        
        save_as_action = QAction("Save Project As...", self)
        save_as_action.setShortcut(QKeySequence.SaveAs)
        save_as_action.triggered.connect(self.save_project_as)
        file_menu.addAction(save_as_action)
        
        file_menu.addSeparator()
        
        import_image_action = QAction("Import Image", self)
        import_image_action.triggered.connect(self.import_image)
        file_menu.addAction(import_image_action)
        
        file_menu.addSeparator()
        
        export_dxf_action = QAction("Export DXF", self)
        export_dxf_action.triggered.connect(self.export_dxf)
        file_menu.addAction(export_dxf_action)
        
        export_svg_action = QAction("Export SVG", self)
        export_svg_action.triggered.connect(self.export_svg)
        file_menu.addAction(export_svg_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("Exit", self)
        exit_action.setShortcut(QKeySequence.Quit)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Edit menu
        edit_menu = menubar.addMenu("Edit")
        
        undo_action = QAction("Undo", self)
        undo_action.setShortcut(QKeySequence.Undo)
        undo_action.triggered.connect(self.canvas.undo)
        edit_menu.addAction(undo_action)
        
        redo_action = QAction("Redo", self)
        redo_action.setShortcut(QKeySequence.Redo)
        redo_action.triggered.connect(self.canvas.redo)
        edit_menu.addAction(redo_action)
        
        edit_menu.addSeparator()
        
        select_all_action = QAction("Select All", self)
        select_all_action.setShortcut(QKeySequence.SelectAll)
        select_all_action.triggered.connect(self.canvas.select_all)
        edit_menu.addAction(select_all_action)
        
        clear_selection_action = QAction("Clear Selection", self)
        clear_selection_action.setShortcut("Esc")
        clear_selection_action.triggered.connect(self.canvas.clear_selection)
        edit_menu.addAction(clear_selection_action)
        
        # Tools menu
        tools_menu = menubar.addMenu("Tools")
        
        analyze_action = QAction("Analyze Design", self)
        analyze_action.triggered.connect(self.analyze_design)
        tools_menu.addAction(analyze_action)
        
        optimize_nesting_action = QAction("Optimize Nesting", self)
        optimize_nesting_action.triggered.connect(self.optimize_nesting)
        tools_menu.addAction(optimize_nesting_action)
        
        # View menu
        view_menu = menubar.addMenu("View")
        
        zoom_in_action = QAction("Zoom In", self)
        zoom_in_action.setShortcut(QKeySequence.ZoomIn)
        zoom_in_action.triggered.connect(self.canvas.zoom_in)
        view_menu.addAction(zoom_in_action)
        
        zoom_out_action = QAction("Zoom Out", self)
        zoom_out_action.setShortcut(QKeySequence.ZoomOut)
        zoom_out_action.triggered.connect(self.canvas.zoom_out)
        view_menu.addAction(zoom_out_action)
        
        zoom_fit_action = QAction("Zoom Fit", self)
        zoom_fit_action.setShortcut("F")
        zoom_fit_action.triggered.connect(self.canvas.zoom_fit)
        view_menu.addAction(zoom_fit_action)
        
        view_menu.addSeparator()
        
        grid_action = QAction("Show Grid", self)
        grid_action.setCheckable(True)
        grid_action.setChecked(True)
        grid_action.triggered.connect(self.toggle_grid)
        view_menu.addAction(grid_action)
        
        snap_action = QAction("Snap to Grid", self)
        snap_action.setCheckable(True)
        snap_action.setChecked(True)
        snap_action.triggered.connect(self.toggle_snap)
        view_menu.addAction(snap_action)
        
        # Settings menu
        settings_menu = menubar.addMenu("Settings")
        
        theme_menu = settings_menu.addMenu("Theme")
        
        light_theme_action = QAction("Light", self)
        light_theme_action.setCheckable(True)
        light_theme_action.setChecked(self.settings.theme == "light")
        light_theme_action.triggered.connect(lambda: self.set_theme("light"))
        theme_menu.addAction(light_theme_action)
        
        dark_theme_action = QAction("Dark", self)
        dark_theme_action.setCheckable(True)
        dark_theme_action.setChecked(self.settings.theme == "dark")
        dark_theme_action.triggered.connect(lambda: self.set_theme("dark"))
        theme_menu.addAction(dark_theme_action)
    
    def setup_statusbar(self):
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        self.statusbar.showMessage("Ready")
    
    def new_project(self):
        reply = QMessageBox.question(self, 'New Project', 
                                    'Are you sure you want to create a new project? Any unsaved changes will be lost.',
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            self.canvas.clear_all()
            self.project_manager.new_project()
            self.statusbar.showMessage("New project created")
    
    def open_project(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Open Project", "", "LaserCAD Project (*.xlt)")
        if file_path:
            try:
                shapes_data = self.project_manager.load_project(file_path)
                # Convert data to shape objects
                shapes = []
                for shape_data in shapes_data:
                    shape = self.dict_to_shape(shape_data)
                    if shape:
                        shapes.append(shape)
                self.canvas.load_shapes(shapes)
                self.statusbar.showMessage(f"Project loaded: {os.path.basename(file_path)}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to open project: {str(e)}")
    
    def save_project(self):
        if self.project_manager.file_path:
            try:
                self.project_manager.save_project(self.canvas.get_shapes())
                self.statusbar.showMessage(f"Project saved: {os.path.basename(self.project_manager.file_path)}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save project: {str(e)}")
        else:
            self.save_project_as()
    
    def save_project_as(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Project As", "", "LaserCAD Project (*.xlt)")
        if file_path:
            if not file_path.endswith('.xlt'):
                file_path += '.xlt'
            
            try:
                self.project_manager.save_project(self.canvas.get_shapes(), file_path)
                self.statusbar.showMessage(f"Project saved: {os.path.basename(file_path)}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save project: {str(e)}")
    
    def import_image(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Import Image", "", "Image Files (*.png *.jpg *.jpeg *.bmp)")
        if file_path:
            try:
                shapes = self.canvas.import_image(file_path)
                self.statusbar.showMessage(f"Image imported: {os.path.basename(file_path)}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to import image: {str(e)}")
    
    def export_dxf(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Export DXF", "", "DXF Files (*.dxf)")
        if file_path:
            if not file_path.endswith('.dxf'):
                file_path += '.dxf'
            
            try:
                self.canvas.export_dxf(file_path)
                self.statusbar.showMessage(f"DXF exported: {os.path.basename(file_path)}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to export DXF: {str(e)}")
    
    def export_svg(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Export SVG", "", "SVG Files (*.svg)")
        if file_path:
            if not file_path.endswith('.svg'):
                file_path += '.svg'
            
            try:
                self.canvas.export_svg(file_path)
                self.statusbar.showMessage(f"SVG exported: {os.path.basename(file_path)}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to export SVG: {str(e)}")
    
    def analyze_design(self):
        try:
            issues = self.canvas.analyze_design()
            if issues:
                message = "Design issues found:\n\n" + "\n".join(issues)
                QMessageBox.information(self, "Design Analysis", message)
            else:
                QMessageBox.information(self, "Design Analysis", "No issues found in the design.")
            self.statusbar.showMessage("Design analysis completed")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to analyze design: {str(e)}")
    
    def optimize_nesting(self):
        try:
            self.canvas.optimize_nesting()
            self.statusbar.showMessage("Nesting optimization completed")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to optimize nesting: {str(e)}")
    
    def toggle_grid(self):
        self.canvas.toggle_grid()
    
    def toggle_snap(self):
        self.canvas.toggle_snap()
    
    def set_theme(self, theme):
        self.settings.theme = theme
        self.settings.save()
        # In a real application, you would apply the theme here
        self.statusbar.showMessage(f"Theme changed to {theme}")
    
    def auto_save(self):
        if self.project_manager.file_path:
            try:
                self.project_manager.save_project(self.canvas.get_shapes())
                self.statusbar.showMessage("Auto-saved", 2000)
            except Exception as e:
                self.log_panel.add_log(f"Auto-save failed: {str(e)}", "error")
    
    def restore_session(self):
        # Check if there's a previous session to restore
        if self.project_manager.has_auto_save():
            reply = QMessageBox.question(self, 'Restore Session', 
                                        'A previous session was found. Do you want to restore it?',
                                        QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            
            if reply == QMessageBox.Yes:
                try:
                    shapes_data = self.project_manager.restore_auto_save()
                    shapes = []
                    for shape_data in shapes_data:
                        shape = self.dict_to_shape(shape_data)
                        if shape:
                            shapes.append(shape)
                    self.canvas.load_shapes(shapes)
                    self.statusbar.showMessage("Previous session restored")
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"Failed to restore session: {str(e)}")
    
    def closeEvent(self, event):
        # Check if there are unsaved changes
        if self.canvas.has_unsaved_changes():
            reply = QMessageBox.question(self, 'Unsaved Changes', 
                                        'You have unsaved changes. Do you want to save before exiting?',
                                        QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel, QMessageBox.Yes)
            
            if reply == QMessageBox.Yes:
                self.save_project()
                event.accept()
            elif reply == QMessageBox.No:
                event.accept()
            else:
                event.ignore()
                return
        
        # Save current session for potential restoration
        try:
            self.project_manager.save_auto_save(self.canvas.get_shapes())
        except Exception as e:
            print(f"Failed to save session: {str(e)}")
        
        event.accept()

    def dict_to_shape(self, shape_data):
        shape_type = shape_data.get("type")
        if not shape_type:
            return None

        shape_classes = {
            "Line": Line,
            "Circle": Circle,
            "Rectangle": Rectangle,
            "Polygon": Polygon,
            "Text": Text,
            "Polyline": Polyline,
            "Bezier": Bezier,
        }

        shape_class = shape_classes.get(shape_type)
        if not shape_class:
            return None
        
        shape = None
        # Create a basic shape instance with minimal required parameters
        if shape_type == "Line":
            start = QPointF(shape_data["start_point"]["x"], shape_data["start_point"]["y"])
            end = QPointF(shape_data["end_point"]["x"], shape_data["end_point"]["y"])
            shape = shape_class(start, end)
        elif shape_type == "Circle":
            center = QPointF(shape_data["center"]["x"], shape_data["center"]["y"])
            shape = shape_class(center, shape_data["radius"])
        elif shape_type == "Rectangle":
            top_left = QPointF(shape_data["top_left"]["x"], shape_data["top_left"]["y"])
            bottom_right = QPointF(shape_data["bottom_right"]["x"], shape_data["bottom_right"]["y"])
            shape = shape_class(top_left, bottom_right)
        elif shape_type in ["Polygon", "Polyline", "Bezier"]:
            points = [QPointF(p["x"], p["y"]) for p in shape_data["points"]]
            shape = shape_class(points)
        elif shape_type == "Text":
            pos = QPointF(shape_data["position"]["x"], shape_data["position"]["y"])
            shape = shape_class(pos, shape_data["text"])
        
        if shape:
            # Set position and then use update_properties for all other attributes
            shape.setPos(QPointF(shape_data["position"]["x"], shape_data["position"]["y"]))
            shape.update_properties(shape_data)
        
        return shape