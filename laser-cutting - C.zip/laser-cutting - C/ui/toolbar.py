from PyQt5.QtWidgets import QToolBar, QAction, QActionGroup, QSpinBox, QLabel, QComboBox
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QIcon
from PyQt5.QtGui import QKeySequence
import os

class Toolbar(QToolBar):
    toolSelected = pyqtSignal(str)
    undoRequested = pyqtSignal()
    redoRequested = pyqtSignal()

    def __init__(self):
        super().__init__()
        # Set toolbar properties
        self.setMovable(False)
        self.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        # Create action group for tools
        self.tool_group = QActionGroup(self)
        self.tool_group.setExclusive(True)
        # Add tools
        self.add_select_tool()
        self.add_line_tool()
        self.add_circle_tool()
        self.add_rectangle_tool()
        self.add_polygon_tool()
        self.add_text_tool()
        self.add_polyline_tool()
        self.add_bezier_tool()
        self.addSeparator()
        # Add undo/redo buttons
        self.add_undo_redo_buttons()
        self.addSeparator()
        # Add color and thickness controls
        self.add_color_control()
        self.add_thickness_control()
        self.addSeparator()
        # Add layer control
        self.add_layer_control()

    def _get_icon_path(self, icon_name: str) -> str:
        """Helper to get the path to an icon, returning a default if not found."""
        path = os.path.join("resources", "icons", icon_name)
        if os.path.exists(path):
            return path
        else:
            # Return a default icon or an empty string if no default is desired
            # For this example, we'll return an empty string, which means no icon
            print(f"Warning: Icon {path} not found.")
            return "" # Or return a path to a default icon

    def add_select_tool(self):
        icon_path = self._get_icon_path("select.png")
        if icon_path:
            action = QAction(QIcon(icon_path), "Select", self)
        else:
            action = QAction("Select", self) # No icon
        action.setCheckable(True)
        action.setChecked(True)
        action.setData("select")
        action.triggered.connect(lambda: self.toolSelected.emit("select"))
        self.tool_group.addAction(action)
        self.addAction(action)

    def add_line_tool(self):
        icon_path = self._get_icon_path("line.png")
        if icon_path:
            action = QAction(QIcon(icon_path), "Line", self)
        else:
            action = QAction("Line", self)
        action.setCheckable(True)
        action.setData("line")
        action.triggered.connect(lambda: self.toolSelected.emit("line"))
        self.tool_group.addAction(action)
        self.addAction(action)

    def add_circle_tool(self):
        icon_path = self._get_icon_path("circle.png")
        if icon_path:
            action = QAction(QIcon(icon_path), "Circle", self)
        else:
            action = QAction("Circle", self)
        action.setCheckable(True)
        action.setData("circle")
        action.triggered.connect(lambda: self.toolSelected.emit("circle"))
        self.tool_group.addAction(action)
        self.addAction(action)

    def add_rectangle_tool(self):
        icon_path = self._get_icon_path("rectangle.png")
        if icon_path:
            action = QAction(QIcon(icon_path), "Rectangle", self)
        else:
            action = QAction("Rectangle", self)
        action.setCheckable(True)
        action.setData("rectangle")
        action.triggered.connect(lambda: self.toolSelected.emit("rectangle"))
        self.tool_group.addAction(action)
        self.addAction(action)

    def add_polygon_tool(self):
        icon_path = self._get_icon_path("polygon.png")
        if icon_path:
            action = QAction(QIcon(icon_path), "Polygon", self)
        else:
            action = QAction("Polygon", self)
        action.setCheckable(True)
        action.setData("polygon")
        action.triggered.connect(lambda: self.toolSelected.emit("polygon"))
        self.tool_group.addAction(action)
        self.addAction(action)

    def add_text_tool(self):
        icon_path = self._get_icon_path("text.png")
        if icon_path:
            action = QAction(QIcon(icon_path), "Text", self)
        else:
            action = QAction("Text", self)
        action.setCheckable(True)
        action.setData("text")
        action.triggered.connect(lambda: self.toolSelected.emit("text"))
        self.tool_group.addAction(action)
        self.addAction(action)

    def add_polyline_tool(self):
        icon_path = self._get_icon_path("polyline.png")
        if icon_path:
            action = QAction(QIcon(icon_path), "Polyline", self)
        else:
            action = QAction("Polyline", self)
        action.setCheckable(True)
        action.setData("polyline")
        action.triggered.connect(lambda: self.toolSelected.emit("polyline"))
        self.tool_group.addAction(action)
        self.addAction(action)

    def add_bezier_tool(self):
        icon_path = self._get_icon_path("bezier.png")
        if icon_path:
            action = QAction(QIcon(icon_path), "Bezier", self)
        else:
            action = QAction("Bezier", self)
        action.setCheckable(True)
        action.setData("bezier")
        action.triggered.connect(lambda: self.toolSelected.emit("bezier"))
        self.tool_group.addAction(action)
        self.addAction(action)

    def add_undo_redo_buttons(self):
        # Undo button
        self.undo_action = QAction("Undo", self)
        self.undo_action.setShortcut(QKeySequence.Undo)
        self.undo_action.setEnabled(False)
        self.undo_action.setToolTip("Undo (Ctrl+Z)")
        self.undo_action.triggered.connect(self.undoRequested.emit)
        self.addAction(self.undo_action)
        
        # Redo button
        self.redo_action = QAction("Redo", self)
        self.redo_action.setShortcut(QKeySequence.Redo)
        self.redo_action.setEnabled(False)
        self.redo_action.setToolTip("Redo (Ctrl+Y or Ctrl+Shift+Z)")
        self.redo_action.triggered.connect(self.redoRequested.emit)
        self.addAction(self.redo_action)

    def update_undo_redo_buttons(self, can_undo, can_redo):
        """Update the enabled/disabled state of undo/redo buttons"""
        if hasattr(self, 'undo_action'):
            self.undo_action.setEnabled(can_undo)
        if hasattr(self, 'redo_action'):
            self.redo_action.setEnabled(can_redo)

    # --- ADD THESE THREE METHODS ---
    def add_color_control(self):
        self.addWidget(QLabel("Color:"))
        self.color_combo = QComboBox()
        self.color_combo.addItems(["Black", "Red", "Green", "Blue", "Yellow", "Cyan", "Magenta"])
        self.color_combo.setCurrentIndex(0)
        self.addWidget(self.color_combo)

    def add_thickness_control(self):
        self.addWidget(QLabel("Thickness:"))
        self.thickness_spin = QSpinBox()
        self.thickness_spin.setRange(1, 20)
        self.thickness_spin.setValue(2)
        self.thickness_spin.setSuffix(" px")
        self.addWidget(self.thickness_spin)

    def add_layer_control(self):
        self.addWidget(QLabel("Layer:"))
        self.layer_combo = QComboBox()
        self.layer_combo.addItems(["Layer 1", "Layer 2", "Layer 3", "Layer 4", "Layer 5"])
        self.layer_combo.setCurrentIndex(0)
        self.addWidget(self.layer_combo)
    # --- END OF ADDED METHODS ---

    # --- ADD THESE THREE GETTER METHODS ---
    def get_color(self):
        color_map = {
            "Black": "#000000",
            "Red": "#FF0000",
            "Green": "#00FF00",
            "Blue": "#0000FF",
            "Yellow": "#FFFF00",
            "Cyan": "#00FFFF",
            "Magenta": "#FF00FF"
        }
        return color_map.get(self.color_combo.currentText(), "#000000")

    def get_thickness(self):
        return self.thickness_spin.value()

    def get_layer(self):
        return self.layer_combo.currentIndex()
    # --- END OF GETTER METHODS ---
