#!/usr/bin/env python3
"""
Test script to verify the CAD application can be imported and basic functionality works
"""

import sys
import os

# Add the fixed_cad directory to Python path
sys.path.insert(0, os.path.dirname(__file__))

def test_imports():
    """Test that all modules can be imported successfully"""
    try:
        print("Testing imports...")
        
        # Test core imports
        from cad.shapes import Shape, Line, Circle, Rectangle, Polygon, Text, Polyline, Bezier
        print("✓ Shapes module imported successfully")
        
        from cad.editor import Editor
        print("✓ Editor module imported successfully")
        
        from exporters.project_manager import ProjectManager
        print("✓ ProjectManager imported successfully")
        
        from exporters.dxf_exporter import DXFExporter
        print("✓ DXFExporter imported successfully")
        
        from exporters.svg_exporter import SVGExporter
        print("✓ SVGExporter imported successfully")
        
        from ui.main_window import MainWindow
        print("✓ MainWindow imported successfully")
        
        from ui.canvas import Canvas
        print("✓ Canvas imported successfully")
        
        from ui.properties_panel import PropertiesPanel
        print("✓ PropertiesPanel imported successfully")
        
        print("\nAll imports successful! ✓")
        return True
        
    except ImportError as e:
        print(f"✗ Import error: {e}")
        return False
    except Exception as e:
        print(f"✗ Unexpected error: {e}")
        return False

def test_basic_functionality():
    """Test basic functionality of core components"""
    try:
        print("\nTesting basic functionality...")
        
        # Test Editor functionality
        from cad.editor import Editor
        editor = Editor()
        
        # Test adding shapes
        from cad.shapes import Line
        from PyQt5.QtCore import QPointF
        
        start = QPointF(0, 0)
        end = QPointF(100, 100)
        line = Line(start, end)
        
        editor.add_shape(line)
        assert len(editor.get_shapes()) == 1
        print("✓ Editor can add shapes")
        
        # Test shape deletion
        editor.delete_shape(line)
        assert len(editor.get_shapes()) == 0
        print("✓ Editor can delete shapes")
        
        # Test ProjectManager
        from exporters.project_manager import ProjectManager
        pm = ProjectManager()
        assert pm.file_path is None
        print("✓ ProjectManager initializes correctly")
        
        print("\nBasic functionality test passed! ✓")
        return True
        
    except Exception as e:
        print(f"✗ Functionality test failed: {e}")
        return False

def main():
    print("CAD Application Test Suite")
    print("=" * 40)
    
    import_success = test_imports()
    functionality_success = test_basic_functionality()
    
    if import_success and functionality_success:
        print("\n🎉 All tests passed! The application should work correctly.")
        return 0
    else:
        print("\n❌ Some tests failed. Please check the errors above.")
        return 1

if __name__ == "__main__":
    exit(main())